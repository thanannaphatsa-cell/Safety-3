/* =========================================================
   Hospital Safety Management System — โรงพยาบาลเปาโล เกษตร
   Architecture: store (data layer) → views (render) → router
   Swap Store.load/save for REST/GraphQL calls to go live.
   ========================================================= */
(function(){
"use strict";

/* ---------- utils ---------- */
const $=(s,r)=> (r||document).querySelector(s);
const $$=(s,r)=> Array.from((r||document).querySelectorAll(s));
const esc=s=> String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=> String(n).padStart(2,'0');
const iso=d=> d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const ym=d=> d.getFullYear()+'-'+pad(d.getMonth()+1);
const TODAY=new Date();
const HOSPITAL='โรงพยาบาลเปาโล เกษตร';
const THMON=['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
const THMON_FULL=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
function thDate(s){ if(!s) return '—'; const d=new Date(s); if(isNaN(d)) return s;
  return d.getDate()+' '+THMON[d.getMonth()]+' '+(d.getFullYear()+543); }
function thMonth(s){ if(!s) return '—'; const p=String(s).split('-');
  return THMON_FULL[Number(p[1])-1]+' '+(Number(p[0])+543); }
function thMonthShort(s){ if(!s) return '—'; const p=String(s).split('-');
  return THMON[Number(p[1])-1]+' '+String(Number(p[0])+543).slice(2); }
function thLong(d){ return ['วันอาทิตย์','วันจันทร์','วันอังคาร','วันพุธ','วันพฤหัสบดี','วันศุกร์','วันเสาร์'][d.getDay()]+'ที่ '+d.getDate()+' '+THMON_FULL[d.getMonth()]+' พ.ศ. '+(d.getFullYear()+543); }
const daysBetween=(a,b)=> Math.round((new Date(b)-new Date(a))/864e5);
const addDays=(d,n)=>{const x=new Date(d); x.setDate(x.getDate()+n); return x;};
const num=n=> (n==null||isNaN(n))?'—':Number(n).toLocaleString('th-TH',{maximumFractionDigits:2});
const pick=(a,i)=> a[i%a.length];
function uid(p){ return p+'-'+Math.random().toString(36).slice(2,7).toUpperCase(); }
function toast(msg,err){ const t=document.createElement('div'); t.className='toast'+(err?' err':'');
  t.innerHTML='<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="'+(err?'M12 8v5M12 16.5v.01M12 3l9 16H3z':'M20 6L9 17l-5-5')+'"/></svg><span>'+esc(msg)+'</span>';
  $('#toasts').appendChild(t); setTimeout(()=>t.remove(),3600); }

/* ---------- reference data ---------- */
const DEPTS=['บริหารคุณภาพและความปลอดภัย ควบคุมและป้องกันการติดเชื้อ','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม','แผนกฉุกเฉินและรถพยาบาล','แผนกทรัพยากรบุคคล','แผนกทันตกรรม','แผนกธุรการ','แผนกบริหารการตลาด','แผนกบริหารจัดการรายได้และสิทธิประโยชน์','แผนกบริการทรัพยากรการแพทย์','แผนกบริหารลูกค้าองค์กรและประกันสัมพันธ์','ผู้ป่วยนอก ตา หู จมูก คอ','แผนกผู้ป่วยนอกกระดูกและข้อ','แผนกผู้ป่วยนอกประกันสังคมเฉพาะทาง','แผนกผู้ป่วยนอกประกันสังคมทั่วไป','แผนกผู้ป่วยนอกศัลยกรรม','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','แผนกผู้ป่วยนอกอายุรกรรม 1','แผนกผู้ป่วยนอกอายุรกรรม 2','แผนกผู้ป่วยในเด็ก Ward 3','แผนกผู้ป่วยในประกันสังคม Ward B6','แผนกผู้ป่วยในสูตินรีเวช-ศัลยกรรม Ward B5','แผนกผู้ป่วยในอายุรกรรม Ward B4','แผนกผู้ป่วยในอายุรกรรม Ward B7','แผนกผู้ป่วยในอายุรกรรม Ward B8','แผนกผู้ป่วยวิกฤต','แผนกรังสี','แผนกศูนย์เลเซอร์และคลินิกเต้านม','แผนกศูนย์ตรวจสุขภาพ','แผนกศูนย์สุขภาพเด็ก','แผนกสนับสนุนบริการพยาบาล','แผนกสื่อสารการตลาด 1','แผนกห้องเด็กอ่อน','แผนกห้องผ่าตัดและจ่ายกลาง','แผนกโอเปอร์เรเตอร์','แผนก พรบ.','แผนกหน่วยการเงินนอก','แผนกหน่วยการเงินใน','หน่วยบริหารความปลอดภัย อาชีวอนามัยและสิ่งแวดล้อม','หน่วยบริหารสินค้าคงคลังและโลจิสติกส์','หน่วยเภสัชกรรมผู้ป่วยนอก','หน่วยเภสัชกรรมผู้ป่วยใน','หน่วยเภสัชกรรมประกันสังคม','หน่วยโภชนาการ','หน่วยแม่บ้านและซักรีด','หน่วยยานพาหนะ','หน่วยรักษาความปลอดภัย','หน่วยรับส่งผู้ป่วย','แผนกลงทะเบียนผู้ป่วยใน','หน่วยลูกค้าสัมพันธ์และลงทะเบียน','หน่วยเวชระเบียน','หน่วยเวชสถิติ','หน่วยสนับสนุนเทคโนโลยีสารสนเทศ'];
const BUILDINGS=['อาคาร A ชั้น 1','อาคาร A ชั้น 2','อาคาร A ชั้น 3','อาคาร A ชั้น 4','อาคาร A ชั้น 5','อาคาร B ชั้น 1','อาคาร B ชั้น 2','อาคาร B ชั้น 3','อาคาร B ชั้น 4','อาคาร B ชั้น 5','อาคาร B ชั้น 6','อาคาร B ชั้น 7','อาคาร B ชั้น 8','ดาดฟ้าอาคาร B','อาคาร C ชั้น 1','อาคาร C ชั้น 2','อาคาร C ชั้น 3','อาคาร C ชั้น 4','อาคาร D ชั้น 1','อาคาร D ชั้น 2','อาคาร D ชั้น 3','อาคาร D ชั้น 4','อาคาร E ชั้น 1','อาคาร E ชั้น M','อาคาร E ชั้น 2','อาคาร E ชั้น 3','อาคาร E ชั้น 4','ห้องผ้า','คุณภาพ','โภชนาการ','การตลาด','วิศวกรรม/เครื่องมือแพทย์'];
const RISK3=['สูง','ปานกลาง','ต่ำ'];
const ROUND_STATUS=['ยังไม่เริ่มดำเนินการ','อยู่ระหว่างดำเนินการ','ดำเนินการเสร็จสิ้น','ไม่สามารถดำเนินการได้'];
const INSPECTORS=['คกก.ENV','คกก.ความปลอดภัย','จป.วิชาชีพ','ทีม IC','ทีมวิศวกรรม'];
const SEVERITY=['เล็กน้อย','ปานกลาง','รุนแรง','วิกฤต'];
const RISK=['สูงมาก','สูง','ปานกลาง','ต่ำ'];
const PERSON_TYPE=['พนักงาน','ผู้รับเหมา','ผู้ป่วย','ผู้มาเยือน','นักศึกษาฝึกงาน'];
const ACC_TYPE=['ของมีคมบาด/ทิ่มตำ','ลื่น/สะดุด/หกล้ม','สัมผัสสารเคมี','ยกของ/ท่าทางการทำงาน','ไฟฟ้า','สัมผัสสารคัดหลั่ง','ถูกกระแทก/ชน','ความร้อน/ลวก','ถูกทำร้ายร่างกาย','อุบัติเหตุจราจรในงาน'];
const STATUS_ACT=['Open','In Progress','Pending Verification','Closed','Overdue'];
const ROLES=['Safety Officer','ผู้ใช้งานทั่วไป'];
const PEOPLE=['ณัฐวุฒิ พงษ์สวัสดิ์','สุภาพร ใจดีงาม','ธนกฤต ศรีวิชัย','พิมพ์ชนก อารีย์','กิตติศักดิ์ แสนสุข','วราภรณ์ ทองแท้','ชัยวัฒน์ มณีรัตน์','อรุณี สว่างจิต','ปรีชา หลักทรัพย์','เมธาวี จันทร์เพ็ญ','สมชาย เกียรติยศ','นภัสสร บุญมาก'];
/* ฐานชั่วโมงการทำงานสำหรับคำนวณ IFR / ISR */
const MANPOWER=860, HOURS_YEAR=MANPOWER*2400;      /* ชม.ทำงานรวมต่อปี */
const HOURS_MONTH=Math.round(HOURS_YEAR/12);
const WW_PARAMS=[
  {k:'appearance',label:'Appearance',std:'ไม่มีสี กลิ่น ตะกอนแขวนลอย',text:true},
  {k:'ph',label:'pH',std:'5.5 – 9.0',min:5.5,max:9,unit:''},
  {k:'bod',label:'BOD',std:'< 20',max:20,unit:'มก./ล.'},
  {k:'tss',label:'TSS',std:'< 30',max:30,unit:'มก./ล.'},
  {k:'tds',label:'TDS',std:'< 1,000',max:1000,unit:'มก./ล.'},
  {k:'settleable',label:'Settleable Solids',std:'< 0.5',max:0.5,unit:'มล./ล.'},
  {k:'sulfide',label:'Sulfide',std:'< 1.0',max:1,unit:'มก./ล.'},
  {k:'tkn',label:'TKN',std:'< 35',max:35,unit:'มก./ล.'},
  {k:'oil',label:'Oil & Grease',std:'< 20',max:20,unit:'มก./ล.'},
  {k:'totalColiform',label:'Total Coliform Bacteria',std:'< 5,000',max:5000,unit:'MPN/100 มล.'},
  {k:'fecalColiform',label:'Fecal Coliform Bacteria',std:'< 1,000',max:1000,unit:'MPN/100 มล.'},
  {k:'chlorine',label:'Chlorine, Residue',std:'0.2 – 1.0',min:0.2,max:1,unit:'มก./ล.'},
  {k:'cod',label:'COD',std:'เฝ้าระวัง',unit:'มก./ล.'},
  {k:'ecoli',label:'E.coli',std:'< 1,000',max:1000,unit:'MPN/100 มล.'},
  {k:'parasite',label:'ไข่พยาธิ',std:'< 1',max:1,unit:'ฟอง/ล.'}
];
const WASTE_TYPES=['ขยะทั่วไป','ขยะติดเชื้อ','ขยะอันตราย','ขยะรีไซเคิล','ขยะเคมี'];
const TRAIN_TYPES=['อบรมพนักงานใหม่ก่อนเริ่มงาน','อบรมผู้รับเหมาก่อนเริ่มงาน'];

/* ---------- seeded pseudo-random (stable demo data) ---------- */
let _s=20260917;
function rnd(){ _s=(_s*1103515245+12345)&0x7fffffff; return _s/0x7fffffff; }
const ri=(a,b)=> a+Math.floor(rnd()*(b-a+1));
const rp=a=> a[Math.floor(rnd()*a.length)];

/* ---------- seed ---------- */
function seed(){
  const S={};
  S.departments=DEPTS.map((n,i)=>({id:'D'+pad(i+1),name:n,head:pick(PEOPLE,i),staff:ri(6,48)}));
  S.users=[
    {id:'U01',name:'ณัฐวุฒิ พงษ์สวัสดิ์',role:'Safety Officer',dept:'หน่วยบริหารความปลอดภัย อาชีวอนามัยและสิ่งแวดล้อม',email:'natt@paolokaset.co.th',status:'อนุมัติแล้ว',regDate:'2026-01-12'},
    {id:'U02',name:'สุภาพร ใจดีงาม',role:'Safety Officer',dept:'บริหารคุณภาพและความปลอดภัย ควบคุมและป้องกันการติดเชื้อ',email:'supa@paolokaset.co.th',status:'อนุมัติแล้ว',regDate:'2026-01-12'},
    {id:'U03',name:'ธนกฤต ศรีวิชัย',role:'ผู้ใช้งานทั่วไป',dept:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',email:'thana@paolokaset.co.th',status:'อนุมัติแล้ว',regDate:'2026-02-03'},
    {id:'U04',name:'พิมพ์ชนก อารีย์',role:'ผู้ใช้งานทั่วไป',dept:'แผนกผู้ป่วยนอกอายุรกรรม 1',email:'pim@paolokaset.co.th',status:'อนุมัติแล้ว',regDate:'2026-02-14'},
    {id:'U05',name:'กิตติศักดิ์ แสนสุข',role:'ผู้ใช้งานทั่วไป',dept:'แผนกห้องผ่าตัดและจ่ายกลาง',email:'kitti@paolokaset.co.th',status:'อนุมัติแล้ว',regDate:'2026-03-02'},
    {id:'U06',name:'วราภรณ์ ทองแท้',role:'ผู้ใช้งานทั่วไป',dept:'แผนกทรัพยากรบุคคล',email:'wara@paolokaset.co.th',status:'อนุมัติแล้ว',regDate:'2026-04-09'},
    {id:'U07',name:'ชัยวัฒน์ มณีรัตน์',role:'ผู้ใช้งานทั่วไป',dept:'หน่วยแม่บ้านและซักรีด',email:'chai@paolokaset.co.th',status:'รออนุมัติ',regDate:iso(addDays(TODAY,-4))},
    {id:'U08',name:'อรุณี สว่างจิต',role:'ผู้ใช้งานทั่วไป',dept:'หน่วยเภสัชกรรมผู้ป่วยใน',email:'arunee@paolokaset.co.th',status:'รออนุมัติ',regDate:iso(addDays(TODAY,-1))}
  ];

  /* ---- events (accident / near miss / incident) ---- */
  S.events=[]; S.actions=[];
  const evSeed=[
    {k:'accident',d:-8,dept:'แผนกห้องผ่าตัดและจ่ายกลาง',loc:'OR 3 — โซนล้างเครื่องมือ',type:'ของมีคมบาด/ทิ่มตำ',sev:'ปานกลาง',pt:'พนักงาน',desc:'พยาบาลถูกเข็ม Suture ทิ่มนิ้วชี้ขณะเก็บเครื่องมือหลังผ่าตัด',ia:'ล้างแผลด้วยน้ำสะอาด ส่งพบแพทย์ ประเมินความเสี่ยงติดเชื้อ',rc:'ไม่ได้ใช้ Needle holder ในการเก็บเข็ม และภาชนะทิ้งของมีคมเต็มเกิน 3/4',ca:'เปลี่ยนภาชนะทิ้งของมีคมทุกจุดเมื่อถึงระดับ 3/4 และติดสติกเกอร์เส้นระดับ',pa:'อบรมทบทวน Sharp Safety ทีมห้องผ่าตัดทุกไตรมาส',lti:1},
    {k:'accident',d:-27,dept:'หน่วยแม่บ้านและซักรีด',loc:'ทางเดินหน้าลิฟต์ อาคาร B ชั้น 1',type:'ลื่น/สะดุด/หกล้ม',sev:'เล็กน้อย',pt:'พนักงาน',desc:'พนักงานทำความสะอาดลื่นล้มบริเวณพื้นเปียกหลังถูพื้น',ia:'ปฐมพยาบาล ประคบเย็น วางป้ายระวังพื้นลื่นเพิ่ม',rc:'วางป้ายเตือนไม่ครอบคลุมพื้นที่ และรองเท้ากันลื่นหมดอายุการใช้งาน',ca:'จัดซื้อรองเท้ากันลื่นใหม่ทั้งหน่วยงาน 24 คู่',pa:'กำหนดมาตรฐานการวางป้ายเตือน 3 จุดต่อพื้นที่ถูพื้น',lti:0},
    {k:'accident',d:-63,dept:'หน่วยโภชนาการ',loc:'ครัวหลัก — เตาต้ม',type:'ความร้อน/ลวก',sev:'ปานกลาง',pt:'พนักงาน',desc:'น้ำเดือดกระเด็นใส่แขนขณะยกหม้อซุป',ia:'ล้างน้ำเย็น 15 นาที ส่งห้องฉุกเฉินทำแผล',rc:'ไม่สวมถุงมือกันความร้อนแบบยาว และหม้อบรรจุเกินระดับที่กำหนด',ca:'จัดหาถุงมือกันความร้อนยาวถึงข้อศอก 10 คู่',pa:'กำหนดระดับบรรจุสูงสุดของหม้อต้มที่ 80%',lti:1},
    {k:'accident',d:-121,dept:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',loc:'ห้องเครื่องปรับอากาศ ดาดฟ้าอาคาร B',type:'ไฟฟ้า',sev:'รุนแรง',pt:'ผู้รับเหมา',desc:'ช่างผู้รับเหมาถูกไฟฟ้าดูดขณะซ่อมตู้ควบคุม เนื่องจากไม่ได้ตัดระบบ',ia:'ตัดไฟทันที ปฐมพยาบาล ส่งห้องฉุกเฉิน สังเกตอาการ 24 ชม.',rc:'ไม่ปฏิบัติตามระบบ Lock Out Tag Out และไม่มีผู้ควบคุมงานหน้างาน',ca:'บังคับใช้ใบอนุญาตทำงาน (Work Permit) กับงานไฟฟ้าทุกงาน 100%',pa:'อบรมความปลอดภัยผู้รับเหมาก่อนเข้าพื้นที่ทุกราย',lti:5},
    {k:'near_miss',d:-3,dept:'หน่วยเภสัชกรรมผู้ป่วยใน',loc:'ห้องจัดยาผู้ป่วยใน',type:'สัมผัสสารเคมี',sev:'เล็กน้อย',pt:'พนักงาน',desc:'ขวดยาเคมีบำบัดเกือบตกจากชั้นวางที่ไม่มีขอบกั้น',ia:'ย้ายยาลงชั้นล่าง ติดตั้งขอบกั้นชั่วคราว',rc:'ชั้นวางไม่มีขอบกันตกและจัดเก็บสูงเกินระดับสายตา',ca:'ติดตั้งขอบกันตกชั้นวางยาเคมีบำบัดทุกชั้น',pa:'ทบทวนผังการจัดเก็บยาความเสี่ยงสูงทั้งหมด',lti:0},
    {k:'near_miss',d:-11,dept:'แผนกฉุกเฉินและรถพยาบาล',loc:'ทางเข้ารถพยาบาล อาคาร A',type:'ถูกกระแทก/ชน',sev:'ปานกลาง',pt:'ผู้มาเยือน',desc:'รถเข็นผู้ป่วยไหลลงทางลาดเกือบชนญาติผู้ป่วย',ia:'หยุดรถเข็นทัน จัดคนประจำจุดทางลาด',rc:'รถเข็น 4 คันมีเบรกชำรุด และทางลาดชันเกินมาตรฐาน',ca:'ตรวจสอบและซ่อมเบรกรถเข็นทั้งโรงพยาบาล',pa:'จัดทำแผนบำรุงรักษารถเข็นทุก 3 เดือน',lti:0},
    {k:'near_miss',d:-19,dept:'หน่วยบริหารสินค้าคงคลังและโลจิสติกส์',loc:'ห้องเก็บของ อาคาร C ชั้น 1',type:'ยกของ/ท่าทางการทำงาน',sev:'เล็กน้อย',pt:'พนักงาน',desc:'กล่องเวชภัณฑ์วางซ้อนสูงเกือบล้มทับขณะหยิบของ',ia:'จัดเรียงใหม่ ลดความสูงการวางซ้อน',rc:'ไม่มีการกำหนดความสูงสูงสุดในการวางซ้อน',ca:'ติดป้ายกำหนดความสูงการวางซ้อนไม่เกิน 1.5 เมตร',pa:'อบรมการจัดเก็บวัสดุอย่างปลอดภัย',lti:0},
    {k:'incident',d:-5,dept:'แผนกบริการทรัพยากรการแพทย์',loc:'ห้องเตรียมสารเคมี',type:'สัมผัสสารเคมี',sev:'ปานกลาง',pt:'พนักงาน',desc:'สารละลาย Xylene หกบนโต๊ะปฏิบัติการ ปริมาณ 200 มล.',ia:'ใช้ชุด Spill Kit เก็บกู้ เปิดระบบระบายอากาศ',rc:'ภาชนะบรรจุไม่มีฝาปิดนิรภัย และไม่ใช้ถาดรองสารเคมี',ca:'จัดหาถาดรองสารเคมีทุกจุดปฏิบัติงาน',pa:'ทบทวน SDS และวิธีปฏิบัติงานกับตัวทำละลาย',lti:0},
    {k:'incident',d:-14,dept:'แผนกรังสี',loc:'ห้อง CT Scan อาคาร E ชั้น 1',type:'ไฟฟ้า',sev:'เล็กน้อย',pt:'พนักงาน',desc:'ไฟฟ้าดับฉุกเฉิน ระบบสำรองจ่ายไฟล่าช้า 40 วินาที',ia:'หยุดการตรวจชั่วคราว ตรวจสอบระบบ UPS',rc:'แบตเตอรี่ UPS เสื่อมสภาพเกินอายุใช้งาน 5 ปี',ca:'เปลี่ยนแบตเตอรี่ UPS ห้องรังสี 2 ชุด',pa:'จัดทำทะเบียนอายุการใช้งาน UPS ทุกจุด',lti:0},
    {k:'incident',d:-33,dept:'แผนกผู้ป่วยในอายุรกรรม Ward B7',loc:'ห้องพักผู้ป่วย B712',type:'ลื่น/สะดุด/หกล้ม',sev:'ปานกลาง',pt:'ผู้ป่วย',desc:'ผู้ป่วยลื่นล้มในห้องน้ำ ไม่มีบาดเจ็บรุนแรง',ia:'ประเมินอาการ แจ้งแพทย์เจ้าของไข้ ติดตามอาการ',rc:'ราวจับในห้องน้ำหลวม และแผ่นกันลื่นเสื่อมสภาพ',ca:'ตรวจสอบราวจับและแผ่นกันลื่นห้องน้ำผู้ป่วยทุกห้อง',pa:'บรรจุเข้าแผน Preventive Maintenance รายเดือน',lti:0},
    {k:'incident',d:-48,dept:'แผนกผู้ป่วยนอกประกันสังคมทั่วไป',loc:'จุดคัดกรอง อาคาร A ชั้น 1',type:'ถูกทำร้ายร่างกาย',sev:'ปานกลาง',pt:'พนักงาน',desc:'ผู้รับบริการมีพฤติกรรมก้าวร้าว ผลักเจ้าหน้าที่คัดกรอง',ia:'แจ้งหน่วยรักษาความปลอดภัย แยกพื้นที่ บันทึกเหตุการณ์',rc:'จุดคัดกรองไม่มีปุ่มฉุกเฉินและเจ้าหน้าที่รักษาความปลอดภัยประจำจุด',ca:'ติดตั้งปุ่มแจ้งเหตุฉุกเฉินที่จุดคัดกรอง 4 จุด',pa:'อบรมการจัดการผู้รับบริการก้าวร้าวให้เจ้าหน้าที่ด่านหน้า',lti:0},
    {k:'accident',d:-198,dept:'หน่วยบริหารสินค้าคงคลังและโลจิสติกส์',loc:'ลานรับของ อาคาร D ชั้น 1',type:'ยกของ/ท่าทางการทำงาน',sev:'ปานกลาง',pt:'พนักงาน',desc:'ปวดหลังเฉียบพลันขณะยกกล่องน้ำยา 22 กก.',ia:'พักงาน ส่งกายภาพบำบัด',rc:'ยกของหนักเกินเกณฑ์คนเดียว ไม่มีอุปกรณ์ช่วยยก',ca:'จัดหารถเข็นยกของ 2 คัน ประจำลานรับของ',pa:'กำหนดน้ำหนักยกสูงสุดต่อคน 15 กก.',lti:3}
  ];
  evSeed.forEach((e,i)=>{
    const date=iso(addDays(TODAY,e.d));
    const id=(e.k==='accident'?'ACC':e.k==='near_miss'?'NM':'INC')+'-'+date.slice(0,4)+'-'+pad(i+1);
    const closed=e.d<-30;
    S.events.push({
      id:id, kind:e.k, date:date, time:pad(ri(7,20))+':'+pick(['05','15','20','30','40','45','55'],i),
      dept:e.dept, location:e.loc, type:e.type, severity:e.sev, personType:e.pt, person:pick(PEOPLE,i+2),
      description:e.desc, immediate:e.ia, rootCause:e.rc, corrective:e.ca, preventive:e.pa,
      owner:pick(PEOPLE,i), due:iso(addDays(new Date(date),21)),
      status: closed?'Closed':(i%3===0?'In Progress':'Open'), lostDays:e.lti,
      injuryClass: e.k!=='accident' ? (e.k==='near_miss'?'Near Miss':'Incident') : (e.lti>0?'Lost Time Injury': (e.sev==='เล็กน้อย'?'First Aid Case':'Recordable Injury')),
      timeline:[
        {t:date+' '+pad(ri(7,20))+':00',title:'รับแจ้งเหตุ',by:pick(PEOPLE,i+1),done:true},
        {t:iso(addDays(new Date(date),1)),title:'ดำเนินการแก้ไขเบื้องต้น',by:pick(PEOPLE,i+3),done:true},
        {t:iso(addDays(new Date(date),4)),title:'วิเคราะห์สาเหตุราก (RCA)',by:'คณะกรรมการความปลอดภัย',done:true},
        {t:iso(addDays(new Date(date),21)),title:closed?'ปิดเคสและติดตามผล':'รอผลการแก้ไขเชิงป้องกัน',by:pick(PEOPLE,i),done:closed}
      ],
      whys:[e.desc,'ผู้ปฏิบัติงานไม่ได้ปฏิบัติตามขั้นตอนที่กำหนด','ขั้นตอนปฏิบัติงานไม่ได้ถูกทบทวนหลังปรับผังงาน','ไม่มีผู้รับผิดชอบทบทวนเอกสารเมื่อมีการเปลี่ยนแปลง',e.rc],
      fishbone:{'คน':['ขาดการทบทวนความรู้','ความเร่งรีบในช่วงเวรบ่าย'],'วิธีการ':['ขั้นตอนไม่ครอบคลุมงานจริง','ไม่มีการตรวจสอบซ้ำ'],
        'เครื่องมือ':['อุปกรณ์เสื่อมสภาพ','ขาดอุปกรณ์ช่วยงาน'],'สภาพแวดล้อม':['แสงสว่างไม่พอ','พื้นที่ทำงานคับแคบ'],
        'วัสดุ':['วัสดุไม่ได้มาตรฐาน'],'การบริหาร':['ความถี่ตรวจสอบไม่เพียงพอ']},
      files:['รายงานเหตุการณ์.pdf','ภาพถ่ายจุดเกิดเหตุ.jpg']
    });
    S.actions.push({id:uid('CA'),source:e.k==='accident'?'Accident':(e.k==='near_miss'?'Near Miss':'Incident'),ref:id,
      finding:e.rc,risk:e.sev==='รุนแรง'?'สูงมาก':(e.sev==='ปานกลาง'?'สูง':'ปานกลาง'),
      owner:pick(PEOPLE,i),due:iso(addDays(new Date(date),21)),dept:e.dept,
      status:closed?'Closed':(i%4===0?'Overdue':(i%3===0?'In Progress':'Open')),
      progress:closed?100:[20,45,70,0][i%4],detail:e.ca,created:date,photoAfter:closed?1:0});
  });

  /* ---- Safety Round (ตามแบบฟอร์ม Excel) ---- */
  S.rounds=[];
  const rSeed=[
    ['2026-08-31','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','อาคาร A ชั้น 4','คกก.ENV','ติดม่านบังมุมของกล้องวงจรปิด และมีการจัดวางสิ่งของกีดขวางบริเวณประตูหนีไฟ','ปานกลาง','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','ดำเนินการเสร็จสิ้น','2026-09-01','จัดเก็บสิ่งของและเปิดมุมกล้องเรียบร้อย',''],
    ['2026-08-31','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','อาคาร A ชั้น 4','คกก.ENV','ทิ้งเข็มในถังเกิน 3/4 ของถัง และมีเข็มค้างบริเวณฝาถัง เสี่ยงต่อการเกิดอุบัติเหตุจากของมีคม','ปานกลาง','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','ดำเนินการเสร็จสิ้น','2026-09-01','เปลี่ยนถังทิ้งของมีคมและกำหนดผู้ตรวจสอบระดับทุกเวร',''],
    ['2026-08-31','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','อาคาร A ชั้น 4','คกก.ENV','เก็บอาหารปะปนกับยาในตู้เย็น และไม่มีการลงบันทึกอุณหภูมิ','ต่ำ','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','ดำเนินการเสร็จสิ้น','2026-09-01','นำตู้เย็นแช่ยาออกจากแผนก','ฝ่ายการพยาบาลกำหนดแผนกที่มีตู้เย็นแช่ยา ได้แก่ แผนกผู้ป่วยวิกฤต และห้องคลอด'],
    ['2026-08-31','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','อาคาร A ชั้น 4','คกก.ENV','พบจานและอุปกรณ์ล้างจานส่วนตัวบริเวณซิงค์น้ำ เนื่องจากซิงค์ดังกล่าวไม่มีการแยกใช้งาน','ต่ำ','แผนกผู้ป่วยนอกสูตินรีเวชและห้องคลอด','ยังไม่เริ่มดำเนินการ','','',''],
    ['2026-08-31','แผนกผู้ป่วยนอกอายุรกรรม 1','อาคาร A ชั้น 3','คกก.ENV','ไม่มีผ้าม่านกั้นบริเวณเตียงตรวจ','ปานกลาง','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม','อยู่ระหว่างดำเนินการ','','',''],
    ['2026-08-31','แผนกผู้ป่วยนอกอายุรกรรม 1','อาคาร A ชั้น 3','คกก.ENV','ทางหนีไฟเดิมยังไม่มีป้ายระบุ “เฉพาะเจ้าหน้าที่”','ปานกลาง','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม','อยู่ระหว่างดำเนินการ','','',''],
    ['2026-08-31','แผนกรังสี','อาคาร E ชั้น 1','คกก.ENV','ห้อง X-ray ไม่มีการควบคุมอุณหภูมิที่เหมาะสมต่อการใช้งานและการเก็บรักษาเครื่องมือ','สูง','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม','ยังไม่เริ่มดำเนินการ','','','รอผลการประเมินระบบปรับอากาศจากผู้รับเหมา']
  ];
  const genIssues=[
    ['ถังดับเพลิงถูกวางสิ่งของกีดขวาง ไม่สามารถหยิบใช้ได้ทันที','สูง'],
    ['ป้ายทางออกฉุกเฉินไฟส่องสว่างดับ 2 จุด','สูง'],
    ['สายไฟต่อพ่วงหลายชั้นบริเวณเคาน์เตอร์พยาบาล','สูง'],
    ['ถังขยะติดเชื้อไม่มีฝาปิดมิดชิด','ปานกลาง'],
    ['จัดเก็บกล่องเวชภัณฑ์สูงเกินระดับที่กำหนด บดบังหัวสปริงเกอร์','ปานกลาง'],
    ['ไม่มีป้ายชี้บ่งสารเคมีตามระบบ GHS ที่จุดจัดเก็บ','ปานกลาง'],
    ['พื้นห้องน้ำผู้ป่วยลื่น แผ่นกันลื่นเสื่อมสภาพ','ปานกลาง'],
    ['ราวจับห้องน้ำหลวม เสี่ยงต่อการพลัดตกหกล้ม','สูง'],
    ['ไม่มีบันทึกการตรวจสอบอุปกรณ์ฉุกเฉินประจำเดือน','ต่ำ'],
    ['ตู้ควบคุมไฟฟ้าไม่ได้ปิดล็อกและไม่มีป้ายเตือน','สูง'],
    ['ถังก๊าซทางการแพทย์ไม่มีโซ่ยึดตรึง','สูง'],
    ['แสงสว่างบริเวณทางเดินไม่เพียงพอ','ต่ำ'],
    ['อุปกรณ์ล้างตาฉุกเฉินไม่ได้ทดสอบตามกำหนด','ปานกลาง'],
    ['วางสิ่งของกีดขวางทางเดินหนีไฟ','สูง'],
    ['ไม่สวมอุปกรณ์ป้องกันส่วนบุคคลขณะปฏิบัติงานกับสารเคมี','ปานกลาง'],
    ['ระบบระบายอากาศในห้องเก็บของมีกลิ่นอับ','ต่ำ'],
    ['สายออกซิเจนวางพาดพื้น เสี่ยงสะดุดล้ม','ปานกลาง'],
    ['ไม่มีป้ายพิกัดน้ำหนักบนชั้นวางของในคลัง','ต่ำ']
  ];
  rSeed.forEach((r,i)=>{
    S.rounds.push({id:'SR-'+r[0].slice(0,4)+'-'+pad(i+1),date:r[0],dept:r[1],building:r[2],inspector:r[3],
      issue:r[4],risk:r[5],owner:r[6],due:iso(addDays(new Date(r[0]),r[5]==='สูง'?14:30)),
      photo:1,status:r[7],doneDate:r[8],photoAfter:r[9]?1:0,fixDetail:r[9],note:r[10]});
  });
  genIssues.forEach((g,i)=>{
    const date=iso(addDays(TODAY,-(ri(5,300))));
    const st=rnd();
    const status= st>0.55?'ดำเนินการเสร็จสิ้น':(st>0.28?'อยู่ระหว่างดำเนินการ':(st>0.08?'ยังไม่เริ่มดำเนินการ':'ไม่สามารถดำเนินการได้'));
    const done=status==='ดำเนินการเสร็จสิ้น';
    S.rounds.push({id:'SR-'+date.slice(0,4)+'-'+pad(i+8),date:date,dept:rp(DEPTS),building:rp(BUILDINGS),
      inspector:rp(INSPECTORS),issue:g[0],risk:g[1],owner:rp(DEPTS),
      due:iso(addDays(new Date(date),g[1]==='สูง'?14:30)),photo:1,status:status,
      doneDate:done?iso(addDays(new Date(date),ri(3,25))):'',photoAfter:done?1:0,
      fixDetail:done?'ดำเนินการแก้ไขและตรวจสอบซ้ำโดยคณะกรรมการความปลอดภัย':'',note:''});
  });
  S.rounds.sort((a,b)=>b.date.localeCompare(a.date));
  S.rounds.forEach(r=>{
    S.actions.push({id:uid('CA'),source:'Safety Round',ref:r.id,finding:r.issue,
      risk:r.risk==='สูง'?'สูง':(r.risk==='ปานกลาง'?'ปานกลาง':'ต่ำ'),owner:r.owner,due:r.due,dept:r.dept,
      status: r.status==='ดำเนินการเสร็จสิ้น'?'Closed':(new Date(r.due)<TODAY?'Overdue':(r.status==='อยู่ระหว่างดำเนินการ'?'In Progress':'Open')),
      progress: r.status==='ดำเนินการเสร็จสิ้น'?100:(r.status==='อยู่ระหว่างดำเนินการ'?ri(30,80):0),
      detail:r.fixDetail||'แก้ไขประเด็นที่พบจากการตรวจ Safety Round',created:r.date,photoAfter:r.photoAfter});
  });

  /* ---- KPI ---- */
  const kpiDef=[
    ['ร้อยละเครื่องมือแพทย์ได้รับการบำรุงรักษาตามแผนที่กำหนด',100,'%','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',[92,95,90,96,98,94,97,99,96,95,98,97]],
    ['จำนวนครั้งของอุบัติการณ์ความไม่พร้อมใช้งานในเครื่องมือเสี่ยงสูง',0,'ครั้ง','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',[1,0,0,2,0,0,1,0,0,0,1,0]],
    ['อัตราซ้อมแผนอัคคีภัยอย่างน้อย 1 ครั้ง/ปี',100,'%','หน่วยบริหารความปลอดภัย อาชีวอนามัยและสิ่งแวดล้อม',[0,0,0,100,100,100,100,100,100,100,100,100]],
    ['อัตราเครื่องสำรองไฟทำงานภายใน 7 วินาทีหลังไฟดับ',100,'%','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',[100,100,100,100,50,100,100,100,100,100,100,100]],
    ['จำนวนครั้งการตรวจพบเชื้อก่อโรคในน้ำใช้',0,'ครั้ง','บริหารคุณภาพและความปลอดภัย ควบคุมและป้องกันการติดเชื้อ',[0,0,1,0,0,0,0,0,0,1,0,0]],
    ['จำนวนครั้งการตรวจพบเชื้อก่อโรคในน้ำดื่ม',0,'ครั้ง','บริหารคุณภาพและความปลอดภัย ควบคุมและป้องกันการติดเชื้อ',[0,0,0,0,0,0,0,0,0,0,0,0]],
    ['อัตราผลการตรวจค่า BOD ผ่านตามเกณฑ์มาตรฐาน',100,'%','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',[100,100,100,0,100,100,100,100,0,100,100,100]],
    ['ผลการตรวจน้ำเสียผ่านตามเกณฑ์มาตรฐาน',100,'%','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',[100,100,100,0,100,100,100,100,0,100,100,100]],
    ['อัตราการหมุนเวียนอากาศ (Air Change Rate) ในพื้นที่ที่กำหนด',100,'%','แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',[88,90,92,94,91,93,95,96,94,95,97,96]]
  ];
  S.kpis=kpiDef.map((k,i)=>{
    const actual=k[4][TODAY.getMonth()];
    const lower = k[2]==='ครั้ง';
    const ach= lower ? (actual<=k[1]?100:Math.max(0,100-actual*25)) : Math.round(actual/k[1]*100);
    return {id:'KPI-'+pad(i+1),name:k[0],desc:'เป้าหมาย '+(lower?'ไม่เกิน ':'')+k[1]+' '+k[2],target:k[1],unit:k[2],
      actual:actual,months:k[4],lower:lower,achievement:Math.min(ach,130),owner:k[3],
      year:TODAY.getFullYear(),month:TODAY.getMonth()+1,
      status: ach>=100?'บรรลุเป้าหมาย':(ach>=90?'เฝ้าระวัง':'ต่ำกว่าเป้าหมาย')};
  });

  /* ---- Waste (รายเดือน) ---- */
  S.waste=[];
  for(let m=11;m>=0;m--){
    const d=new Date(TODAY.getFullYear(),TODAY.getMonth()-m,1);
    WASTE_TYPES.forEach(t=>{
      const base={'ขยะทั่วไป':[2600,3400],'ขยะติดเชื้อ':[1100,1600],'ขยะอันตราย':[70,150],'ขยะรีไซเคิล':[400,760],'ขยะเคมี':[35,90]}[t];
      S.waste.push({id:uid('WS'),month:ym(d),type:t,qty:ri(base[0],base[1]),unit:'กก.',
        recorder:rp(PEOPLE),
        method: t==='ขยะติดเชื้อ'?'เผาในเตาเผาขยะติดเชื้อ':(t==='ขยะรีไซเคิล'?'ส่งจำหน่ายผู้รับซื้อ':(t==='ขยะเคมี'||t==='ขยะอันตราย'?'ส่งกำจัดโดยผู้รับอนุญาต':'ฝังกลบ/เทศบาล')),
        vendor: t==='ขยะทั่วไป'?'สำนักงานเขตจตุจักร':(t==='ขยะรีไซเคิล'?'บจก. รีไซเคิลไทย':'บจก. เบตเตอร์ เวิลด์ กรีน')});
    });
  }

  /* ---- Wastewater (รายเดือน ตามพารามิเตอร์มาตรฐาน) ---- */
  S.wastewater=[];
  for(let m=11;m>=0;m--){
    const d=new Date(TODAY.getFullYear(),TODAY.getMonth()-m,1);
    const bad=(m===8||m===3);
    const r={id:uid('WW'),month:ym(d),appearance: bad?'มีตะกอนแขวนลอยเล็กน้อย':'ใส ไม่มีกลิ่น',
      ph:Number((6.6+rnd()*1.6+(bad?1.4:0)).toFixed(2)),
      bod:Math.round(6+rnd()*10+(bad?16:0)), tss:Math.round(8+rnd()*14+(bad?22:0)),
      tds:Math.round(420+rnd()*380), settleable:Number((0.1+rnd()*0.25).toFixed(2)),
      sulfide:Number((0.1+rnd()*0.5).toFixed(2)), tkn:Math.round(8+rnd()*18+(bad?16:0)),
      oil:Number((2+rnd()*8+(bad?14:0)).toFixed(1)),
      totalColiform:Math.round(400+rnd()*2600), fecalColiform:Math.round(120+rnd()*600),
      chlorine:Number((0.3+rnd()*0.6).toFixed(2)), cod:Math.round(30+rnd()*55+(bad?70:0)),
      ecoli:Math.round(90+rnd()*550), parasite:0,
      lab:'บจก. ห้องปฏิบัติการกลาง (ประเทศไทย)', by:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม', file:'ผลตรวจน้ำทิ้ง_'+ym(d)+'.pdf',
      fix:null};
    r.fails=wwFails(r); r.result=r.fails.length?'ไม่ผ่าน':'ผ่าน';
    if(r.fails.length){
      r.fix={detail:'ล้างบ่อดักไขมันและปรับอัตราการเติมอากาศ เพิ่มความถี่การเติมคลอรีน พร้อมสุ่มตรวจซ้ำ',
        date:iso(addDays(new Date(d.getFullYear(),d.getMonth(),20),10)),by:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',
        file:'ผลตรวจซ้ำ_'+ym(d)+'.pdf', status: m>4?'แก้ไขแล้ว':'อยู่ระหว่างแก้ไข'};
      S.actions.push({id:uid('CA'),source:'Wastewater',ref:r.id,
        finding:'ผลตรวจน้ำเสียเดือน '+thMonth(r.month)+' เกินมาตรฐาน: '+r.fails.join(', '),risk:'สูง',
        owner:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',due:iso(addDays(new Date(d.getFullYear(),d.getMonth(),25),20)),
        dept:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',status:m>4?'Closed':'In Progress',progress:m>4?100:60,
        detail:r.fix.detail,created:ym(d)+'-25',photoAfter:m>4?1:0});
    }
    S.wastewater.push(r);
  }
  S.wastewater.sort((a,b)=>b.month.localeCompare(a.month));

  /* ---- Inspections ---- */
  S.inspections=[
    {id:'INS-01',date:iso(addDays(TODAY,-22)),agency:'สำนักงานสวัสดิการและคุ้มครองแรงงานกรุงเทพมหานคร',type:'หน่วยงานราชการ',topic:'การตรวจสภาพการจ้างและความปลอดภัยในการทำงาน',
     finding:'ทะเบียนเจ้าหน้าที่ความปลอดภัยระดับเทคนิคขั้นสูงยังไม่ครบตามจำนวนลูกจ้าง',severity:'ปานกลาง',rec:'จัดส่งพนักงานเข้าอบรมและขึ้นทะเบียนเพิ่ม 2 คน ภายใน 90 วัน',
     ca:'ส่งอบรม จป.เทคนิคขั้นสูง รุ่นเดือนหน้า 2 คน',owner:'สุภาพร ใจดีงาม',due:iso(addDays(TODAY,68)),status:'In Progress',files:['หนังสือแจ้งผลการตรวจ.pdf']},
    {id:'INS-02',date:iso(addDays(TODAY,-47)),agency:'สถาบันรับรองคุณภาพสถานพยาบาล (สรพ.)',type:'Hospital Accreditation',topic:'ENV — ระบบสิ่งแวดล้อมและความปลอดภัยทางกายภาพ',
     finding:'แผนซ้อมอพยพหนีไฟยังไม่ครอบคลุมเวรบ่าย-ดึก',severity:'สูง',rec:'จัดซ้อมอพยพนอกเวลาราชการอย่างน้อยปีละ 1 ครั้ง',
     ca:'กำหนดแผนซ้อมอพยพเวรดึก เดือนหน้า',owner:'ณัฐวุฒิ พงษ์สวัสดิ์',due:iso(addDays(TODAY,25)),status:'In Progress',files:['รายงานผลเยี่ยมสำรวจ.pdf','ภาพประกอบ.jpg']},
    {id:'INS-03',date:iso(addDays(TODAY,-75)),agency:'สำนักอนามัย กรุงเทพมหานคร',type:'Environmental / Safety Inspection',topic:'ระบบบำบัดน้ำเสียและการจัดการมูลฝอยติดเชื้อ',
     finding:'เอกสารกำกับการขนส่งมูลฝอยติดเชื้อจัดเก็บไม่ครบ 2 เดือน',severity:'ปานกลาง',rec:'จัดทำแฟ้มทะเบียนเอกสารกำกับการขนส่งให้เป็นปัจจุบัน',
     ca:'จัดทำระบบทะเบียนเอกสารอิเล็กทรอนิกส์',owner:'ชัยวัฒน์ มณีรัตน์',due:iso(addDays(TODAY,-5)),status:'Overdue',files:['บันทึกตรวจ.pdf']},
    {id:'INS-04',date:iso(addDays(TODAY,-110)),agency:'คณะกรรมการตรวจสอบภายใน',type:'Internal Audit',topic:'การบริหารความเสี่ยงด้านอัคคีภัย',
     finding:'ถังดับเพลิง 6 จุด เลยกำหนดตรวจสอบประจำเดือน',severity:'เล็กน้อย',rec:'กำหนดผู้รับผิดชอบตรวจสอบรายเดือนและบันทึกผล',
     ca:'มอบหมายแผนกวิศวกรรมตรวจสอบและบันทึกผลทุกวันที่ 5',owner:'ธนกฤต ศรีวิชัย',due:iso(addDays(TODAY,-60)),status:'Closed',files:['รายงานตรวจสอบภายใน.pdf']},
    {id:'INS-05',date:iso(addDays(TODAY,-150)),agency:'บริษัทผู้ตรวจสอบอาคารที่ได้รับอนุญาต',type:'External Audit',topic:'การตรวจสอบอาคารประจำปีตามกฎหมาย',
     finding:'ระบบไฟส่องสว่างฉุกเฉินบันไดหนีไฟชำรุด 4 จุด',severity:'สูง',rec:'ซ่อมแซมและทดสอบระบบไฟฉุกเฉินทุก 6 เดือน',
     ca:'เปลี่ยนโคมไฟฉุกเฉิน 4 จุด และทดสอบระบบ',owner:'ธนกฤต ศรีวิชัย',due:iso(addDays(TODAY,-100)),status:'Closed',files:['รายงานตรวจสอบอาคาร.pdf']}
  ];
  S.inspections.forEach(x=>{ if(x.status!=='Closed') S.actions.push({id:uid('CA'),source:'Inspection',ref:x.id,
    finding:x.finding,risk:x.severity==='สูง'?'สูง':'ปานกลาง',owner:x.owner,due:x.due,dept:'แผนกธุรการ',
    status:x.status,progress:x.status==='Overdue'?35:60,detail:x.ca,created:x.date,photoAfter:0}); });

  /* ---- Training (พนักงานใหม่ / ผู้รับเหมา) ---- */
  S.trainings=[];
  for(let m=11;m>=0;m--){
    const base=new Date(TODAY.getFullYear(),TODAY.getMonth()-m,1);
    const d1=iso(new Date(base.getFullYear(),base.getMonth(),ri(3,12)));
    S.trainings.push({id:uid('TN'),type:TRAIN_TYPES[0],date:d1,count:ri(4,18),
      topic:'ความปลอดภัยพื้นฐาน อาชีวอนามัย สิ่งแวดล้อม และการรายงานอุบัติการณ์',
      trainer:'หน่วยบริหารความปลอดภัย อาชีวอนามัยและสิ่งแวดล้อม',
      file:'ผลการอบรมพนักงานใหม่_'+ym(base)+'.xlsx',expiry:'',note:''});
    const n=m<3?2:1;
    for(let j=0;j<n;j++){
      const d2=iso(new Date(base.getFullYear(),base.getMonth(),ri(6,26)));
      S.trainings.push({id:uid('TC'),type:TRAIN_TYPES[1],date:d2,count:ri(3,14),
        topic:'กฎความปลอดภัยผู้รับเหมา การขออนุญาตทำงาน และการทำงานกับไฟฟ้า/ความร้อน',
        trainer:'หน่วยบริหารความปลอดภัย อาชีวอนามัยและสิ่งแวดล้อม',
        file:'ทะเบียนผู้รับเหมา_'+d2+'.xlsx',expiry:iso(addDays(new Date(d2),30)),
        note:'บริษัทผู้รับเหมา '+pick(['บจก. ไทยเอ็นจิเนียริ่ง','บจก. ซี.เอ็ม.เซอร์วิส','บจก. เพาเวอร์เทค','บจก. คลีนโปร'],j+m)});
    }
  }
  S.trainings.sort((a,b)=>b.date.localeCompare(a.date));

  /* ---- Safety officers ---- */
  const LEVELS=['จป.หัวหน้างาน','จป.เทคนิค','จป.เทคนิคขั้นสูง','จป.วิชาชีพ','จป.บริหาร'];
  S.officers=[]; const cnt={'จป.หัวหน้างาน':14,'จป.เทคนิค':5,'จป.เทคนิคขั้นสูง':2,'จป.วิชาชีพ':3,'จป.บริหาร':4}; let oi=0;
  LEVELS.forEach(lv=>{ for(let i=0;i<cnt[lv];i++){ oi++;
    const train=addDays(TODAY,-ri(120,1400));
    S.officers.push({id:'SO-'+pad(oi),name:pick(PEOPLE,oi),position:pick(['หัวหน้าพยาบาล','หัวหน้าแผนกวิศวกรรม','นักวิชาการสาธารณสุข','เจ้าพนักงานธุรการ','หัวหน้าแผนก','ผู้อำนวยการฝ่ายบริหาร'],oi),
      dept:pick(DEPTS,oi*5),level:lv,appointDate:iso(addDays(train,14)),trainDate:iso(train),
      regDate:iso(addDays(train,30)),regNo:'จป.'+(TODAY.getFullYear()+543-ri(0,4))+'/'+pad(oi)+pad(ri(10,99)),
      expiry:(lv==='จป.วิชาชีพ'||lv==='จป.เทคนิคขั้นสูง')?iso(addDays(train,ri(200,1460))):'',
      files:['หนังสือแต่งตั้ง.pdf','วุฒิบัตรการอบรม.pdf']});
  }});

  S.settings={role:'Safety Officer',user:'ณัฐวุฒิ พงษ์สวัสดิ์'};
  return S;
}
function wwFails(r){
  const f=[];
  WW_PARAMS.forEach(p=>{ if(p.text) return; const v=Number(r[p.k]);
    if(isNaN(v)) return;
    if(p.min!=null && v<p.min) f.push(p.label);
    else if(p.max!=null && v>p.max) f.push(p.label); });
  return f;
}

/* ---------- store ---------- */
const KEY='hsms.paolo.v1';
const Store={
  data:null,
  load(){ try{ const raw=localStorage.getItem(KEY); if(raw){ this.data=JSON.parse(raw); return; } }catch(e){}
    this.data=seed(); this.save(); },
  save(){ try{ localStorage.setItem(KEY,JSON.stringify(this.data)); }catch(e){} },
  reset(){ try{ localStorage.removeItem(KEY); }catch(e){} this.data=seed(); this.save(); }
};
const S=()=>Store.data;

/* ---------- derived metrics ---------- */
function lastAccident(){
  const a=S().events.filter(e=>e.kind==='accident').sort((x,y)=> y.date.localeCompare(x.date))[0];
  return a?a.date:iso(addDays(TODAY,-365));
}
function daysSafe(){ return Math.max(0,daysBetween(lastAccident(),iso(TODAY))); }
function inMonth(d,m,y){ const x=new Date(d); return x.getMonth()===m && x.getFullYear()===y; }
function thisYear(arr){ return arr.filter(r=>new Date(r.date).getFullYear()===TODAY.getFullYear()); }
/* IFR = จำนวนครั้งบาดเจ็บ × 1,000,000 / ชั่วโมงการทำงาน
   ISR = จำนวนวันสูญเสีย × 1,000,000 / ชั่วโมงการทำงาน */
function ifrIsr(){
  const y=thisYear(S().events.filter(e=>e.kind==='accident'));
  const inj=y.length, lost=y.reduce((s,e)=>s+(e.lostDays||0),0);
  return {inj:inj,lost:lost,
    ifr:Number((inj*1e6/HOURS_YEAR).toFixed(2)),
    isr:Number((lost*1e6/HOURS_YEAR).toFixed(2))};
}
function metrics(){
  const ev=S().events, ac=S().actions, rd=S().rounds;
  const monthEv=k=> ev.filter(e=>e.kind===k && inMonth(e.date,TODAY.getMonth(),TODAY.getFullYear())).length;
  const done=rd.filter(r=>r.status==='ดำเนินการเสร็จสิ้น').length;
  const kpiAvg=Math.round(S().kpis.reduce((s,k)=>s+Math.min(k.achievement,100),0)/S().kpis.length);
  const ww=S().wastewater[0];
  const curM=ym(TODAY);
  const tr=S().trainings;
  return {
    daysSafe:daysSafe(), accMonth:monthEv('accident'), nmMonth:monthEv('near_miss'), incMonth:monthEv('incident'),
    roundTotal:rd.length, roundDone:done, roundProgress:rd.filter(r=>r.status==='อยู่ระหว่างดำเนินการ').length,
    roundNotStart:rd.filter(r=>r.status==='ยังไม่เริ่มดำเนินการ').length,
    roundBlocked:rd.filter(r=>r.status==='ไม่สามารถดำเนินการได้').length,
    roundPct: rd.length?Math.round(done/rd.length*100):0,
    roundHigh: rd.filter(r=>r.risk==='สูง'&&r.status!=='ดำเนินการเสร็จสิ้น').length,
    roundOpen: rd.length-done,
    kpiAvg:kpiAvg, kpiOk:S().kpis.filter(k=>k.achievement>=100).length,
    actOpen:ac.filter(a=>a.status!=='Closed').length, actOverdue:ac.filter(a=>a.status==='Overdue').length,
    actClosed:ac.filter(a=>a.status==='Closed').length, actTotal:ac.length,
    newStaffTrained: tr.filter(t=>t.type===TRAIN_TYPES[0]).reduce((s,t)=>s+t.count,0),
    contractorTrained: tr.filter(t=>t.type===TRAIN_TYPES[1]).reduce((s,t)=>s+t.count,0),
    contractorExpiring: tr.filter(t=>t.type===TRAIN_TYPES[1]&&t.expiry&&daysBetween(iso(TODAY),t.expiry)>=0&&daysBetween(iso(TODAY),t.expiry)<=7).length,
    contractorActive: tr.filter(t=>t.type===TRAIN_TYPES[1]&&t.expiry&&daysBetween(iso(TODAY),t.expiry)>=0).reduce((s,t)=>s+t.count,0),
    wasteMonth: S().waste.filter(w=>w.month===curM).reduce((s,w)=>s+w.qty,0),
    infectiousMonth: S().waste.filter(w=>w.month===curM&&w.type==='ขยะติดเชื้อ').reduce((s,w)=>s+w.qty,0),
    wwLast: ww, wwFail: S().wastewater.filter(w=>w.result==='ไม่ผ่าน').length,
    insOpen:S().inspections.filter(i=>i.status!=='Closed').length,
    officers:S().officers.length, ifr:ifrIsr().ifr, isr:ifrIsr().isr
  };
}
function riskClass(r){ return r==='สูงมาก'?'b-red':r==='สูง'?'b-red':r==='ปานกลาง'?'b-amber':'b-blue'; }
function sevClass(s){ return (s==='วิกฤต'||s==='รุนแรง')?'b-red':s==='ปานกลาง'?'b-amber':'b-green'; }
function statClass(s){ return s==='Closed'?'b-green':s==='Overdue'?'b-red':s==='In Progress'?'b-blue':s==='Pending Verification'?'b-amber':'b-gray'; }
function statTh(s){ return {'Open':'เปิดงาน','In Progress':'กำลังดำเนินการ','Pending Verification':'รอตรวจสอบผล','Closed':'ปิดงานแล้ว','Overdue':'เกินกำหนด'}[s]||s; }
function roundStatClass(s){ return s==='ดำเนินการเสร็จสิ้น'?'b-green':s==='อยู่ระหว่างดำเนินการ'?'b-blue':s==='ไม่สามารถดำเนินการได้'?'b-red':'b-gray'; }

/* ---------- permissions ---------- */
const PERM={
  'Safety Officer':{write:true,label:'บันทึก แก้ไข และปิดงานได้ทุกโมดูล'},
  'ผู้ใช้งานทั่วไป':{write:false,label:'ดูข้อมูลและรายงานได้อย่างเดียว ไม่สามารถแก้ไข'}
};
const can=()=> !!(PERM[S().settings.role]||{}).write;
function guard(){ if(!can()){ toast('สิทธิ์ผู้ใช้งานทั่วไปดูข้อมูลได้อย่างเดียว — ต้องเป็น Safety Officer จึงจะแก้ไขได้',true); return false;} return true; }

/* ---------- notifications ---------- */
function buildNotifs(){
  const n=[]; const now=iso(TODAY);
  S().events.filter(e=>daysBetween(e.date,now)<=10).forEach(e=>n.push({
    level:e.kind==='accident'?'red':(e.kind==='near_miss'?'amber':'blue'),
    title:(e.kind==='accident'?'อุบัติเหตุใหม่':e.kind==='near_miss'?'รายงานเหตุเกือบเกิด':'อุบัติการณ์ใหม่')+' — '+e.dept,
    detail:e.description.slice(0,72)+'…', when:e.date, go:'#/zero-accident'}));
  S().rounds.filter(r=>r.risk==='สูง'&&r.status!=='ดำเนินการเสร็จสิ้น').slice(0,5).forEach(r=>n.push({
    level:'red',title:'ประเด็นความเสี่ยงสูงยังไม่ปิด — '+r.dept,detail:r.issue.slice(0,70),when:r.date,go:'#/patrol'}));
  S().actions.filter(a=>a.status==='Overdue').slice(0,5).forEach(a=>n.push({
    level:'red',title:'การแก้ไขเกินกำหนด — '+a.id,detail:a.finding.slice(0,70),when:a.due,go:'#/actions'}));
  S().actions.filter(a=>a.status!=='Closed'&&a.status!=='Overdue'&&daysBetween(now,a.due)>=0&&daysBetween(now,a.due)<=7).slice(0,5).forEach(a=>n.push({
    level:'amber',title:'ใกล้ถึงวันที่แล้วเสร็จ ('+daysBetween(now,a.due)+' วัน)',detail:a.finding.slice(0,70),when:a.due,go:'#/actions'}));
  S().trainings.filter(t=>t.expiry&&daysBetween(now,t.expiry)>=-7&&daysBetween(now,t.expiry)<=10).forEach(t=>n.push({
    level:daysBetween(now,t.expiry)<0?'red':'amber',
    title:daysBetween(now,t.expiry)<0?'การอบรมผู้รับเหมาหมดอายุแล้ว':'การอบรมผู้รับเหมาใกล้หมดอายุ',
    detail:t.note+' — อบรม '+t.count+' คน หมดอายุ '+thDate(t.expiry),when:t.expiry,go:'#/training'}));
  const ww=S().wastewater.filter(w=>w.result==='ไม่ผ่าน'&&(!w.fix||w.fix.status!=='แก้ไขแล้ว'));
  ww.forEach(w=>n.push({level:'red',title:'ผลตรวจน้ำเสียเกินมาตรฐาน',
    detail:thMonth(w.month)+' — '+w.fails.join(', '),when:w.month+'-25',go:'#/wastewater'}));
  S().inspections.filter(i=>i.status!=='Closed').forEach(i=>n.push({
    level:i.status==='Overdue'?'red':'blue',title:'ข้อสังเกตจากการตรวจประเมินยังไม่ปิด',
    detail:i.agency+' — '+i.finding.slice(0,60),when:i.due,go:'#/inspection'}));
  return n.sort((a,b)=>String(b.when).localeCompare(String(a.when)));
}

/* ---------- charts ---------- */
const charts={};
function destroyCharts(){ Object.keys(charts).forEach(k=>{ try{charts[k].destroy();}catch(e){} delete charts[k]; }); }
const C={navy:'#0B2C5C',blue:'#1E88E5',sky:'#7FB8EE',green:'#0E9F58',amber:'#E08700',red:'#D32F2F',gray:'#A7B6CC',teal:'#1BA7A0',purple:'#6B5BD2'};
function gridColor(){ return getComputedStyle(document.body).getPropertyValue('--line').trim()||'#E2E8F2'; }
function tickColor(){ return getComputedStyle(document.body).getPropertyValue('--muted').trim()||'#7789A1'; }
function mkChart(id,cfg){
  const el=document.getElementById(id); if(!el||typeof Chart==='undefined') return;
  cfg.options=Object.assign({responsive:true,maintainAspectRatio:false,
    plugins:{legend:{labels:{color:tickColor(),font:{family:'IBM Plex Sans Thai',size:11},boxWidth:10,boxHeight:10,usePointStyle:true,pointStyle:'circle'}},
      tooltip:{backgroundColor:'#0B2C5C',padding:10,titleFont:{family:'IBM Plex Sans Thai'},bodyFont:{family:'IBM Plex Sans Thai'},cornerRadius:8}},
    scales: cfg.type==='doughnut'||cfg.type==='pie'||cfg.type==='radar'?undefined:{
      x:{grid:{display:false},ticks:{color:tickColor(),font:{family:'IBM Plex Sans Thai',size:11}}},
      y:{grid:{color:gridColor()},border:{display:false},ticks:{color:tickColor(),font:{family:'IBM Plex Sans Thai',size:11}},beginAtZero:true}
    }},cfg.options||{});
  charts[id]=new Chart(el,cfg);
}
function last12(){ const o=[]; for(let m=11;m>=0;m--){ const d=new Date(TODAY.getFullYear(),TODAY.getMonth()-m,1); o.push({label:THMON[d.getMonth()],key:ym(d)}); } return o; }
function last12Labels(){ return last12().map(x=>x.label); }
function monthlyCount(arr,pred,dateKey){ const o=new Array(12).fill(0);
  arr.forEach(r=>{ if(pred&&!pred(r)) return; const d=new Date(r[dateKey||'date']);
    const diff=(TODAY.getFullYear()-d.getFullYear())*12+(TODAY.getMonth()-d.getMonth());
    if(diff>=0&&diff<12) o[11-diff]++; });
  return o; }
function monthlySum(arr,pred,valKey,dateKey){ const o=new Array(12).fill(0);
  arr.forEach(r=>{ if(pred&&!pred(r)) return; const d=new Date((r[dateKey||'date']||'')+(String(r[dateKey||'date']).length===7?'-01':''));
    const diff=(TODAY.getFullYear()-d.getFullYear())*12+(TODAY.getMonth()-d.getMonth());
    if(diff>=0&&diff<12) o[11-diff]+=Number(r[valKey]||0); });
  return o; }
function groupCount(arr,key){ const m={}; arr.forEach(r=>{ const k=typeof key==='function'?key(r):r[key]; m[k]=(m[k]||0)+1; }); return m; }

/* ---------- reusable UI ---------- */
function kpiCard(o){
  return '<div class="card kpi '+(o.tone||'info')+'"><div class="card-b">'+
    '<div class="row" style="justify-content:space-between;align-items:flex-start">'+
      '<div class="kpi-label">'+esc(o.label)+'</div>'+(o.icon?'<div class="kpi-ic">'+o.icon+'</div>':'')+'</div>'+
    '<div class="kpi-value">'+o.value+(o.unit?'<span class="unit">'+esc(o.unit)+'</span>':'')+'</div>'+
    (o.bar!=null?'<div class="prog '+(o.barTone||'')+'" style="margin-top:10px"><span style="width:'+Math.min(100,o.bar)+'%"></span></div>':'')+
    (o.foot?'<div class="kpi-foot">'+o.foot+'</div>':'')+'</div></div>';
}
function card(title,body,opts){ opts=opts||{};
  return '<section class="card '+(opts.cls||'')+'">'+
    (title?'<div class="card-h"><div><h3>'+esc(title)+'</h3>'+(opts.sub?'<div class="sub">'+esc(opts.sub)+'</div>':'')+'</div><div class="spacer"></div>'+(opts.actions||'')+'</div>':'')+
    (opts.raw? body : '<div class="card-b">'+body+'</div>')+'</section>';
}
function table(cols,rows,opts){ opts=opts||{};
  if(!rows.length) return '<div class="empty"><strong>'+esc(opts.emptyTitle||'ยังไม่มีข้อมูล')+'</strong>'+esc(opts.empty||'เริ่มต้นด้วยการบันทึกรายการแรก')+'</div>';
  return '<div class="tbl-wrap"><table><thead><tr>'+cols.map(c=>'<th'+(c.w?' style="width:'+c.w+'"':'')+'>'+esc(c.label)+'</th>').join('')+'</tr></thead><tbody>'+
    rows.map((r,i)=>'<tr>'+cols.map(c=>'<td'+(c.cls?' class="'+c.cls+'"':'')+'>'+(c.render?c.render(r,i):esc(r[c.key]))+'</td>').join('')+'</tr>').join('')+
  '</tbody></table></div>';
}
function badge(text,cls,plain){ return '<span class="badge '+(cls||'b-gray')+(plain?' plain':'')+'">'+esc(text)+'</span>'; }
function progress(p,tone){ return '<div class="row" style="gap:8px;min-width:120px"><div class="prog '+(tone||'')+'" style="flex:1"><span style="width:'+Math.min(100,p||0)+'%"></span></div><span class="tiny mono">'+(p||0)+'%</span></div>'; }
function chartCard(title,id,sub,h){ return card(title,'<div class="chart-box '+(h||'')+'"><canvas id="'+id+'"></canvas></div>',{sub:sub}); }
function photoTag(has,label){ return has?'<span class="badge b-blue plain tiny">'+esc(label)+'</span>':'<span class="tiny muted">—</span>'; }

/* icons */
const IC={
  shield:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
  alert:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>',
  clipboard:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 14l2 2 4-4"/></svg>',
  chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/></svg>',
  trash:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>',
  drop:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.7S6 9.4 6 14a6 6 0 0 0 12 0c0-4.6-6-11.3-6-11.3z"/></svg>',
  search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  book:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  badge:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="9" r="5"/><path d="M8.5 13 7 22l5-2.5L17 22l-1.5-9"/></svg>',
  file:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>',
  bell:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/></svg>',
  users:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M17 4.5a4 4 0 0 1 0 7M18 21h4a6 6 0 0 0-4-5.7"/></svg>',
  db:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5.5" rx="8" ry="3.2"/><path d="M4 5.5v13c0 1.8 3.6 3.2 8 3.2s8-1.4 8-3.2v-13"/><path d="M4 12c0 1.8 3.6 3.2 8 3.2s8-1.4 8-3.2"/></svg>',
  home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>',
  grid:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
  plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  wrench:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a4 4 0 0 0 5 5L21 21H3l9.7-9.7a4 4 0 0 0 5-5z"/></svg>',
  down:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v13M7 12l5 5 5-5M4 21h16"/></svg>'
};

/* ---------- navigation ---------- */
const NAV=[
  {group:'ภาพรวม',items:[{id:'home',label:'หน้าแรกผู้บริหาร',icon:IC.home},{id:'dashboard',label:'Safety Dashboard',icon:IC.grid}]},
  {group:'งานความปลอดภัย',items:[
    {id:'zero-accident',label:'Zero Accident',icon:IC.shield},
    {id:'accidents',label:'ฐานข้อมูลอุบัติเหตุ',icon:IC.alert},
    {id:'patrol',label:'Safety Round',icon:IC.clipboard},
    {id:'actions',label:'การแก้ไข (CAPA)',icon:IC.wrench,badgeKey:'actOverdue'},
    {id:'kpi',label:'ตัวชี้วัด KPI',icon:IC.chart}]},
  {group:'สิ่งแวดล้อม',items:[{id:'waste',label:'การจัดการขยะ',icon:IC.trash},{id:'wastewater',label:'น้ำเสีย',icon:IC.drop}]},
  {group:'บุคลากร',items:[{id:'training',label:'การอบรม',icon:IC.book},{id:'officers',label:'ทะเบียน จป.',icon:IC.badge}]},
  {group:'กำกับติดตาม',items:[{id:'inspection',label:'ผลตรวจ / Audit',icon:IC.search},
    {id:'reports',label:'ศูนย์รายงาน',icon:IC.file},{id:'notifications',label:'การแจ้งเตือน',icon:IC.bell,badgeKey:'notif'}]},
  {group:'ระบบ',items:[{id:'users',label:'ผู้ใช้และสิทธิ์',icon:IC.users},{id:'database',label:'โครงสร้างข้อมูล',icon:IC.db}]}
];
const TITLES={home:'หน้าแรกผู้บริหาร',dashboard:'Safety Dashboard','zero-accident':'Zero Accident Management',
  accidents:'ฐานข้อมูลอุบัติเหตุ',patrol:'Safety Round',actions:'ระบบติดตามการแก้ไข',kpi:'ตัวชี้วัดความปลอดภัย',
  waste:'การจัดการขยะ',wastewater:'ระบบน้ำเสีย',training:'การอบรมความปลอดภัย',officers:'ทะเบียนเจ้าหน้าที่ความปลอดภัย',
  inspection:'ผลการตรวจประเมิน',reports:'ศูนย์รายงาน',notifications:'การแจ้งเตือน',users:'ผู้ใช้และสิทธิ์',database:'โครงสร้างฐานข้อมูล'};

function renderNav(){
  const m=metrics(); const notifCount=buildNotifs().filter(n=>n.level!=='blue').length;
  const cur=route().page;
  $('#nav').innerHTML=NAV.map(g=>'<div class="nav-group">'+esc(g.group)+'</div>'+g.items.map(it=>{
    const n= it.badgeKey==='notif'?notifCount:(it.badgeKey?m[it.badgeKey]:0);
    return '<button class="nav-item'+(cur===it.id?' active':'')+'" data-go="'+it.id+'">'+
      '<span class="ic">'+it.icon+'</span><span>'+esc(it.label)+'</span>'+(n?'<span class="pill">'+n+'</span>':'')+'</button>';
  }).join('')).join('');
}

/* ---------- modal + forms ---------- */
function closeModal(){ $('#modalRoot').innerHTML=''; }
function openModal(title,bodyHtml,footHtml,opts){
  opts=opts||{};
  $('#modalRoot').innerHTML='<div class="modal-bg" data-close="1"><div class="modal" style="'+(opts.width?'width:min('+opts.width+',100%)':'')+'" role="dialog" aria-modal="true">'+
    '<div class="modal-h"><h2 style="font-size:1rem">'+esc(title)+'</h2><div class="spacer"></div>'+
    '<button class="icon-btn" data-close="1" aria-label="ปิด"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>'+
    '<div class="modal-b">'+bodyHtml+'</div>'+(footHtml?'<div class="modal-f">'+footHtml+'</div>':'')+'</div></div>';
}
function fieldHtml(f,val){
  const v=val==null?(f.value||''):val;
  let inp;
  if(f.type==='select') inp='<select class="select" name="'+f.key+'"'+(f.id?' id="'+f.id+'"':'')+'>'+(f.placeholder?'<option value="">'+esc(f.placeholder)+'</option>':'')+
    (f.options||[]).map(o=>{ const val2=typeof o==='object'?o.value:o, lab=typeof o==='object'?o.label:o;
      return '<option value="'+esc(val2)+'"'+(String(val2)===String(v)?' selected':'')+'>'+esc(lab)+'</option>'; }).join('')+'</select>';
  else if(f.type==='textarea') inp='<textarea class="input" rows="'+(f.rows||3)+'" name="'+f.key+'"'+(f.id?' id="'+f.id+'"':'')+' placeholder="'+esc(f.placeholder||'')+'">'+esc(v)+'</textarea>';
  else if(f.type==='file') inp='<div class="drop">'+IC.file.replace('<svg','<svg width="18" height="18" style="vertical-align:-3px;margin-right:6px"')+esc(f.placeholder||'แนบไฟล์หรือรูปภาพหลักฐาน (.jpg .png .pdf .xlsx)')+'</div>';
  else inp='<input class="input" type="'+(f.type||'text')+'" name="'+f.key+'"'+(f.id?' id="'+f.id+'"':'')+' value="'+esc(v)+'" placeholder="'+esc(f.placeholder||'')+'"'+(f.step?' step="'+f.step+'"':'')+'>';
  return '<div class="field'+(f.full?' full':'')+'"><label>'+esc(f.label)+(f.required?' <span class="req">*</span>':'')+'</label>'+inp+
    (f.hint?'<span class="tiny muted">'+esc(f.hint)+'</span>':'')+'</div>';
}
function openForm(title,fields,onSave,record,opts){
  opts=opts||{};
  openModal(title,'<form id="mForm">'+(opts.intro||'')+'<div class="form-grid">'+fields.map(f=>fieldHtml(f,record?record[f.key]:undefined)).join('')+'</div></form>',
    '<button class="btn" data-close="1">ยกเลิก</button><button class="btn btn-primary" id="mSave">บันทึกข้อมูล</button>',opts);
  if(opts.after) opts.after();
  $('#mSave').onclick=()=>{
    const form=$('#mForm'); const data={}; let missing=null;
    fields.forEach(f=>{ if(f.type==='file') return; const el=form.elements[f.key]; if(!el) return;
      data[f.key]=el.value; if(f.required&&!el.value){ missing=missing||f.label; } });
    if(missing){ toast('กรอกข้อมูลไม่ครบ: '+missing,true); return; }
    onSave(data); closeModal();
  };
}

/* ---------- export ---------- */
function toCSV(cols,rows){
  const head=cols.map(c=>'"'+String(c.label).replace(/"/g,'""')+'"').join(',');
  const body=rows.map(r=>cols.map(c=>{ const v=c.csv?c.csv(r):r[c.key]; return '"'+String(v==null?'':v).replace(/"/g,'""')+'"'; }).join(',')).join('\n');
  return '\ufeff'+head+'\n'+body;
}
async function exportCSV(filename,cols,rows){
  const csv=toCSV(cols,rows);
  try{
    const dl= window.claude && claude.use ? await claude.use('downloads') : null;
    if(dl){ await dl.save({filename:filename,data:csv}); toast('บันทึกไฟล์ '+filename+' แล้ว'); return; }
  }catch(e){ toast('ยกเลิกการบันทึกไฟล์',true); return; }
  try{
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})); a.download=filename;
    document.body.appendChild(a); a.click(); a.remove(); toast('ดาวน์โหลด '+filename+' แล้ว');
  }catch(e){
    openModal('ข้อมูลสำหรับคัดลอกไปยัง Excel','<textarea class="input" rows="14" id="csvBox">'+esc(csv)+'</textarea>',
      '<button class="btn" data-close="1">ปิด</button><button class="btn btn-primary" id="copyCsv">คัดลอกข้อมูล</button>');
    $('#copyCsv').onclick=()=>{ const t=$('#csvBox'); t.select(); try{document.execCommand('copy'); toast('คัดลอกแล้ว');}catch(e){} };
  }
}
function printReport(){ try{ window.print(); }catch(e){ toast('เบราว์เซอร์ไม่รองรับการสั่งพิมพ์',true); } }

/* =========================================================
   VIEWS
   ========================================================= */
const V={};

/* ---- Executive home ---- */
V.home=function(){
  const m=metrics();
  const overall= (m.actOverdue>4||m.accMonth>2) ? 'CRITICAL' : ((m.accMonth>0||m.actOverdue>0)?'WARNING':'GOOD');
  const qa=[['report-accident','รายงานอุบัติเหตุ'],['add-round','บันทึก Safety Round'],['add-action','สร้างงานแก้ไข'],
    ['add-training','บันทึกการอบรม'],['add-inspection','บันทึกผลตรวจ'],['add-waste','บันทึกขยะ']];
  const dueActions=S().actions.filter(a=>a.status!=='Closed').sort((a,b)=>a.due.localeCompare(b.due)).slice(0,6);
  const openRounds=S().rounds.filter(r=>r.status!=='ดำเนินการเสร็จสิ้น').slice(0,5);
  return '<div class="hero mb">'+
    '<div class="row" style="justify-content:space-between;align-items:flex-start">'+
      '<div><h1>Hospital Safety Management System</h1>'+
      '<div class="sub">'+esc(HOSPITAL)+' · '+thLong(TODAY)+' · ผู้ใช้งาน '+esc(S().settings.user)+' ('+esc(S().settings.role)+')</div></div>'+
      '<span class="badge" style="background:rgba(255,255,255,.16);color:#fff">สถานะภาพรวม: '+overall+'</span></div>'+
    '<div class="hero-stat">'+
      '<div><span>วันปลอดอุบัติเหตุ</span><strong>'+m.daysSafe+' วัน</strong></div>'+
      '<div><span>IFR / ISR สะสมปีนี้</span><strong>'+m.ifr+' / '+m.isr+'</strong></div>'+
      '<div><span>KPI เฉลี่ยทั้งระบบ</span><strong>'+m.kpiAvg+'%</strong></div>'+
      '<div><span>การแก้ไขค้างดำเนินการ</span><strong>'+m.actOpen+' รายการ</strong></div>'+
      '<div><span>Safety Round ปิดแล้ว</span><strong>'+m.roundPct+'%</strong></div></div>'+
    '<div class="qa mt">'+qa.map(q=>'<button data-quick="'+q[0]+'">'+IC.plus.replace('<svg','<svg width="14" height="14" style="vertical-align:-2px"')+' '+esc(q[1])+'</button>').join('')+'</div></div>'+
  '<div class="grid g7 mb">'+
    kpiCard({label:'ZERO ACCIDENT',value:m.daysSafe,unit:'วัน',tone:m.daysSafe>90?'good':'warn',foot:'ล่าสุด '+thDate(lastAccident())})+
    kpiCard({label:'SAFETY ROUND',value:m.roundDone+'/'+m.roundTotal,tone:m.roundPct>=80?'good':'warn',bar:m.roundPct,barTone:m.roundPct>=80?'green':'amber',foot:'ยังไม่ปิด '+m.roundOpen+' ประเด็น'})+
    kpiCard({label:'ACCIDENT เดือนนี้',value:m.accMonth,unit:'ครั้ง',tone:m.accMonth?'crit':'good',foot:'เป้าหมาย 0 ครั้ง'})+
    kpiCard({label:'NEAR MISS เดือนนี้',value:m.nmMonth,unit:'เรื่อง',tone:'info',foot:'ยิ่งรายงานมาก ยิ่งป้องกันได้'})+
    kpiCard({label:'KPI ACHIEVEMENT',value:m.kpiAvg+'%',tone:m.kpiAvg>=90?'good':'warn',bar:m.kpiAvg,barTone:m.kpiAvg>=90?'green':'amber',foot:m.kpiOk+' จาก '+S().kpis.length+' ตัวชี้วัดบรรลุเป้า'})+
    kpiCard({label:'TRAINING',value:m.newStaffTrained,unit:'คน',tone:'good',foot:'ผู้รับเหมาที่ยังไม่หมดอายุ '+m.contractorActive+' คน'})+
    kpiCard({label:'OPEN ACTION',value:m.actOpen,tone:m.actOverdue?'crit':'info',foot:'เกินกำหนด '+m.actOverdue+' รายการ'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('Safety Performance – รายเดือน','execTrend','อุบัติเหตุ เหตุเกือบเกิด และอุบัติการณ์ ย้อนหลัง 12 เดือน','chart-lg')+
    card('สรุปสถานะรายด้าน','<div>'+[
      ['IFR สะสมปีนี้ (ต่อ 1,000,000 ชม.)',m.ifr,m.ifr<=1?'b-green':'b-amber'],
      ['ISR สะสมปีนี้ (ต่อ 1,000,000 ชม.)',m.isr,m.isr<=5?'b-green':'b-amber'],
      ['ประเด็น Safety Round ความเสี่ยงสูงที่ยังไม่ปิด',m.roundHigh+' ประเด็น',m.roundHigh?'b-red':'b-green'],
      ['การแก้ไขเกินกำหนด',m.actOverdue+' รายการ',m.actOverdue?'b-red':'b-green'],
      ['ขยะติดเชื้อเดือนนี้',num(m.infectiousMonth)+' กก.','b-blue'],
      ['ผลตรวจน้ำเสียล่าสุด',m.wwLast.result+' ('+thMonth(m.wwLast.month)+')',m.wwLast.result==='ผ่าน'?'b-green':'b-red'],
      ['ผลตรวจราชการที่ยังไม่ปิด',m.insOpen+' เรื่อง',m.insOpen?'b-amber':'b-green']
    ].map(r=>'<div class="stat-row"><span>'+esc(r[0])+'</span>'+badge(r[1],r[2])+'</div>').join('')+'</div>',{sub:'ข้อมูล ณ '+thDate(iso(TODAY))})+
  '</div>'+
  '<div class="grid g2">'+
    card('งานแก้ไขที่ต้องติดตามใกล้ที่สุด',table([
      {label:'รหัส',key:'id',cls:'mono nowrap'},
      {label:'ประเด็น',render:r=>esc(r.finding.slice(0,52))+(r.finding.length>52?'…':'')},
      {label:'ผู้รับผิดชอบ',key:'owner',cls:'nowrap'},
      {label:'วันที่แล้วเสร็จ',render:r=>'<span class="nowrap">'+thDate(r.due)+'</span>'},
      {label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))}
    ],dueActions),{raw:true,actions:'<button class="btn btn-sm" data-go="actions">ดูทั้งหมด</button>'})+
    card('ประเด็น Safety Round ที่ยังไม่ปิด','<div class="timeline">'+
      openRounds.map(r=>'<div class="tl-item'+(r.risk==='สูง'?' late':'')+'"><div class="when">'+thDate(r.date)+' · '+esc(r.building)+'</div>'+
      '<b class="small">'+esc(r.issue.slice(0,80))+'</b><div class="tiny muted">'+esc(r.dept)+' · ความเสี่ยง'+esc(r.risk)+' · '+esc(r.status)+'</div></div>').join('')+'</div>',
      {actions:'<button class="btn btn-sm" data-go="patrol">เปิดโมดูล</button>'})+
  '</div>';
};
V.home.after=function(){
  mkChart('execTrend',{type:'bar',data:{labels:last12Labels(),datasets:[
    {label:'อุบัติเหตุ',data:monthlyCount(S().events,e=>e.kind==='accident'),backgroundColor:C.red,borderRadius:5,barPercentage:.7,categoryPercentage:.7},
    {label:'อุบัติการณ์',data:monthlyCount(S().events,e=>e.kind==='incident'),backgroundColor:C.amber,borderRadius:5,barPercentage:.7,categoryPercentage:.7},
    {label:'เหตุเกือบเกิด',data:monthlyCount(S().events,e=>e.kind==='near_miss'),type:'line',borderColor:C.blue,backgroundColor:C.blue,tension:.35,pointRadius:3,borderWidth:2}
  ]},options:{scales:{y:{ticks:{stepSize:1}}}}});
};

/* ---- Dashboard ---- */
V.dashboard=function(){
  const m=metrics();
  return '<div class="page-head"><div><h1>Safety Dashboard</h1><p>ภาพรวมการดำเนินงานความปลอดภัย '+esc(HOSPITAL)+' · ปรับปรุงล่าสุด '+pad(TODAY.getHours())+':'+pad(TODAY.getMinutes())+' น.</p></div>'+
    '<div class="spacer"></div><button class="btn" id="printBtn">พิมพ์หน้านี้</button></div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'สถานะ Zero Accident',value:m.daysSafe,unit:'วันปลอดอุบัติเหตุ',tone:m.daysSafe>90?'good':'warn',icon:IC.shield,foot:'อุบัติเหตุล่าสุด '+thDate(lastAccident())})+
    kpiCard({label:'อุบัติเหตุเดือนนี้',value:m.accMonth,unit:'ครั้ง',tone:m.accMonth?'crit':'good',icon:IC.alert,foot:'อุบัติการณ์ '+m.incMonth+' · เหตุเกือบเกิด '+m.nmMonth})+
    kpiCard({label:'Safety Round',value:m.roundDone+'/'+m.roundTotal,tone:'info',icon:IC.clipboard,bar:m.roundPct,foot:'ดำเนินการเสร็จสิ้น '+m.roundPct+'% · ยังไม่ปิด '+m.roundOpen+' ประเด็น'})+
    kpiCard({label:'KPI Safety Achievement',value:m.kpiAvg+'%',tone:m.kpiAvg>=90?'good':'warn',icon:IC.chart,bar:m.kpiAvg,barTone:m.kpiAvg>=90?'green':'amber',foot:'ค่าเฉลี่ยทุกตัวชี้วัด'})+
  '</div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'IFR (อัตราความถี่การบาดเจ็บ)',value:m.ifr,tone:m.ifr<=1?'good':'warn',foot:'ต่อชั่วโมงการทำงาน 1,000,000 ชม.'})+
    kpiCard({label:'ISR (อัตราความรุนแรง)',value:m.isr,tone:m.isr<=5?'good':'warn',foot:'วันสูญเสียต่อ 1,000,000 ชม.'})+
    kpiCard({label:'ขยะรวมเดือนนี้',value:num(m.wasteMonth),unit:'กก.',tone:'info',foot:'ขยะติดเชื้อ '+num(m.infectiousMonth)+' กก.'})+
    kpiCard({label:'ผลตรวจน้ำเสียล่าสุด',value:m.wwLast.result,tone:m.wwLast.result==='ผ่าน'?'good':'crit',foot:thMonth(m.wwLast.month)+' · ไม่ผ่านรวม '+m.wwFail+' เดือน'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('แนวโน้มอุบัติเหตุรายเดือน','dTrend','เปรียบเทียบกับเป้าหมาย Zero Accident')+
    chartCard('ผลสำเร็จตามตัวชี้วัด (KPI)','dKpi','ร้อยละความสำเร็จเทียบเป้าหมาย')+
  '</div>'+
  '<div class="grid g3 mb">'+
    chartCard('สถานะประเด็น Safety Round','dRound','','chart-sm')+
    chartCard('อุบัติการณ์แยกตามหน่วยงาน','dDept','รวมทุกประเภทเหตุการณ์','chart-sm')+
    chartCard('อุบัติการณ์แยกตามประเภท','dType','','chart-sm')+
  '</div>'+
  '<div class="grid g2">'+
    card('งานแก้ไขที่ยังไม่ปิด (Open Corrective Action)',table([
      {label:'รหัส',key:'id',cls:'mono nowrap'},{label:'แหล่งที่มา',key:'source',cls:'nowrap'},
      {label:'ความเสี่ยง',render:r=>badge(r.risk,riskClass(r.risk))},
      {label:'ผู้รับผิดชอบ',key:'owner',cls:'nowrap'},
      {label:'วันที่แล้วเสร็จ',render:r=>'<span class="nowrap">'+thDate(r.due)+'</span>'},
      {label:'ความคืบหน้า',render:r=>progress(r.progress,r.status==='Overdue'?'red':(r.progress>=70?'green':''))}
    ],S().actions.filter(a=>a.status!=='Closed').slice(0,8)),{raw:true,actions:'<button class="btn btn-sm" data-go="actions">เปิดโมดูล CAPA</button>'})+
    card('การอบรมล่าสุด',table([
      {label:'วันที่',render:r=>'<span class="nowrap">'+thDate(r.date)+'</span>'},
      {label:'ประเภท',render:r=>badge(r.type===TRAIN_TYPES[0]?'พนักงานใหม่':'ผู้รับเหมา',r.type===TRAIN_TYPES[0]?'b-blue':'b-amber')},
      {label:'จำนวน',render:r=>'<span class="mono">'+r.count+' คน</span>'},
      {label:'หมดอายุ',render:r=>r.expiry?thDate(r.expiry):'<span class="muted">—</span>'}
    ],S().trainings.slice(0,7)),{raw:true,actions:'<button class="btn btn-sm" data-go="training">ดูทั้งหมด</button>'})+
  '</div>';
};
V.dashboard.after=function(){
  mkChart('dTrend',{type:'line',data:{labels:last12Labels(),datasets:[
    {label:'อุบัติเหตุ',data:monthlyCount(S().events,e=>e.kind==='accident'),borderColor:C.red,backgroundColor:'rgba(211,47,47,.12)',fill:true,tension:.35,pointRadius:3},
    {label:'เป้าหมาย',data:new Array(12).fill(0),borderColor:C.green,borderDash:[6,5],pointRadius:0,borderWidth:2}
  ]},options:{scales:{y:{ticks:{stepSize:1}}}}});
  const k=S().kpis;
  mkChart('dKpi',{type:'bar',data:{labels:k.map(x=>x.name.length>34?x.name.slice(0,34)+'…':x.name),datasets:[{label:'ความสำเร็จ (%)',data:k.map(x=>x.achievement),
    backgroundColor:k.map(x=>x.achievement>=100?C.green:x.achievement>=90?C.amber:C.red),borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{grid:{color:gridColor()},ticks:{color:tickColor()}},y:{grid:{display:false},ticks:{color:tickColor(),font:{size:9,family:'IBM Plex Sans Thai'}}}}}});
  const gs=groupCount(S().rounds,'status'); const ks=ROUND_STATUS.filter(s=>gs[s]);
  mkChart('dRound',{type:'doughnut',data:{labels:ks,datasets:[{data:ks.map(s=>gs[s]),
    backgroundColor:ks.map(s=>s==='ดำเนินการเสร็จสิ้น'?C.green:s==='อยู่ระหว่างดำเนินการ'?C.blue:s==='ไม่สามารถดำเนินการได้'?C.red:C.gray),borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'bottom',labels:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor(),usePointStyle:true,boxWidth:8}}}}});
  const g=groupCount(S().events,'dept'); const gk=Object.keys(g).sort((a,b)=>g[b]-g[a]).slice(0,8);
  mkChart('dDept',{type:'bar',data:{labels:gk.map(x=>x.length>22?x.slice(0,22)+'…':x),datasets:[{label:'จำนวนเหตุการณ์',data:gk.map(x=>g[x]),backgroundColor:C.navy,borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{ticks:{font:{size:9,family:'IBM Plex Sans Thai'},color:tickColor()},grid:{display:false}},x:{ticks:{stepSize:1}}}}});
  const t=groupCount(S().events,'type'); const tk=Object.keys(t);
  mkChart('dType',{type:'doughnut',data:{labels:tk,datasets:[{data:tk.map(x=>t[x]),
    backgroundColor:[C.navy,C.blue,C.sky,C.green,C.amber,C.red,C.teal,C.purple,C.gray,'#8A6BC4'],borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'right',labels:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor(),boxWidth:8,usePointStyle:true}}}}});
};

/* ---- Zero Accident ---- */
const EVENT_FIELDS=()=>[
  {key:'date',label:'วันที่เกิดเหตุ',type:'date',required:true,value:iso(TODAY)},
  {key:'time',label:'เวลา',type:'time',required:true,value:pad(TODAY.getHours())+':'+pad(TODAY.getMinutes())},
  {key:'dept',label:'แผนก/หน่วยงาน',type:'select',options:DEPTS,required:true},
  {key:'location',label:'สถานที่เกิดเหตุ',required:true,placeholder:'เช่น ห้องผ่าตัด 3 โซนล้างเครื่องมือ'},
  {key:'type',label:'ประเภทเหตุการณ์',type:'select',options:ACC_TYPE,required:true},
  {key:'severity',label:'ระดับความรุนแรง',type:'select',options:SEVERITY,required:true},
  {key:'personType',label:'ประเภทผู้เกี่ยวข้อง',type:'select',options:PERSON_TYPE,required:true},
  {key:'person',label:'ชื่อผู้เกี่ยวข้อง',placeholder:'ชื่อ-นามสกุล'},
  {key:'lostDays',label:'จำนวนวันหยุดงาน (ใช้คำนวณ ISR)',type:'number',value:'0'},
  {key:'description',label:'รายละเอียดเหตุการณ์',type:'textarea',full:true,required:true},
  {key:'immediate',label:'การดำเนินการทันที (Immediate Action)',type:'textarea',full:true},
  {key:'rootCause',label:'สาเหตุราก (Root Cause)',type:'textarea',full:true},
  {key:'corrective',label:'การแก้ไข (Corrective Action)',type:'textarea',full:true},
  {key:'preventive',label:'การป้องกัน (Preventive Action)',type:'textarea',full:true},
  {key:'owner',label:'ผู้รับผิดชอบ',required:true,placeholder:'พิมพ์ชื่อ-นามสกุล'},
  {key:'due',label:'วันที่แล้วเสร็จ',type:'date',value:iso(addDays(TODAY,21))},
  {key:'status',label:'สถานะ',type:'select',options:['Open','In Progress','Pending Verification','Closed']},
  {key:'files',label:'เอกสาร/ภาพหลักฐาน',type:'file',full:true}
];
function addEvent(kind,d){
  const id=(kind==='accident'?'ACC':kind==='near_miss'?'NM':'INC')+'-'+d.date.slice(0,4)+'-'+pad(S().events.length+1);
  const lost=Number(d.lostDays||0);
  S().events.unshift(Object.assign({},d,{id:id,kind:kind,lostDays:lost,
    injuryClass: kind!=='accident'?(kind==='near_miss'?'Near Miss':'Incident'):(lost>0?'Lost Time Injury':(d.severity==='เล็กน้อย'?'First Aid Case':'Recordable Injury')),
    timeline:[{t:d.date+' '+d.time,title:'รับแจ้งเหตุและบันทึกเข้าระบบ',by:S().settings.user,done:true}],
    whys:[d.description||'',''],fishbone:{'คน':[],'วิธีการ':[],'เครื่องมือ':[],'สภาพแวดล้อม':[],'วัสดุ':[],'การบริหาร':[]},files:[]}));
  if(d.corrective) S().actions.unshift({id:uid('CA'),source:kind==='accident'?'Accident':(kind==='near_miss'?'Near Miss':'Incident'),ref:id,
    finding:d.rootCause||d.description,risk:(d.severity==='รุนแรง'||d.severity==='วิกฤต')?'สูงมาก':'สูง',owner:d.owner,due:d.due,dept:d.dept,
    status:'Open',progress:0,detail:d.corrective,created:d.date,photoAfter:0});
  Store.save(); toast('บันทึกเหตุการณ์ '+id+' เรียบร้อย'); render();
}
V['zero-accident']=function(){
  const ev=S().events; const m=metrics(); const r=ifrIsr();
  const cls=k=> ev.filter(e=>e.injuryClass===k).length;
  const year=ev.filter(e=>new Date(e.date).getFullYear()===TODAY.getFullYear());
  const best=Math.max(m.daysSafe,214);
  return '<div class="page-head"><div><h1>Zero Accident Management</h1><p>ติดตามสถิติความปลอดภัย พร้อมคำนวณอัตราความถี่ (IFR) และอัตราความรุนแรง (ISR) ของการบาดเจ็บ</p></div>'+
    '<div class="spacer"></div><div class="row">'+
    '<button class="btn btn-primary" data-quick="report-accident">'+IC.plus+' บันทึกอุบัติเหตุ</button>'+
    '<button class="btn" data-quick="add-nearmiss">'+IC.plus+' บันทึกเหตุเกือบเกิด</button>'+
    '<button class="btn" data-quick="add-incident">'+IC.plus+' บันทึกอุบัติการณ์</button></div></div>'+
  '<div class="grid g2 mb">'+
    '<div class="card" style="background:linear-gradient(120deg,#0E9F58,#0B7B44);color:#fff;border:0"><div class="card-b">'+
      '<div style="font-size:.82rem;color:#CDEFDD">จำนวนวันปลอดอุบัติเหตุต่อเนื่อง</div>'+
      '<div style="font-size:3.6rem;font-weight:600;line-height:1.05;letter-spacing:-.03em">'+m.daysSafe+'<span style="font-size:1.1rem;font-weight:500;margin-left:8px">วัน</span></div>'+
      '<div class="row mt" style="gap:26px">'+
        '<div><div style="font-size:.76rem;color:#CDEFDD">อุบัติเหตุล่าสุด</div><b>'+thDate(lastAccident())+'</b></div>'+
        '<div><div style="font-size:.76rem;color:#CDEFDD">สถิติสูงสุดขององค์กร</div><b>'+best+' วัน</b></div>'+
        '<div><div style="font-size:.76rem;color:#CDEFDD">เป้าหมายปีนี้</div><b>365 วัน</b></div></div>'+
      '<div class="prog mt" style="background:rgba(255,255,255,.25);border-color:transparent"><span style="width:'+Math.min(100,Math.round(m.daysSafe/365*100))+'%;background:#fff"></span></div>'+
      '<div class="tiny mt" style="color:#CDEFDD">ความคืบหน้าสู่เป้าหมาย '+Math.round(m.daysSafe/365*100)+'%</div></div></div>'+
    chartCard('สถิติเหตุการณ์รายเดือน','zaTrend','จำแนกตามระดับการบาดเจ็บ','chart-lg')+
  '</div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'Lost Time Injury (LTI)',value:cls('Lost Time Injury'),unit:'ครั้ง',tone:cls('Lost Time Injury')?'crit':'good',foot:'รวมวันสูญเสีย '+ev.reduce((s,e)=>s+(e.lostDays||0),0)+' วัน'})+
    kpiCard({label:'Recordable Injury',value:cls('Recordable Injury'),unit:'ครั้ง',tone:'warn',foot:'ต้องบันทึกตามกฎหมาย'})+
    kpiCard({label:'First Aid Case',value:cls('First Aid Case'),unit:'ครั้ง',tone:'info',foot:'ปฐมพยาบาลแล้วกลับเข้างานได้'})+
    kpiCard({label:'Near Miss',value:cls('Near Miss'),unit:'เรื่อง',tone:'good',foot:'ส่งเสริมการรายงานเชิงป้องกัน'})+
  '</div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'IFR — อัตราความถี่ของการบาดเจ็บ',value:r.ifr,tone:r.ifr<=1?'good':'crit',foot:'บาดเจ็บ '+r.inj+' ครั้ง ต่อชั่วโมงทำงาน 1,000,000 ชม.'})+
    kpiCard({label:'ISR — อัตราความรุนแรงของการบาดเจ็บ',value:r.isr,tone:r.isr<=5?'good':'crit',foot:'วันทำงานที่สูญเสีย '+r.lost+' วัน ต่อ 1,000,000 ชม.'})+
    kpiCard({label:'Total Incident ปีนี้',value:year.length,unit:'เหตุการณ์',tone:'info',foot:'ทุกประเภทรวมกัน'})+
    kpiCard({label:'เหตุการณ์ที่ปิดแล้ว',value:ev.filter(e=>e.status==='Closed').length+'/'+ev.length,tone:'good',bar:Math.round(ev.filter(e=>e.status==='Closed').length/Math.max(1,ev.length)*100),barTone:'green'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('แนวโน้ม IFR และ ISR รายเดือน','ifrTrend','คำนวณจากชั่วโมงการทำงาน '+num(HOURS_MONTH)+' ชม./เดือน','chart-lg')+
    card('วิธีคำนวณและฐานข้อมูลที่ใช้',
      '<div class="stat-row"><span>จำนวนพนักงาน (ฐานคำนวณ)</span><b class="mono">'+num(MANPOWER)+' คน</b></div>'+
      '<div class="stat-row"><span>ชั่วโมงการทำงานรวมต่อปี</span><b class="mono">'+num(HOURS_YEAR)+' ชม.</b></div>'+
      '<div class="card mt" style="background:var(--sky);border-color:var(--sky-200)"><div class="card-b">'+
      '<b class="small">IFR (Injury Frequency Rate)</b><div class="small">อัตราความถี่ของการบาดเจ็บ = จำนวนครั้งที่มีผู้ได้รับบาดเจ็บจากการทำงาน × 1,000,000 ÷ ชั่วโมงการทำงานทั้งหมด</div>'+
      '<div class="tiny muted mt">ปีนี้ = '+r.inj+' × 1,000,000 ÷ '+num(HOURS_YEAR)+' = <b>'+r.ifr+'</b></div>'+
      '<b class="small" style="display:block;margin-top:12px">ISR (Injury Severity Rate)</b><div class="small">อัตราความรุนแรงของการบาดเจ็บ = จำนวนวันทำงานที่สูญเสียไป × 1,000,000 ÷ ชั่วโมงการทำงานทั้งหมด</div>'+
      '<div class="tiny muted mt">ปีนี้ = '+r.lost+' × 1,000,000 ÷ '+num(HOURS_YEAR)+' = <b>'+r.isr+'</b></div>'+
      '</div></div>')+
  '</div>'+
  card('ทะเบียนเหตุการณ์ทั้งหมด',table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},
    {label:'วันที่',render:r2=>'<span class="nowrap">'+thDate(r2.date)+' '+esc(r2.time)+'</span>'},
    {label:'ประเภท',render:r2=>badge(r2.kind==='accident'?'อุบัติเหตุ':r2.kind==='near_miss'?'เหตุเกือบเกิด':'อุบัติการณ์',r2.kind==='accident'?'b-red':r2.kind==='near_miss'?'b-blue':'b-amber')},
    {label:'หน่วยงาน',key:'dept'},
    {label:'ลักษณะ',key:'type'},
    {label:'ความรุนแรง',render:r2=>badge(r2.severity,sevClass(r2.severity))},
    {label:'วันสูญเสีย',render:r2=>'<span class="mono">'+(r2.lostDays||0)+'</span>'},
    {label:'สถานะ',render:r2=>badge(statTh(r2.status),statClass(r2.status))},
    {label:'',render:r2=>'<button class="btn btn-sm" data-ev="'+r2.id+'">รายละเอียด</button>'}
  ],ev),{raw:true,actions:'<button class="btn btn-sm" id="expEv">ส่งออก CSV</button>'});
};
V['zero-accident'].after=function(){
  const cls=k=>monthlyCount(S().events,e=>e.injuryClass===k);
  mkChart('zaTrend',{type:'bar',data:{labels:last12Labels(),datasets:[
    {label:'Lost Time Injury',data:cls('Lost Time Injury'),backgroundColor:C.red,borderRadius:4,stack:'a'},
    {label:'Recordable',data:cls('Recordable Injury'),backgroundColor:C.amber,borderRadius:4,stack:'a'},
    {label:'First Aid',data:cls('First Aid Case'),backgroundColor:C.blue,borderRadius:4,stack:'a'},
    {label:'Near Miss',data:cls('Near Miss'),backgroundColor:C.green,borderRadius:4,stack:'a'},
    {label:'Incident',data:cls('Incident'),backgroundColor:C.gray,borderRadius:4,stack:'a'}
  ]},options:{scales:{x:{stacked:true},y:{stacked:true,ticks:{stepSize:1}}}}});
  const inj=monthlyCount(S().events,e=>e.kind==='accident');
  const lost=monthlySum(S().events,e=>e.kind==='accident','lostDays');
  mkChart('ifrTrend',{type:'line',data:{labels:last12Labels(),datasets:[
    {label:'IFR',data:inj.map(v=>Number((v*1e6/HOURS_MONTH).toFixed(2))),borderColor:C.blue,backgroundColor:'rgba(30,136,229,.14)',fill:true,tension:.3,pointRadius:3},
    {label:'ISR',data:lost.map(v=>Number((v*1e6/HOURS_MONTH).toFixed(2))),borderColor:C.red,tension:.3,pointRadius:3}
  ]}});
  const b=$('#expEv'); if(b) b.onclick=()=>exportCSV('accident-register.csv',
    [{label:'รหัส',key:'id'},{label:'วันที่',key:'date'},{label:'เวลา',key:'time'},{label:'ประเภท',key:'kind'},{label:'หน่วยงาน',key:'dept'},{label:'สถานที่',key:'location'},{label:'ลักษณะ',key:'type'},{label:'ความรุนแรง',key:'severity'},{label:'วันสูญเสีย',key:'lostDays'},{label:'สถานะ',key:'status'},{label:'รายละเอียด',key:'description'}],S().events);
};
function eventDetail(id){
  const e=S().events.find(x=>x.id===id); if(!e) return;
  const acts=S().actions.filter(a=>a.ref===id);
  openModal('รายละเอียดเหตุการณ์ '+e.id,
    '<div class="row mb" style="gap:8px">'+badge(e.kind==='accident'?'อุบัติเหตุ':e.kind==='near_miss'?'เหตุเกือบเกิด':'อุบัติการณ์',e.kind==='accident'?'b-red':'b-blue')+
      badge(e.severity,sevClass(e.severity))+badge(e.injuryClass,'b-gray')+badge(statTh(e.status),statClass(e.status))+'</div>'+
    '<div class="grid g2" style="gap:0 18px">'+
      [['วันที่และเวลา',thDate(e.date)+' เวลา '+e.time+' น.'],['หน่วยงาน',e.dept],['สถานที่',e.location],['ลักษณะเหตุการณ์',e.type],
       ['ผู้เกี่ยวข้อง',(e.person||'—')+' ('+e.personType+')'],['วันทำงานที่สูญเสีย',(e.lostDays||0)+' วัน'],['ผู้รับผิดชอบ',e.owner],['วันที่แล้วเสร็จ',thDate(e.due)]]
       .map(r=>'<div class="field"><label>'+esc(r[0])+'</label><b class="small">'+esc(r[1])+'</b></div>').join('')+'</div>'+
    [['รายละเอียดเหตุการณ์',e.description],['การดำเนินการทันที',e.immediate],['สาเหตุราก (Root Cause)',e.rootCause],['การแก้ไข (Corrective)',e.corrective],['การป้องกัน (Preventive)',e.preventive]]
      .map(r=>'<div class="field"><label>'+esc(r[0])+'</label><div class="small">'+esc(r[1]||'—')+'</div></div>').join('')+
    '<h3 class="mt" style="margin-bottom:10px">ไทม์ไลน์การดำเนินการแก้ไข</h3><div class="timeline">'+
      e.timeline.map(t=>'<div class="tl-item'+(t.done?' done':' late')+'"><div class="when">'+thDate(t.t.slice(0,10))+(t.t.length>10?' '+t.t.slice(11):'')+'</div><b class="small">'+esc(t.title)+'</b><div class="tiny muted">ผู้ดำเนินการ: '+esc(t.by)+'</div></div>').join('')+'</div>'+
    (acts.length?'<h3 class="mt" style="margin-bottom:10px">งานแก้ไขที่เชื่อมโยง</h3>'+table([
      {label:'รหัส',key:'id',cls:'mono'},{label:'รายละเอียด',key:'detail'},
      {label:'วันที่แล้วเสร็จ',render:r=>thDate(r.due)},{label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))}],acts):'')+
    '<h3 class="mt" style="margin-bottom:8px">เอกสารแนบ</h3><div class="row">'+(e.files||[]).map(f=>'<span class="badge b-blue plain">'+esc(f)+'</span>').join('')+'</div>',
    '<button class="btn" data-close="1">ปิด</button>'+(can()?'<button class="btn btn-primary" data-advance="'+e.id+'">บันทึกความคืบหน้า</button>':''));
}

/* ---- Safety Round ---- */
let roundFilter={dept:'',risk:'',status:'',q:''};
V.patrol=function(){
  const all=S().rounds; const m=metrics();
  const rows=all.filter(r=>(!roundFilter.dept||r.dept===roundFilter.dept)&&(!roundFilter.risk||r.risk===roundFilter.risk)&&
    (!roundFilter.status||r.status===roundFilter.status)&&
    (!roundFilter.q||(r.issue+r.building+r.owner+r.id).toLowerCase().includes(roundFilter.q.toLowerCase())));
  const sel=(id,label,opts,val)=>'<select class="select" style="width:auto" data-rf="'+id+'"><option value="">'+label+'</option>'+
    opts.map(o=>'<option'+(o===val?' selected':'')+'>'+esc(o)+'</option>').join('')+'</select>';
  return '<div class="page-head"><div><h1>Safety Round</h1><p>บันทึกและติดตามประเด็นความเสี่ยงที่พบจากการตรวจ Safety Round ตามแบบฟอร์มคณะกรรมการความปลอดภัย</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="add-round">'+IC.plus+' บันทึกประเด็นที่พบ</button></div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'จำนวนประเด็นทั้งหมด',value:m.roundTotal,unit:'ประเด็น',tone:'info',foot:'จากการตรวจทุกพื้นที่'})+
    kpiCard({label:'ดำเนินการเสร็จสิ้น',value:m.roundDone,tone:'good',bar:m.roundPct,barTone:'green',foot:'คิดเป็น '+m.roundPct+'% ของประเด็นทั้งหมด'})+
    kpiCard({label:'อยู่ระหว่างดำเนินการ',value:m.roundProgress,tone:'warn',foot:'ยังไม่เริ่มดำเนินการ '+m.roundNotStart+' ประเด็น'})+
    kpiCard({label:'ความเสี่ยงสูงที่ยังไม่ปิด',value:m.roundHigh,tone:m.roundHigh?'crit':'good',foot:'ไม่สามารถดำเนินการได้ '+m.roundBlocked+' ประเด็น'})+
  '</div>'+
  '<div class="grid g3 mb">'+
    chartCard('สรุปตามระดับความเสี่ยง','rRisk','','chart-sm')+
    chartCard('สรุปตามสถานะดำเนินการ','rStatus','','chart-sm')+
    card('หน่วยงานที่พบประเด็นมากที่สุด','<div>'+Object.entries(groupCount(all,'dept')).sort((a,b)=>b[1]-a[1]).slice(0,7)
      .map(r=>{const done=all.filter(x=>x.dept===r[0]&&x.status==='ดำเนินการเสร็จสิ้น').length;
        return '<div class="stat-row"><span class="small">'+esc(r[0].length>30?r[0].slice(0,30)+'…':r[0])+'<div class="tiny muted">เสร็จสิ้น '+done+' จาก '+r[1]+'</div></span>'+
        '<div class="row" style="gap:10px;min-width:120px"><div class="prog" style="flex:1"><span style="width:'+Math.round(done/r[1]*100)+'%"></span></div><b class="mono small">'+r[1]+'</b></div></div>';}).join('')+'</div>')+
  '</div>'+
  card('ตัวกรอง','<div class="row">'+
    '<input class="input" style="flex:1;min-width:220px" placeholder="ค้นหาประเด็น อาคาร/ชั้น หรือผู้รับผิดชอบ" data-rf="q" value="'+esc(roundFilter.q)+'">'+
    sel('dept','ทุกหน่วยงาน',DEPTS,roundFilter.dept)+sel('risk','ทุกระดับความเสี่ยง',RISK3,roundFilter.risk)+
    sel('status','ทุกสถานะ',ROUND_STATUS,roundFilter.status)+'<button class="btn" id="clrRf">ล้างตัวกรอง</button></div>',{cls:'mb'})+
  card('บันทึก Safety Round ('+rows.length+' ประเด็น)',table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},
    {label:'วันที่ตรวจ',render:r=>'<span class="nowrap">'+thDate(r.date)+'</span>'},
    {label:'หน่วยงาน/พื้นที่',render:r=>'<span class="small">'+esc(r.dept)+'</span>'},
    {label:'อาคาร/ชั้น',key:'building',cls:'nowrap'},
    {label:'ผู้ตรวจประเมิน',key:'inspector',cls:'nowrap'},
    {label:'ประเด็น/ความเสี่ยงที่พบ',render:r=>'<span class="small">'+esc(r.issue)+'</span>'+(r.note?'<div class="tiny muted">หมายเหตุ: '+esc(r.note)+'</div>':'')},
    {label:'ระดับความเสี่ยง',render:r=>badge(r.risk,riskClass(r.risk))},
    {label:'ผู้รับผิดชอบแก้ไข',render:r=>'<span class="small">'+esc(r.owner)+'</span>'},
    {label:'กำหนดแล้วเสร็จ',render:r=>'<span class="nowrap">'+thDate(r.due)+'</span>'},
    {label:'รูปก่อนแก้ไข',render:r=>photoTag(r.photo,'มีรูป')},
    {label:'สถานะดำเนินการ',render:r=>badge(r.status,roundStatClass(r.status))},
    {label:'วันที่เสร็จจริง',render:r=>r.doneDate?'<span class="nowrap">'+thDate(r.doneDate)+'</span>':'<span class="muted">—</span>'},
    {label:'รูปหลังแก้ไข',render:r=>photoTag(r.photoAfter,'มีรูป')},
    {label:'',render:r=>'<button class="btn btn-sm" data-round="'+r.id+'">'+(can()?'บันทึกผล':'ดูรายละเอียด')+'</button>'}
  ],rows,{emptyTitle:'ไม่พบประเด็นตามเงื่อนไข',empty:'ลองปรับตัวกรองหรือบันทึกประเด็นใหม่'}),
  {raw:true,actions:'<button class="btn btn-sm" id="expRound">ส่งออก CSV</button>'});
};
V.patrol.after=function(){
  $$('[data-rf]').forEach(el=>{ const k=el.dataset.rf;
    if(el.tagName==='SELECT') el.onchange=()=>{ roundFilter[k]=el.value; render(); };
    else el.oninput=()=>{ clearTimeout(el._t); el._t=setTimeout(()=>{ const v=el.value; roundFilter.q=v; render();
      const nx=document.querySelector('[data-rf="q"]'); if(nx){ nx.focus(); nx.setSelectionRange(v.length,v.length); } },420); };
  });
  const c=$('#clrRf'); if(c) c.onclick=()=>{ roundFilter={dept:'',risk:'',status:'',q:''}; render(); };
  const gr=groupCount(S().rounds,'risk'); const kr=RISK3.filter(r=>gr[r]);
  mkChart('rRisk',{type:'doughnut',data:{labels:kr,datasets:[{data:kr.map(r=>gr[r]),
    backgroundColor:kr.map(r=>r==='สูง'?C.red:r==='ปานกลาง'?C.amber:C.blue),borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'bottom'}}}});
  const gs=groupCount(S().rounds,'status'); const ks=ROUND_STATUS.filter(s=>gs[s]);
  mkChart('rStatus',{type:'bar',data:{labels:ks,datasets:[{data:ks.map(s=>gs[s]),
    backgroundColor:ks.map(s=>s==='ดำเนินการเสร็จสิ้น'?C.green:s==='อยู่ระหว่างดำเนินการ'?C.blue:s==='ไม่สามารถดำเนินการได้'?C.red:C.gray),borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{grid:{display:false},ticks:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor()}},x:{ticks:{stepSize:1}}}}});
  $$('[data-round]').forEach(b=>b.onclick=()=>roundDetail(b.dataset.round));
  const e=$('#expRound'); if(e) e.onclick=()=>exportCSV('safety-round.csv',
    [{label:'ลำดับ',key:'id'},{label:'วันที่ตรวจ',key:'date'},{label:'หน่วยงาน/พื้นที่',key:'dept'},{label:'อาคาร/ชั้น',key:'building'},
     {label:'ผู้ตรวจประเมิน',key:'inspector'},{label:'ประเด็น/ความเสี่ยงที่พบ',key:'issue'},{label:'ระดับความเสี่ยง',key:'risk'},
     {label:'ผู้รับผิดชอบแก้ไข',key:'owner'},{label:'กำหนดแล้วเสร็จ',key:'due'},{label:'สถานะดำเนินการ',key:'status'},
     {label:'วันที่ดำเนินการเสร็จจริง',key:'doneDate'},{label:'การแก้ไข',key:'fixDetail'},{label:'หมายเหตุ',key:'note'}],S().rounds);
};
function roundDetail(id){
  const r=S().rounds.find(x=>x.id===id); if(!r) return;
  if(!can()){
    openModal('ประเด็น Safety Round '+r.id,
      '<div class="row mb" style="gap:8px">'+badge(r.risk,riskClass(r.risk))+badge(r.status,roundStatClass(r.status))+'</div>'+
      [['วันที่ตรวจ',thDate(r.date)],['หน่วยงาน/พื้นที่',r.dept],['อาคาร/ชั้น',r.building],['ผู้ตรวจประเมิน',r.inspector],
       ['ประเด็น/ความเสี่ยงที่พบ',r.issue],['ผู้รับผิดชอบแก้ไข',r.owner],['กำหนดแล้วเสร็จ',thDate(r.due)],
       ['วันที่ดำเนินการเสร็จจริง',r.doneDate?thDate(r.doneDate):'—'],['การแก้ไขที่ดำเนินการ',r.fixDetail||'—'],['หมายเหตุ',r.note||'—']]
      .map(x=>'<div class="field"><label>'+esc(x[0])+'</label><div class="small">'+esc(x[1])+'</div></div>').join(''),
      '<button class="btn" data-close="1">ปิด</button>');
    return;
  }
  openForm('บันทึกผลการดำเนินการ — '+r.id,[
    {key:'issue',label:'ประเด็น/ความเสี่ยงที่พบ',type:'textarea',full:true,value:r.issue},
    {key:'risk',label:'ระดับความเสี่ยง',type:'select',options:RISK3,value:r.risk},
    {key:'owner',label:'ผู้รับผิดชอบแก้ไข',value:r.owner,placeholder:'พิมพ์ชื่อหน่วยงานหรือชื่อ-นามสกุล'},
    {key:'due',label:'กำหนดแล้วเสร็จ',type:'date',value:r.due},
    {key:'status',label:'สถานะดำเนินการ',type:'select',options:ROUND_STATUS,value:r.status},
    {key:'doneDate',label:'วันที่ดำเนินการเสร็จจริง',type:'date',value:r.doneDate},
    {key:'fixDetail',label:'การแก้ไขที่ดำเนินการ',type:'textarea',full:true,value:r.fixDetail},
    {key:'note',label:'หมายเหตุ',type:'textarea',full:true,value:r.note},
    {key:'photoAfter',label:'รูปภาพประกอบหลังการแก้ไข',type:'file',full:true,placeholder:'แนบรูปภาพหลังการแก้ไข (.jpg .png)'}
  ],d=>{
    Object.assign(r,d);
    if(d.status==='ดำเนินการเสร็จสิ้น'){ if(!r.doneDate) r.doneDate=iso(TODAY); r.photoAfter=1; }
    const a=S().actions.find(x=>x.ref===r.id);
    if(a){ a.status= d.status==='ดำเนินการเสร็จสิ้น'?'Closed':(new Date(r.due)<TODAY?'Overdue':(d.status==='อยู่ระหว่างดำเนินการ'?'In Progress':'Open'));
      a.progress= d.status==='ดำเนินการเสร็จสิ้น'?100:a.progress; a.detail=d.fixDetail||a.detail; a.due=r.due; a.owner=r.owner; }
    Store.save(); toast('บันทึกผลการดำเนินการแล้ว'); render();
  });
}

/* ---- KPI ---- */
V.kpi=function(){
  const k=S().kpis; const m=metrics();
  return '<div class="page-head"><div><h1>ตัวชี้วัดความปลอดภัย (Safety KPI)</h1><p>ผลการดำเนินงานเทียบเป้าหมายรายเดือนและรายปี ประจำปี '+(TODAY.getFullYear()+543)+'</p></div>'+
    '<div class="spacer"></div><div class="row"><select class="select" id="kpiYear"><option>'+(TODAY.getFullYear()+543)+'</option><option>'+(TODAY.getFullYear()+542)+'</option></select>'+
    (can()?'<button class="btn btn-primary" id="addKpi">'+IC.plus+' เพิ่มตัวชี้วัด</button>':'')+'</div></div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'ตัวชี้วัดที่บรรลุเป้าหมาย',value:m.kpiOk+'/'+k.length,tone:m.kpiOk>=k.length*0.7?'good':'warn',bar:Math.round(m.kpiOk/k.length*100),barTone:'green'})+
    kpiCard({label:'ค่าเฉลี่ยความสำเร็จ',value:m.kpiAvg+'%',tone:'info',bar:m.kpiAvg})+
    kpiCard({label:'ตัวชี้วัดที่ต้องเฝ้าระวัง',value:k.filter(x=>x.achievement>=90&&x.achievement<100).length,tone:'warn',foot:'ความสำเร็จ 90–99%'})+
    kpiCard({label:'ตัวชี้วัดต่ำกว่าเป้าหมาย',value:k.filter(x=>x.achievement<90).length,tone:k.filter(x=>x.achievement<90).length?'crit':'good',foot:'ต้องจัดทำแผนปรับปรุง'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('แนวโน้มตัวชี้วัดรายเดือน','kpiTrend','กดปุ่มแนวโน้มในตารางเพื่อเลือกตัวชี้วัด','chart-lg')+
    chartCard('ภาพรวมความสำเร็จรายตัวชี้วัด','kpiRadar','เทียบเป้าหมาย 100%','chart-lg')+
  '</div>'+
  card('ตารางตัวชี้วัดประจำเดือน'+THMON_FULL[TODAY.getMonth()],table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},
    {label:'ตัวชี้วัด',render:r=>'<b class="small">'+esc(r.name)+'</b><div class="tiny muted">'+esc(r.desc)+'</div>'},
    {label:'เป้าหมาย',render:r=>'<span class="mono nowrap">'+(r.lower?'≤ ':'')+num(r.target)+' '+esc(r.unit)+'</span>'},
    {label:'ผลจริง',render:r=>'<span class="mono nowrap"><b>'+num(r.actual)+'</b> '+esc(r.unit)+'</span>'},
    {label:'ความสำเร็จ',render:r=>progress(Math.min(r.achievement,100),r.achievement>=100?'green':r.achievement>=90?'amber':'red')},
    {label:'ผู้รับผิดชอบ',render:r=>'<span class="small">'+esc(r.owner)+'</span>'},
    {label:'สถานะ',render:r=>badge(r.status,r.achievement>=100?'b-green':r.achievement>=90?'b-amber':'b-red')},
    {label:'',render:r=>'<button class="btn btn-sm" data-kpi="'+r.id+'">แนวโน้ม</button>'}
  ],k),{raw:true,actions:'<button class="btn btn-sm" id="expKpi">ส่งออก CSV</button>'});
};
V.kpi.after=function(){
  drawKpiTrend(S().kpis[0]);
  const k=S().kpis;
  mkChart('kpiRadar',{type:'radar',data:{labels:k.map(x=>x.name.length>26?x.name.slice(0,26)+'…':x.name),datasets:[
    {label:'ความสำเร็จ (%)',data:k.map(x=>Math.min(x.achievement,120)),borderColor:C.blue,backgroundColor:'rgba(30,136,229,.18)',pointBackgroundColor:C.blue,borderWidth:2},
    {label:'เป้าหมาย',data:k.map(()=>100),borderColor:C.green,borderDash:[5,4],pointRadius:0,borderWidth:1.5}
  ]},options:{scales:{r:{beginAtZero:true,max:120,grid:{color:gridColor()},angleLines:{color:gridColor()},
    pointLabels:{font:{size:8,family:'IBM Plex Sans Thai'},color:tickColor()},ticks:{display:false}}}}});
  $$('[data-kpi]').forEach(b=>b.onclick=()=>{ const kp=S().kpis.find(x=>x.id===b.dataset.kpi); drawKpiTrend(kp);
    document.getElementById('kpiTrend').scrollIntoView({behavior:'smooth',block:'center'}); toast('แสดงแนวโน้ม: '+kp.name); });
  const e=$('#expKpi'); if(e) e.onclick=()=>exportCSV('kpi-report.csv',
    [{label:'รหัส',key:'id'},{label:'ตัวชี้วัด',key:'name'},{label:'เป้าหมาย',key:'target'},{label:'หน่วย',key:'unit'},{label:'ผลจริง',key:'actual'},{label:'ความสำเร็จ %',key:'achievement'},{label:'ผู้รับผิดชอบ',key:'owner'},{label:'สถานะ',key:'status'}],S().kpis);
  const a=$('#addKpi'); if(a) a.onclick=()=>openForm('เพิ่มตัวชี้วัดความปลอดภัย',[
    {key:'name',label:'ชื่อตัวชี้วัด',required:true,full:true},
    {key:'unit',label:'หน่วย',type:'select',options:['%','ครั้ง','วัน','เรื่อง','คน']},
    {key:'target',label:'เป้าหมาย',type:'number',required:true},{key:'actual',label:'ผลจริงเดือนนี้',type:'number',required:true},
    {key:'owner',label:'ผู้รับผิดชอบ',type:'select',options:DEPTS,required:true}],d=>{
      const lower=d.unit==='ครั้ง';
      const ach= lower ? (Number(d.actual)<=Number(d.target)?100:Math.max(0,100-Number(d.actual)*25)) : Math.round(d.actual/d.target*100);
      S().kpis.push({id:'KPI-'+pad(S().kpis.length+1),name:d.name,desc:'เป้าหมาย '+(lower?'ไม่เกิน ':'')+d.target+' '+d.unit,
        target:+d.target,unit:d.unit,actual:+d.actual,months:new Array(12).fill(+d.actual),lower:lower,
        achievement:Math.min(ach,130),owner:d.owner,year:TODAY.getFullYear(),month:TODAY.getMonth()+1,
        status:ach>=100?'บรรลุเป้าหมาย':(ach>=90?'เฝ้าระวัง':'ต่ำกว่าเป้าหมาย')});
      Store.save(); toast('เพิ่มตัวชี้วัดแล้ว'); render(); });
};
function drawKpiTrend(k){
  if(!k) return;
  if(charts['kpiTrend']){ charts['kpiTrend'].destroy(); delete charts['kpiTrend']; }
  mkChart('kpiTrend',{type:'line',data:{labels:last12Labels(),datasets:[
    {label:(k.name.length>34?k.name.slice(0,34)+'…':k.name),data:k.months,borderColor:C.blue,backgroundColor:'rgba(30,136,229,.14)',fill:true,tension:.35,pointRadius:3},
    {label:'เป้าหมาย '+k.target+' '+k.unit,data:new Array(12).fill(k.target),borderColor:C.green,borderDash:[6,5],pointRadius:0,borderWidth:2}
  ]}});
}

/* ---- Waste ---- */
V.waste=function(){
  const w=S().waste; const curM=ym(TODAY);
  const month=w.filter(x=>x.month===curM);
  const sum=t=>month.filter(x=>x.type===t).reduce((s,x)=>s+x.qty,0);
  const total=month.reduce((s,x)=>s+x.qty,0);
  return '<div class="page-head"><div><h1>การจัดการขยะโรงพยาบาล</h1><p>บันทึกปริมาณขยะรายเดือนแยกตามประเภท พร้อมวิธีการจัดการและผู้รับกำจัด</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="add-waste">'+IC.plus+' บันทึกปริมาณขยะ</button></div>'+
  '<div class="grid g4 mb">'+WASTE_TYPES.slice(0,4).map(t=>kpiCard({label:t+' ('+thMonth(curM)+')',value:num(sum(t)),unit:'กก.',
      tone:t==='ขยะติดเชื้อ'?'warn':(t==='ขยะอันตราย'?'crit':'info'),bar:total?Math.round(sum(t)/total*100):0,
      foot:'คิดเป็น '+(total?Math.round(sum(t)/total*100):0)+'% ของขยะทั้งหมด'})).join('')+'</div>'+
  '<div class="grid g2 mb">'+
    chartCard('ปริมาณขยะรายเดือนแยกตามประเภท','wTrend','ย้อนหลัง 12 เดือน (กิโลกรัม)','chart-lg')+
    '<div class="grid" style="gap:16px">'+
      chartCard('สัดส่วนขยะเดือนนี้','wPie','','chart-sm')+
      card('สรุปการส่งกำจัดเดือนนี้','<div>'+WASTE_TYPES.map(t=>{const rec=month.filter(x=>x.type===t);
        return '<div class="stat-row"><span>'+esc(t)+'<div class="tiny muted">'+esc(rec[0]?rec[0].vendor:'—')+'</div></span><b class="mono">'+num(sum(t))+' กก.</b></div>';}).join('')+
        '<div class="stat-row" style="border-top:1px solid var(--line);margin-top:6px;padding-top:10px"><b>รวมทั้งหมด</b><b class="mono">'+num(total)+' กก.</b></div></div>')+
    '</div>'+
  '</div>'+
  card('ทะเบียนการจัดการขยะ',table([
    {label:'เดือน',render:r=>'<span class="nowrap">'+thMonth(r.month)+'</span>'},
    {label:'ประเภท',render:r=>badge(r.type,r.type==='ขยะติดเชื้อ'?'b-red':(r.type==='ขยะอันตราย'||r.type==='ขยะเคมี')?'b-amber':r.type==='ขยะรีไซเคิล'?'b-green':'b-gray')},
    {label:'ปริมาณ',render:r=>'<span class="mono">'+num(r.qty)+' '+esc(r.unit)+'</span>',cls:'nowrap'},
    {label:'วิธีการจัดการ',key:'method'},{label:'ผู้รับกำจัด',key:'vendor'},{label:'ผู้บันทึก',key:'recorder',cls:'nowrap'}
  ],w.slice().sort((a,b)=>b.month.localeCompare(a.month)).slice(0,45)),
  {raw:true,actions:'<button class="btn btn-sm" id="expW">ส่งออก CSV</button>'});
};
V.waste.after=function(){
  const cols=[C.gray,C.red,C.amber,C.green,C.purple];
  const L=last12();
  const series=WASTE_TYPES.map((t,i)=>({label:t,backgroundColor:cols[i],borderRadius:4,stack:'w',
    data:L.map(x=>S().waste.filter(w=>w.type===t&&w.month===x.key).reduce((s,w)=>s+w.qty,0))}));
  mkChart('wTrend',{type:'bar',data:{labels:L.map(x=>x.label),datasets:series},options:{scales:{x:{stacked:true},y:{stacked:true}}}});
  const curM=ym(TODAY); const month=S().waste.filter(x=>x.month===curM);
  mkChart('wPie',{type:'doughnut',data:{labels:WASTE_TYPES,datasets:[{data:WASTE_TYPES.map(t=>month.filter(x=>x.type===t).reduce((s,x)=>s+x.qty,0)),backgroundColor:cols,borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'right',labels:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor(),usePointStyle:true,boxWidth:8}}}}});
  const e=$('#expW'); if(e) e.onclick=()=>exportCSV('waste-report.csv',
    [{label:'เดือน',key:'month'},{label:'ประเภท',key:'type'},{label:'ปริมาณ',key:'qty'},{label:'หน่วย',key:'unit'},{label:'วิธีการจัดการ',key:'method'},{label:'ผู้รับกำจัด',key:'vendor'},{label:'ผู้บันทึก',key:'recorder'}],S().waste);
};

/* ---- Wastewater ---- */
V.wastewater=function(){
  const w=S().wastewater; const last=w[0];
  const fails=w.filter(x=>x.result==='ไม่ผ่าน');
  const fixed=fails.filter(x=>x.fix&&x.fix.status==='แก้ไขแล้ว').length;
  const cell=(r,p)=>{ if(p.text) return '<span class="small">'+esc(r[p.k])+'</span>';
    const v=Number(r[p.k]); const bad=(p.min!=null&&v<p.min)||(p.max!=null&&v>p.max);
    return '<span class="mono"'+(bad?' style="color:var(--red);font-weight:600"':'')+'>'+num(v)+'</span>'; };
  const KEYS=['ph','bod','tss','tds','oil','cod'];
  return '<div class="page-head"><div><h1>ระบบติดตามคุณภาพน้ำเสีย</h1><p>ผลตรวจวิเคราะห์น้ำทิ้งรายเดือนเทียบค่ามาตรฐาน พร้อมบันทึกวิธีการแก้ไขเมื่อผลไม่ผ่านเกณฑ์</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="add-ww">'+IC.plus+' บันทึกผลตรวจประจำเดือน</button></div>'+
  (last.result==='ไม่ผ่าน'?'<div class="card mb" style="border-left:3px solid var(--red)"><div class="card-b row" style="gap:14px">'+
    '<span style="color:var(--red)">'+IC.alert.replace('<svg','<svg width="22" height="22"')+'</span>'+
    '<div><b>ผลตรวจล่าสุดเกินค่ามาตรฐาน</b><div class="small muted">'+thMonth(last.month)+' — พารามิเตอร์ที่เกิน: '+esc(last.fails.join(', '))+' ระบบสร้างงานแก้ไขให้อัตโนมัติแล้ว</div></div>'+
    '<div class="spacer"></div><button class="btn btn-sm" data-ww="'+last.id+'">บันทึกการแก้ไข</button></div></div>':'')+
  '<div class="grid g4 mb">'+
    kpiCard({label:'ผลตรวจล่าสุด',value:last.result,tone:last.result==='ผ่าน'?'good':'crit',foot:thMonth(last.month)})+
    kpiCard({label:'เดือนที่ผ่านเกณฑ์',value:(w.length-fails.length)+'/'+w.length,tone:fails.length?'warn':'good',bar:Math.round((w.length-fails.length)/w.length*100),barTone:'green',foot:'ในรอบ 12 เดือน'})+
    kpiCard({label:'ค่า BOD ล่าสุด',value:last.bod,unit:'มก./ล.',tone:last.bod<=20?'good':'crit',foot:'มาตรฐานไม่เกิน 20'})+
    kpiCard({label:'การแก้ไขที่ดำเนินการแล้ว',value:fixed+'/'+fails.length,tone:fixed===fails.length?'good':'warn',foot:'จากเดือนที่ผลไม่ผ่านเกณฑ์'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('แนวโน้ม BOD / COD / TSS','wwTrend','เทียบเส้นมาตรฐาน (มก./ล.)','chart-lg')+
    chartCard('แนวโน้มค่า pH','wwPh','ช่วงมาตรฐาน 5.5 – 9.0','chart-lg')+
  '</div>'+
  card('ผลการตรวจวิเคราะห์น้ำทิ้งรายเดือน','<div class="tbl-wrap"><table><thead><tr>'+
    ['เดือน','Appearance'].concat(KEYS.map(k=>WW_PARAMS.find(p=>p.k===k).label)).concat(['ผลการประเมิน','เอกสารผลตรวจ','']).map(h=>'<th>'+esc(h)+'</th>').join('')+
    '</tr><tr class="tiny muted"><th>มาตรฐาน</th><th>ไม่มีกลิ่น/ตะกอน</th>'+KEYS.map(k=>'<th>'+esc(WW_PARAMS.find(p=>p.k===k).std)+'</th>').join('')+'<th></th><th></th><th></th></tr></thead><tbody>'+
    w.map(r=>'<tr><td class="nowrap">'+thMonth(r.month)+'</td><td class="small">'+esc(r.appearance)+'</td>'+
      KEYS.map(k=>'<td>'+cell(r,WW_PARAMS.find(p=>p.k===k))+'</td>').join('')+
      '<td>'+badge(r.result,r.result==='ผ่าน'?'b-green':'b-red')+'</td>'+
      '<td><span class="badge b-blue plain tiny">'+esc(r.file||'—')+'</span></td>'+
      '<td class="nowrap"><button class="btn btn-sm" data-wwv="'+r.id+'">ค่าทั้งหมด</button>'+
      (r.result==='ไม่ผ่าน'?' <button class="btn btn-sm" data-ww="'+r.id+'">การแก้ไข</button>':'')+'</td></tr>').join('')+
    '</tbody></table></div>',{raw:true,cls:'mb',actions:'<button class="btn btn-sm" id="expWw">ส่งออก CSV</button>'})+
  '<div class="grid g2">'+
    card('Dashboard การแก้ไขเมื่อผลตรวจไม่ผ่านเกณฑ์',
      fails.length? '<div class="timeline">'+fails.map(f=>'<div class="tl-item'+(f.fix&&f.fix.status==='แก้ไขแล้ว'?' done':' late')+'">'+
        '<div class="when">'+thMonth(f.month)+' · เกินมาตรฐาน: '+esc(f.fails.join(', '))+'</div>'+
        '<b class="small">'+esc(f.fix?f.fix.detail:'ยังไม่ได้บันทึกวิธีการแก้ไข')+'</b>'+
        '<div class="tiny muted">'+(f.fix?('ผู้ดำเนินการ '+esc(f.fix.by)+' · '+thDate(f.fix.date)+' · '+esc(f.fix.status)):'รอบันทึกข้อมูล')+'</div></div>').join('')+'</div>'
        :'<div class="empty"><strong>ผลตรวจผ่านเกณฑ์ทุกเดือน</strong>ยังไม่มีรายการที่ต้องแก้ไข</div>')+
    chartCard('จำนวนพารามิเตอร์ที่เกินมาตรฐานรายเดือน','wwFail','','chart-sm')+
  '</div>';
};
V.wastewater.after=function(){
  const w=S().wastewater.slice().sort((a,b)=>a.month.localeCompare(b.month));
  const lb=w.map(x=>thMonthShort(x.month));
  mkChart('wwTrend',{type:'line',data:{labels:lb,datasets:[
    {label:'BOD',data:w.map(x=>x.bod),borderColor:C.blue,tension:.3,pointRadius:3},
    {label:'COD',data:w.map(x=>x.cod),borderColor:C.purple,tension:.3,pointRadius:3},
    {label:'TSS',data:w.map(x=>x.tss),borderColor:C.teal,tension:.3,pointRadius:3},
    {label:'มาตรฐาน BOD (20)',data:w.map(()=>20),borderColor:C.red,borderDash:[6,4],pointRadius:0,borderWidth:1.5},
    {label:'มาตรฐาน TSS (30)',data:w.map(()=>30),borderColor:C.amber,borderDash:[6,4],pointRadius:0,borderWidth:1.5}
  ]}});
  mkChart('wwPh',{type:'line',data:{labels:lb,datasets:[
    {label:'pH',data:w.map(x=>x.ph),borderColor:C.teal,backgroundColor:'rgba(27,167,160,.15)',fill:true,tension:.3,pointRadius:3},
    {label:'ขอบบน 9.0',data:w.map(()=>9),borderColor:C.red,borderDash:[6,4],pointRadius:0,borderWidth:1.5},
    {label:'ขอบล่าง 5.5',data:w.map(()=>5.5),borderColor:C.red,borderDash:[6,4],pointRadius:0,borderWidth:1.5}
  ]},options:{scales:{y:{beginAtZero:false,min:4,max:11}}}});
  mkChart('wwFail',{type:'bar',data:{labels:lb,datasets:[{label:'พารามิเตอร์ที่เกินมาตรฐาน',
    data:w.map(x=>x.fails.length),backgroundColor:w.map(x=>x.fails.length?C.red:C.green),borderRadius:5}]},
    options:{plugins:{legend:{display:false}},scales:{y:{ticks:{stepSize:1}}}}});
  $$('[data-wwv]').forEach(b=>b.onclick=()=>{
    const r=S().wastewater.find(x=>x.id===b.dataset.wwv);
    openModal('ผลตรวจน้ำทิ้ง '+thMonth(r.month),
      '<div class="row mb" style="gap:8px">'+badge(r.result,r.result==='ผ่าน'?'b-green':'b-red')+badge('ห้องปฏิบัติการ: '+r.lab,'b-gray')+'</div>'+
      '<div class="tbl-wrap"><table><thead><tr><th>รายการตรวจ</th><th>ผลตรวจ</th><th>หน่วย</th><th>มาตรฐาน</th><th>ผล</th></tr></thead><tbody>'+
      WW_PARAMS.map(p=>{ const v=r[p.k]; let ok=true;
        if(!p.text){ const n=Number(v); if(p.min!=null&&n<p.min) ok=false; if(p.max!=null&&n>p.max) ok=false; }
        return '<tr><td>'+esc(p.label)+'</td><td class="mono">'+(p.text?esc(v):num(v))+'</td><td class="tiny muted">'+esc(p.unit||'')+'</td>'+
        '<td class="tiny muted">'+esc(p.std)+'</td><td>'+(p.text||p.std==='เฝ้าระวัง'?'<span class="tiny muted">—</span>':badge(ok?'ผ่าน':'เกิน',ok?'b-green':'b-red'))+'</td></tr>'; }).join('')+
      '</tbody></table></div>'+
      '<div class="drop mt">'+esc(r.file||'ยังไม่ได้แนบเอกสารผลตรวจ')+'</div>',
      '<button class="btn" data-close="1">ปิด</button>',{width:'760px'});
  });
  $$('[data-ww]').forEach(b=>b.onclick=()=>{
    const r=S().wastewater.find(x=>x.id===b.dataset.ww);
    if(!can()){ toast('ต้องเป็น Safety Officer จึงจะบันทึกการแก้ไขได้',true); return; }
    openForm('บันทึกการแก้ไข — ผลตรวจ'+thMonth(r.month),[
      {key:'detail',label:'วิธีการแก้ไขที่ดำเนินการ',type:'textarea',full:true,required:true,value:r.fix?r.fix.detail:''},
      {key:'by',label:'ผู้ดำเนินการ',required:true,value:r.fix?r.fix.by:'',placeholder:'พิมพ์ชื่อ-นามสกุล หรือหน่วยงาน'},
      {key:'date',label:'วันที่ดำเนินการ',type:'date',required:true,value:r.fix?r.fix.date:iso(TODAY)},
      {key:'status',label:'สถานะการแก้ไข',type:'select',options:['อยู่ระหว่างแก้ไข','แก้ไขแล้ว'],value:r.fix?r.fix.status:'อยู่ระหว่างแก้ไข'},
      {key:'file',label:'เอกสารผลตรวจซ้ำ / หลักฐาน',type:'file',full:true}
    ],d=>{ r.fix=Object.assign({file:r.fix?r.fix.file:''},d);
      const a=S().actions.find(x=>x.ref===r.id);
      if(a){ a.status=d.status==='แก้ไขแล้ว'?'Closed':'In Progress'; a.progress=d.status==='แก้ไขแล้ว'?100:60; a.detail=d.detail; }
      Store.save(); toast('บันทึกการแก้ไขผลตรวจน้ำเสียแล้ว'); render(); },null,
      {intro:'<div class="card mb" style="background:var(--surface-2)"><div class="card-b small">พารามิเตอร์ที่เกินมาตรฐาน: <b>'+esc(r.fails.join(', '))+'</b></div></div>'});
  });
  const e=$('#expWw'); if(e) e.onclick=()=>exportCSV('wastewater-report.csv',
    [{label:'เดือน',key:'month'},{label:'Appearance',key:'appearance'}].concat(
      WW_PARAMS.filter(p=>!p.text).map(p=>({label:p.label,key:p.k}))).concat(
      [{label:'ผล',key:'result'},{label:'เกินมาตรฐาน',csv:r=>r.fails.join(' / ')},{label:'การแก้ไข',csv:r=>r.fix?r.fix.detail:''}]),S().wastewater);
};

/* ---- Inspection ---- */
V.inspection=function(){
  const ins=S().inspections;
  return '<div class="page-head"><div><h1>ผลการตรวจประเมินและ Audit</h1><p>รวมผลการตรวจจากหน่วยงานราชการ การตรวจสอบภายใน การตรวจภายนอก และการรับรองคุณภาพสถานพยาบาล</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="add-inspection">'+IC.plus+' บันทึกผลการตรวจ</button></div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'การตรวจประเมินทั้งหมด',value:ins.length,unit:'ครั้ง',tone:'info',foot:'ทุกประเภทหน่วยงานผู้ตรวจ'})+
    kpiCard({label:'ข้อสังเกตที่ยังไม่ปิด',value:ins.filter(i=>i.status!=='Closed').length,tone:'warn',foot:'ต้องติดตามการแก้ไข'})+
    kpiCard({label:'เกินกำหนดแก้ไข',value:ins.filter(i=>i.status==='Overdue').length,tone:ins.filter(i=>i.status==='Overdue').length?'crit':'good'})+
    kpiCard({label:'ปิดเรียบร้อยแล้ว',value:ins.filter(i=>i.status==='Closed').length,tone:'good',bar:Math.round(ins.filter(i=>i.status==='Closed').length/ins.length*100),barTone:'green'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    card('ผลการตรวจประเมินทั้งหมด','<div>'+ins.map(i=>
      '<div style="padding:14px 0;border-bottom:1px solid var(--line)">'+
        '<div class="row" style="justify-content:space-between"><div><b>'+esc(i.topic)+'</b>'+
        '<div class="tiny muted">'+esc(i.agency)+' · ตรวจเมื่อ '+thDate(i.date)+'</div></div>'+badge(statTh(i.status),statClass(i.status))+'</div>'+
        '<div class="small" style="margin-top:8px"><b>ข้อสังเกต:</b> '+esc(i.finding)+'</div>'+
        '<div class="small muted">ข้อเสนอแนะ: '+esc(i.rec)+'</div>'+
        '<div class="row mt" style="gap:8px">'+badge(i.type,'b-blue')+badge('ความรุนแรง: '+i.severity,sevClass(i.severity))+
        badge('วันที่แล้วเสร็จ '+thDate(i.due),'b-gray')+'<span class="tiny muted">ผู้รับผิดชอบ: '+esc(i.owner)+'</span>'+
        '<div class="spacer"></div><button class="btn btn-sm" data-ins="'+i.id+'">เอกสารแนบ</button></div></div>').join('')+'</div>')+
    '<div class="grid" style="gap:16px;align-content:start">'+
      chartCard('ข้อสังเกตแยกตามประเภทการตรวจ','insType','','chart-sm')+
      chartCard('ระดับความรุนแรงของข้อสังเกต','insSev','','chart-sm')+
    '</div>'+
  '</div>'+
  card('ตารางสรุปการติดตามข้อสังเกต',table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},{label:'วันที่ตรวจ',render:r=>'<span class="nowrap">'+thDate(r.date)+'</span>'},
    {label:'ประเภท',render:r=>badge(r.type,'b-blue')},{label:'หน่วยงานผู้ตรวจ',key:'agency'},
    {label:'ข้อสังเกต',render:r=>esc(r.finding)},
    {label:'ความรุนแรง',render:r=>badge(r.severity,sevClass(r.severity))},
    {label:'ผู้รับผิดชอบ',key:'owner',cls:'nowrap'},
    {label:'วันที่แล้วเสร็จ',render:r=>'<span class="nowrap">'+thDate(r.due)+'</span>'},
    {label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))}
  ],ins),{raw:true,actions:'<button class="btn btn-sm" id="expIns">ส่งออก CSV</button>'});
};
V.inspection.after=function(){
  const g=groupCount(S().inspections,'type'); const k=Object.keys(g);
  mkChart('insType',{type:'bar',data:{labels:k,datasets:[{data:k.map(x=>g[x]),backgroundColor:C.navy,borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{ticks:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor()},grid:{display:false}},x:{ticks:{stepSize:1}}}}});
  const gs=groupCount(S().inspections,'severity'); const ks=SEVERITY.filter(s=>gs[s]);
  mkChart('insSev',{type:'doughnut',data:{labels:ks,datasets:[{data:ks.map(s=>gs[s]),
    backgroundColor:ks.map(s=>s==='รุนแรง'||s==='วิกฤต'?C.red:s==='ปานกลาง'?C.amber:C.green),borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'bottom'}}}});
  $$('[data-ins]').forEach(b=>b.onclick=()=>{ const i=S().inspections.find(x=>x.id===b.dataset.ins);
    openModal('เอกสารและหลักฐานประกอบ — '+i.id,
      '<div class="small mb"><b>'+esc(i.topic)+'</b><div class="muted">'+esc(i.agency)+' · '+thDate(i.date)+'</div></div>'+
      i.files.map(f=>'<div class="stat-row"><span>'+esc(f)+'</span><button class="btn btn-sm">เปิดไฟล์</button></div>').join('')+
      '<div class="drop mt">อัปโหลดเอกสารหรือภาพหลักฐานเพิ่มเติม</div>','<button class="btn" data-close="1">ปิด</button>'); });
  const e=$('#expIns'); if(e) e.onclick=()=>exportCSV('inspection-report.csv',
    [{label:'รหัส',key:'id'},{label:'วันที่',key:'date'},{label:'ประเภท',key:'type'},{label:'หน่วยงาน',key:'agency'},{label:'หัวข้อ',key:'topic'},{label:'ข้อสังเกต',key:'finding'},{label:'ความรุนแรง',key:'severity'},{label:'ผู้รับผิดชอบ',key:'owner'},{label:'วันที่แล้วเสร็จ',key:'due'},{label:'สถานะ',key:'status'}],S().inspections);
};

/* ---- Accident database ---- */
let accFilter={dept:'',type:'',sev:'',pt:'',status:'',q:''};
V.accidents=function(){
  const all=S().events;
  const rows=all.filter(e=>
    (!accFilter.dept||e.dept===accFilter.dept)&&(!accFilter.type||e.type===accFilter.type)&&
    (!accFilter.sev||e.severity===accFilter.sev)&&(!accFilter.pt||e.personType===accFilter.pt)&&
    (!accFilter.status||e.status===accFilter.status)&&
    (!accFilter.q||(e.description+e.id+e.location+(e.person||'')).toLowerCase().includes(accFilter.q.toLowerCase())));
  const sel=(id,label,opts,val)=>'<select class="select" style="width:auto" data-f="'+id+'"><option value="">'+label+'</option>'+
    opts.map(o=>'<option'+(o===val?' selected':'')+'>'+esc(o)+'</option>').join('')+'</select>';
  return '<div class="page-head"><div><h1>ฐานข้อมูลอุบัติเหตุและอุบัติการณ์</h1><p>ค้นหา วิเคราะห์ และหาสาเหตุรากด้วยเครื่องมือ 5 Why และแผนภูมิก้างปลา</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="report-accident">'+IC.plus+' บันทึกอุบัติเหตุ</button></div>'+
  card('ตัวกรองข้อมูล','<div class="row">'+
    '<input class="input" style="flex:1;min-width:220px" placeholder="ค้นหารหัส สถานที่ ชื่อผู้เกี่ยวข้อง หรือรายละเอียด" data-f="q" value="'+esc(accFilter.q)+'">'+
    sel('dept','ทุกหน่วยงาน',DEPTS,accFilter.dept)+sel('type','ทุกประเภท',ACC_TYPE,accFilter.type)+
    sel('sev','ทุกระดับความรุนแรง',SEVERITY,accFilter.sev)+sel('pt','ทุกกลุ่มผู้เกี่ยวข้อง',PERSON_TYPE,accFilter.pt)+
    sel('status','ทุกสถานะ',['Open','In Progress','Pending Verification','Closed'],accFilter.status)+
    '<button class="btn" id="clrF">ล้างตัวกรอง</button></div>',{cls:'mb'})+
  '<div class="grid g4 mb">'+
    kpiCard({label:'ผลการค้นหา',value:rows.length,unit:'รายการ',tone:'info',foot:'จากทั้งหมด '+all.length+' เหตุการณ์'})+
    kpiCard({label:'อุบัติเหตุ',value:rows.filter(r=>r.kind==='accident').length,tone:'crit'})+
    kpiCard({label:'อุบัติการณ์',value:rows.filter(r=>r.kind==='incident').length,tone:'warn'})+
    kpiCard({label:'เหตุเกือบเกิด',value:rows.filter(r=>r.kind==='near_miss').length,tone:'good'})+
  '</div>'+
  '<div class="grid g2 mb">'+chartCard('แนวโน้มเหตุการณ์','aTrend','','chart-sm')+chartCard('แยกตามหน่วยงาน','aDept','','chart-sm')+'</div>'+
  '<div class="grid g2 mb">'+chartCard('แยกตามประเภทเหตุการณ์','aType','','chart-sm')+chartCard('แยกตามระดับความรุนแรง','aSev','','chart-sm')+'</div>'+
  card('ผลการค้นหา',table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},{label:'วันที่',render:r=>'<span class="nowrap">'+thDate(r.date)+'</span>'},
    {label:'หน่วยงาน',render:r=>'<span class="small">'+esc(r.dept)+'</span>'},{label:'สถานที่',key:'location'},{label:'ประเภท',key:'type'},
    {label:'ความรุนแรง',render:r=>badge(r.severity,sevClass(r.severity))},
    {label:'กลุ่มผู้เกี่ยวข้อง',key:'personType',cls:'nowrap'},
    {label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))},
    {label:'',render:r=>'<div class="row" style="flex-wrap:nowrap"><button class="btn btn-sm" data-ev="'+r.id+'">รายละเอียด</button><button class="btn btn-sm" data-rca="'+r.id+'">RCA</button></div>'}
  ],rows,{emptyTitle:'ไม่พบข้อมูลตามเงื่อนไข',empty:'ลองปรับตัวกรองหรือล้างเงื่อนไขการค้นหา'}),
  {raw:true,actions:'<button class="btn btn-sm" id="expAcc">ส่งออก CSV</button>'});
};
V.accidents.after=function(){
  $$('[data-f]').forEach(el=>{ const k=el.dataset.f;
    if(el.tagName==='SELECT') el.onchange=()=>{ accFilter[k]=el.value; render(); };
    else el.oninput=()=>{ clearTimeout(el._t); el._t=setTimeout(()=>{ const v=el.value; accFilter.q=v; render();
      const nx=document.querySelector('[data-f="q"]'); if(nx){ nx.focus(); nx.setSelectionRange(v.length,v.length); } },420); };
  });
  const c=$('#clrF'); if(c) c.onclick=()=>{ accFilter={dept:'',type:'',sev:'',pt:'',status:'',q:''}; render(); };
  mkChart('aTrend',{type:'line',data:{labels:last12Labels(),datasets:[
    {label:'อุบัติเหตุ',data:monthlyCount(S().events,e=>e.kind==='accident'),borderColor:C.red,tension:.3,pointRadius:3},
    {label:'อุบัติการณ์',data:monthlyCount(S().events,e=>e.kind==='incident'),borderColor:C.amber,tension:.3,pointRadius:3},
    {label:'เหตุเกือบเกิด',data:monthlyCount(S().events,e=>e.kind==='near_miss'),borderColor:C.green,tension:.3,pointRadius:3}
  ]},options:{scales:{y:{ticks:{stepSize:1}}}}});
  const gd=groupCount(S().events,'dept'),kd=Object.keys(gd);
  mkChart('aDept',{type:'bar',data:{labels:kd.map(x=>x.length>24?x.slice(0,24)+'…':x),datasets:[{data:kd.map(x=>gd[x]),backgroundColor:C.blue,borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{grid:{display:false},ticks:{font:{size:9,family:'IBM Plex Sans Thai'},color:tickColor()}},x:{ticks:{stepSize:1}}}}});
  const gt=groupCount(S().events,'type'),kt=Object.keys(gt);
  mkChart('aType',{type:'bar',data:{labels:kt,datasets:[{data:kt.map(x=>gt[x]),backgroundColor:C.navy,borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{grid:{display:false},ticks:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor()}},x:{ticks:{stepSize:1}}}}});
  const gs=groupCount(S().events,'severity'),ks=SEVERITY.filter(s=>gs[s]);
  mkChart('aSev',{type:'doughnut',data:{labels:ks,datasets:[{data:ks.map(x=>gs[x]),
    backgroundColor:ks.map(s=>s==='วิกฤต'?'#8E1717':s==='รุนแรง'?C.red:s==='ปานกลาง'?C.amber:C.green),borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'bottom'}}}});
  const e=$('#expAcc'); if(e) e.onclick=()=>exportCSV('accident-database.csv',
    [{label:'รหัส',key:'id'},{label:'วันที่',key:'date'},{label:'หน่วยงาน',key:'dept'},{label:'สถานที่',key:'location'},{label:'ประเภท',key:'type'},{label:'ความรุนแรง',key:'severity'},{label:'ผู้เกี่ยวข้อง',key:'personType'},{label:'สาเหตุราก',key:'rootCause'},{label:'สถานะ',key:'status'}],S().events);
};
function rcaModal(id){
  const e=S().events.find(x=>x.id===id); if(!e) return;
  const cats=Object.keys(e.fishbone);
  const W=760,H=380,spine=H/2;
  const bones=cats.map((c,i)=>{
    const top=i<3, col=i%3;
    const x=140+col*185, y=top?60:H-60;
    return '<line x1="'+x+'" y1="'+y+'" x2="'+(x+70)+'" y2="'+spine+'" stroke="var(--line-strong)" stroke-width="2"/>'+
      '<rect x="'+(x-62)+'" y="'+(top?y-26:y+4)+'" width="124" height="24" rx="7" fill="var(--navy)"/>'+
      '<text x="'+x+'" y="'+(top?y-9:y+21)+'" fill="#fff" font-size="12" text-anchor="middle">'+esc(c)+'</text>'+
      (e.fishbone[c]||[]).map((t,j)=>{ const yy= top? y+18+j*17 : y-22-j*17;
        return '<text x="'+(x-50)+'" y="'+yy+'" font-size="10.5" fill="var(--text-2)">• '+esc(t.slice(0,26))+'</text>'; }).join('');
  }).join('');
  openModal('การวิเคราะห์สาเหตุราก — '+e.id,
    '<div class="tabs mb" id="rcaTabs"><button class="tab active" data-t="why">5 Why Analysis</button><button class="tab" data-t="fish">Fishbone Diagram</button></div>'+
    '<div id="rcaWhy"><div class="small muted mb">เหตุการณ์: '+esc(e.description)+'</div>'+
      e.whys.filter(Boolean).map((w,i)=>'<div class="why-step"><div class="why-n">'+(i===0?'ปัญหา':'Why '+i)+'</div><div class="small">'+esc(w)+'</div></div>').join('')+
      '<div class="card mt" style="background:var(--sky);border-color:var(--sky-200)"><div class="card-b"><b class="small">สาเหตุรากที่สรุปได้</b><div class="small">'+esc(e.rootCause||'—')+'</div>'+
      '<b class="small" style="display:block;margin-top:10px">มาตรการแก้ไข</b><div class="small">'+esc(e.corrective||'—')+'</div></div></div></div>'+
    '<div id="rcaFish" hidden><div style="overflow-x:auto"><svg class="fishbone" viewBox="0 0 '+W+' '+H+'" style="width:100%;min-width:700px;height:'+H+'px">'+
      '<line x1="40" y1="'+spine+'" x2="'+(W-170)+'" y2="'+spine+'" stroke="var(--line-strong)" stroke-width="3"/>'+bones+
      '<rect x="'+(W-165)+'" y="'+(spine-30)+'" width="150" height="60" rx="10" fill="var(--red)"/>'+
      '<text x="'+(W-90)+'" y="'+(spine-6)+'" fill="#fff" font-size="12" text-anchor="middle">ปัญหา</text>'+
      '<text x="'+(W-90)+'" y="'+(spine+14)+'" fill="#fff" font-size="11" text-anchor="middle">'+esc(e.type)+'</text></svg></div></div>',
    '<button class="btn" data-close="1">ปิด</button>',{width:'900px'});
  $$('#rcaTabs .tab').forEach(t=>t.onclick=()=>{ $$('#rcaTabs .tab').forEach(x=>x.classList.remove('active')); t.classList.add('active');
    $('#rcaWhy').hidden=t.dataset.t!=='why'; $('#rcaFish').hidden=t.dataset.t!=='fish'; });
}

/* ---- Training ---- */
V.training=function(){
  const t=S().trainings; const m=metrics();
  const newT=t.filter(x=>x.type===TRAIN_TYPES[0]);
  const conT=t.filter(x=>x.type===TRAIN_TYPES[1]);
  const expired=conT.filter(x=>daysBetween(iso(TODAY),x.expiry)<0);
  const soon=conT.filter(x=>daysBetween(iso(TODAY),x.expiry)>=0&&daysBetween(iso(TODAY),x.expiry)<=7);
  return '<div class="page-head"><div><h1>การอบรมความปลอดภัย</h1><p>บันทึกการอบรมก่อนเริ่มงาน 2 ประเภท พร้อมหลักฐานผลการอบรม และควบคุมอายุการอบรมผู้รับเหมา 30 วัน</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="add-training">'+IC.plus+' บันทึกการอบรม</button></div>'+
  (soon.length||expired.length?'<div class="card mb" style="border-left:3px solid var(--amber)"><div class="card-b row" style="gap:14px">'+
    '<span style="color:var(--amber)">'+IC.alert.replace('<svg','<svg width="22" height="22"')+'</span>'+
    '<div><b>การอบรมผู้รับเหมาใกล้หมดอายุ '+soon.length+' รายการ · หมดอายุแล้ว '+expired.length+' รายการ</b>'+
    '<div class="small muted">ผู้รับเหมาที่การอบรมหมดอายุต้องลงทะเบียนอบรมใหม่ก่อนเข้าปฏิบัติงาน</div></div></div></div>':'')+
  '<div class="grid g4 mb">'+
    kpiCard({label:'พนักงานใหม่ที่ผ่านการอบรม',value:m.newStaffTrained,unit:'คน',tone:'good',icon:IC.book,foot:'จาก '+newT.length+' ครั้งการอบรม (12 เดือน)'})+
    kpiCard({label:'ผู้รับเหมาที่ผ่านการอบรม',value:m.contractorTrained,unit:'คน',tone:'info',icon:IC.users,foot:'จาก '+conT.length+' ครั้งการลงทะเบียน'})+
    kpiCard({label:'ผู้รับเหมาที่ยังไม่หมดอายุ',value:m.contractorActive,unit:'คน',tone:'good',foot:'อายุการอบรม 30 วันนับจากวันลงทะเบียน'})+
    kpiCard({label:'ใกล้หมดอายุภายใน 7 วัน',value:soon.length,unit:'รายการ',tone:soon.length?'warn':'good',foot:'หมดอายุแล้ว '+expired.length+' รายการ'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('จำนวนผู้เข้าอบรมรายเดือน','trMonth','แยกพนักงานใหม่และผู้รับเหมา','chart-lg')+
    chartCard('จำนวนครั้งการจัดอบรมรายเดือน','trCount','','chart-lg')+
  '</div>'+
  '<div class="grid g2">'+
    card('1. อบรมพนักงานใหม่ก่อนเริ่มงาน',table([
      {label:'วันที่',render:r=>'<span class="nowrap">'+thDate(r.date)+'</span>'},
      {label:'จำนวนผู้เข้าร่วม',render:r=>'<span class="mono">'+r.count+' คน</span>'},
      {label:'หัวข้อ',render:r=>'<span class="small">'+esc(r.topic)+'</span>'},
      {label:'หลักฐานผลการอบรม',render:r=>'<span class="badge b-blue plain tiny">'+esc(r.file)+'</span>'}
    ],newT),{raw:true,actions:'<button class="btn btn-sm" id="expTrN">ส่งออก CSV</button>'})+
    card('2. อบรมผู้รับเหมาก่อนเริ่มงาน',table([
      {label:'วันที่ Register',render:r=>'<span class="nowrap">'+thDate(r.date)+'</span>'},
      {label:'จำนวน',render:r=>'<span class="mono">'+r.count+' คน</span>'},
      {label:'บริษัทผู้รับเหมา',render:r=>'<span class="small">'+esc(r.note||'—')+'</span>'},
      {label:'วันหมดอายุ (30 วัน)',render:r=>'<span class="nowrap">'+thDate(r.expiry)+'</span>'},
      {label:'สถานะ',render:r=>{const d=daysBetween(iso(TODAY),r.expiry);
        return badge(d<0?'หมดอายุแล้ว':'เหลือ '+d+' วัน',d<0?'b-red':d<=7?'b-amber':'b-green');}},
      {label:'หลักฐาน',render:r=>'<span class="badge b-blue plain tiny">'+esc(r.file)+'</span>'}
    ],conT),{raw:true,actions:'<button class="btn btn-sm" id="expTrC">ส่งออก CSV</button>'})+
  '</div>';
};
V.training.after=function(){
  const L=last12();
  const sum=(type)=>L.map(x=>S().trainings.filter(t=>t.type===type&&ym(new Date(t.date))===x.key).reduce((s,t)=>s+t.count,0));
  const cnt=(type)=>L.map(x=>S().trainings.filter(t=>t.type===type&&ym(new Date(t.date))===x.key).length);
  mkChart('trMonth',{type:'bar',data:{labels:L.map(x=>x.label),datasets:[
    {label:'พนักงานใหม่ (คน)',data:sum(TRAIN_TYPES[0]),backgroundColor:C.blue,borderRadius:5},
    {label:'ผู้รับเหมา (คน)',data:sum(TRAIN_TYPES[1]),backgroundColor:C.amber,borderRadius:5}
  ]}});
  mkChart('trCount',{type:'line',data:{labels:L.map(x=>x.label),datasets:[
    {label:'อบรมพนักงานใหม่ (ครั้ง)',data:cnt(TRAIN_TYPES[0]),borderColor:C.blue,tension:.3,pointRadius:3},
    {label:'อบรมผู้รับเหมา (ครั้ง)',data:cnt(TRAIN_TYPES[1]),borderColor:C.amber,tension:.3,pointRadius:3}
  ]},options:{scales:{y:{ticks:{stepSize:1}}}}});
  const a=$('#expTrN'); if(a) a.onclick=()=>exportCSV('training-newstaff.csv',
    [{label:'วันที่',key:'date'},{label:'จำนวนผู้เข้าร่วม',key:'count'},{label:'หัวข้อ',key:'topic'},{label:'หลักฐาน',key:'file'}],S().trainings.filter(t=>t.type===TRAIN_TYPES[0]));
  const b=$('#expTrC'); if(b) b.onclick=()=>exportCSV('training-contractor.csv',
    [{label:'วันที่ Register',key:'date'},{label:'จำนวน',key:'count'},{label:'บริษัท',key:'note'},{label:'วันหมดอายุ',key:'expiry'},{label:'หลักฐาน',key:'file'}],S().trainings.filter(t=>t.type===TRAIN_TYPES[1]));
};

/* ---- Safety officers ---- */
V.officers=function(){
  const o=S().officers;
  const LEVELS=['จป.หัวหน้างาน','จป.เทคนิค','จป.เทคนิคขั้นสูง','จป.วิชาชีพ','จป.บริหาร'];
  const cnt=l=>o.filter(x=>x.level===l).length;
  const expiring=o.filter(x=>x.expiry&&daysBetween(iso(TODAY),x.expiry)<=180);
  return '<div class="page-head"><div><h1>ทะเบียนเจ้าหน้าที่ความปลอดภัยในการทำงาน</h1><p>ข้อมูลการแต่งตั้ง การอบรม และการขึ้นทะเบียน จป. ทุกระดับตามกฎกระทรวง</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" id="addSO">'+IC.plus+' เพิ่มทะเบียน จป.</button></div>'+
  '<div class="grid g4 mb">'+
    kpiCard({label:'จป. ทั้งหมด',value:o.length,unit:'คน',tone:'info',foot:'ครอบคลุม '+new Set(o.map(x=>x.dept)).size+' หน่วยงาน'})+
    kpiCard({label:'จป.วิชาชีพ',value:cnt('จป.วิชาชีพ'),unit:'คน',tone:cnt('จป.วิชาชีพ')>=2?'good':'warn',foot:'ตามกฎหมายต้องมีประจำสถานประกอบกิจการ'})+
    kpiCard({label:'จป.หัวหน้างาน',value:cnt('จป.หัวหน้างาน'),unit:'คน',tone:'good',foot:'ครอบคลุมทุกหน่วยงานที่มีลูกจ้าง'})+
    kpiCard({label:'ทะเบียนใกล้หมดอายุ',value:expiring.length,unit:'คน',tone:expiring.length?'warn':'good',foot:'ภายใน 180 วัน'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    chartCard('จำนวน จป. แยกตามระดับ','soLevel','','chart-sm')+
    card('การกระจายตัวตามหน่วยงาน','<div>'+Object.entries(groupCount(o,'dept')).sort((a,b)=>b[1]-a[1]).slice(0,8)
      .map(r=>'<div class="stat-row"><span class="small">'+esc(r[0].length>30?r[0].slice(0,30)+'…':r[0])+'</span><div class="row" style="gap:10px;min-width:120px"><div class="prog" style="flex:1"><span style="width:'+Math.min(100,r[1]/o.length*100*5)+'%"></span></div><b class="mono small">'+r[1]+' คน</b></div></div>').join('')+'</div>')+
  '</div>'+
  card('ทะเบียน จป.',table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},{label:'ชื่อ-นามสกุล',render:r=>'<b class="small">'+esc(r.name)+'</b><div class="tiny muted">'+esc(r.position)+'</div>'},
    {label:'หน่วยงาน',render:r=>'<span class="small">'+esc(r.dept)+'</span>'},
    {label:'ระดับ จป.',render:r=>badge(r.level,r.level==='จป.วิชาชีพ'?'b-blue':r.level==='จป.บริหาร'?'b-green':'b-gray')},
    {label:'วันที่อบรม',render:r=>'<span class="nowrap">'+thDate(r.trainDate)+'</span>'},
    {label:'วันที่แต่งตั้ง',render:r=>'<span class="nowrap">'+thDate(r.appointDate)+'</span>'},
    {label:'เลขทะเบียน',key:'regNo',cls:'mono nowrap'},
    {label:'วันหมดอายุ',render:r=>{ if(!r.expiry) return '<span class="muted">ไม่มีกำหนด</span>';
      const d=daysBetween(iso(TODAY),r.expiry); return '<span class="nowrap">'+thDate(r.expiry)+'</span> '+(d<180?badge(d<0?'หมดอายุ':'เหลือ '+d+' วัน',d<0?'b-red':'b-amber'):''); }},
    {label:'เอกสาร',render:r=>'<span class="tiny muted">'+r.files.length+' ไฟล์</span>'}
  ],o),{raw:true,actions:'<button class="btn btn-sm" id="expSO">ส่งออก CSV</button>'});
};
V.officers.after=function(){
  const LEVELS=['จป.หัวหน้างาน','จป.เทคนิค','จป.เทคนิคขั้นสูง','จป.วิชาชีพ','จป.บริหาร'];
  const o=S().officers;
  mkChart('soLevel',{type:'doughnut',data:{labels:LEVELS,datasets:[{data:LEVELS.map(l=>o.filter(x=>x.level===l).length),
    backgroundColor:[C.sky,C.blue,C.navy,C.green,C.teal],borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'right',labels:{font:{size:11,family:'IBM Plex Sans Thai'},color:tickColor(),usePointStyle:true,boxWidth:8}}}}});
  const e=$('#expSO'); if(e) e.onclick=()=>exportCSV('safety-officer-register.csv',
    [{label:'รหัส',key:'id'},{label:'ชื่อ',key:'name'},{label:'ตำแหน่ง',key:'position'},{label:'หน่วยงาน',key:'dept'},{label:'ระดับ',key:'level'},{label:'วันที่อบรม',key:'trainDate'},{label:'วันที่แต่งตั้ง',key:'appointDate'},{label:'เลขทะเบียน',key:'regNo'},{label:'หมดอายุ',key:'expiry'}],o);
  const a=$('#addSO'); if(a) a.onclick=()=>{ if(!guard()) return;
    openForm('เพิ่มทะเบียนเจ้าหน้าที่ความปลอดภัย',[
      {key:'name',label:'ชื่อ-นามสกุล',required:true},{key:'position',label:'ตำแหน่ง',required:true},
      {key:'dept',label:'หน่วยงาน',type:'select',options:DEPTS,required:true},
      {key:'level',label:'ระดับ จป.',type:'select',options:LEVELS,required:true},
      {key:'trainDate',label:'วันที่อบรม',type:'date',required:true},{key:'appointDate',label:'วันที่แต่งตั้ง',type:'date',required:true},
      {key:'regDate',label:'วันที่ขึ้นทะเบียน',type:'date'},{key:'regNo',label:'เลขทะเบียน'},
      {key:'expiry',label:'วันหมดอายุ (ถ้ามี)',type:'date'},{key:'files',label:'เอกสารประกอบ',type:'file',full:true}],d=>{
      S().officers.push(Object.assign({id:'SO-'+pad(S().officers.length+1),files:['หนังสือแต่งตั้ง.pdf']},d));
      Store.save(); toast('เพิ่มทะเบียน จป. เรียบร้อย'); render(); }); };
};

/* ---- Corrective action (CAPA) ---- */
let actFilter='';
function openSources(){
  const out=[];
  S().rounds.filter(r=>r.status!=='ดำเนินการเสร็จสิ้น').forEach(r=>out.push(
    {ref:r.id,source:'Safety Round',finding:r.issue,risk:r.risk,dept:r.dept,due:r.due,owner:r.owner,
     label:r.id+' — Safety Round · '+r.dept+' · '+r.issue.slice(0,45)}));
  S().events.filter(e=>e.status!=='Closed').forEach(e=>out.push(
    {ref:e.id,source:e.kind==='accident'?'Accident':(e.kind==='near_miss'?'Near Miss':'Incident'),
     finding:e.rootCause||e.description,risk:(e.severity==='รุนแรง'||e.severity==='วิกฤต')?'สูง':'ปานกลาง',dept:e.dept,due:e.due,owner:e.owner,
     label:e.id+' — '+(e.kind==='accident'?'อุบัติเหตุ':e.kind==='near_miss'?'เหตุเกือบเกิด':'อุบัติการณ์')+' · '+e.dept+' · '+(e.description||'').slice(0,40)}));
  S().inspections.filter(i=>i.status!=='Closed').forEach(i=>out.push(
    {ref:i.id,source:'Inspection',finding:i.finding,risk:i.severity==='สูง'?'สูง':'ปานกลาง',dept:'แผนกธุรการ',due:i.due,owner:i.owner,
     label:i.id+' — ผลตรวจประเมิน · '+i.agency.slice(0,28)+' · '+i.finding.slice(0,35)}));
  S().wastewater.filter(w=>w.result==='ไม่ผ่าน'&&(!w.fix||w.fix.status!=='แก้ไขแล้ว')).forEach(w=>out.push(
    {ref:w.id,source:'Wastewater',finding:'ผลตรวจน้ำเสีย '+thMonth(w.month)+' เกินมาตรฐาน: '+w.fails.join(', '),risk:'สูง',
     dept:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',due:iso(addDays(TODAY,14)),owner:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',
     label:'น้ำเสีย '+thMonth(w.month)+' — เกินมาตรฐาน: '+w.fails.join(', ')}));
  const used=S().actions.filter(a=>a.status!=='Closed').map(a=>a.ref);
  return out.filter(o=>used.indexOf(o.ref)<0).concat(out.filter(o=>used.indexOf(o.ref)>=0));
}
V.actions=function(){
  const a=S().actions.slice().sort((x,y)=>x.due.localeCompare(y.due));
  const rows=actFilter?a.filter(x=>x.status===actFilter):a;
  const m=metrics();
  const soon=a.filter(x=>x.status!=='Closed'&&x.status!=='Overdue'&&daysBetween(iso(TODAY),x.due)<=7&&daysBetween(iso(TODAY),x.due)>=0);
  const chip=(s,label)=>'<button class="btn btn-sm'+(actFilter===s?' btn-blue':'')+'" data-af="'+s+'">'+label+'</button>';
  return '<div class="page-head"><div><h1>ระบบติดตามการแก้ไขและป้องกัน (CAPA)</h1><p>รวมงานแก้ไขจากทุกโมดูล — Safety Round อุบัติเหตุ ผลตรวจประเมิน และคุณภาพน้ำเสีย</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" data-quick="add-action">'+IC.plus+' สร้างงานแก้ไข</button></div>'+
  (m.actOverdue?'<div class="card mb" style="border-left:3px solid var(--red)"><div class="card-b row" style="gap:14px">'+
    '<span style="color:var(--red)">'+IC.alert.replace('<svg','<svg width="22" height="22"')+'</span>'+
    '<div><b>มีงานแก้ไขเกินกำหนด '+m.actOverdue+' รายการ</b><div class="small muted">และอีก '+soon.length+' รายการจะถึงวันที่แล้วเสร็จภายใน 7 วัน</div></div>'+
    '<div class="spacer"></div><button class="btn btn-sm" data-af="Overdue">ดูเฉพาะที่เกินกำหนด</button></div></div>':'')+
  '<div class="grid g4 mb">'+
    kpiCard({label:'งานแก้ไขทั้งหมด',value:m.actTotal,tone:'info',foot:'จากทุกแหล่งที่มา'})+
    kpiCard({label:'ปิดงานแล้ว',value:m.actClosed,tone:'good',bar:Math.round(m.actClosed/m.actTotal*100),barTone:'green',foot:'อัตราการปิดงาน '+Math.round(m.actClosed/m.actTotal*100)+'%'})+
    kpiCard({label:'อยู่ระหว่างดำเนินการ',value:m.actOpen-m.actOverdue,tone:'warn',foot:'ใกล้ถึงกำหนด '+soon.length+' รายการ'})+
    kpiCard({label:'เกินกำหนด',value:m.actOverdue,tone:m.actOverdue?'crit':'good',foot:'ต้องรายงานคณะกรรมการความปลอดภัย'})+
  '</div>'+
  '<div class="grid g3 mb">'+
    chartCard('สถานะงานแก้ไข','caStatus','','chart-sm')+
    chartCard('แหล่งที่มาของงานแก้ไข','caSource','','chart-sm')+
    chartCard('ระดับความเสี่ยง','caRisk','','chart-sm')+
  '</div>'+
  card('ทะเบียนงานแก้ไข','<div class="row" style="padding:0 18px 14px">'+chip('','ทั้งหมด')+STATUS_ACT.map(s=>chip(s,statTh(s))).join('')+'</div>'+
  table([
    {label:'Action ID',key:'id',cls:'mono nowrap'},
    {label:'แหล่งที่มา',render:r=>badge(r.source,'b-blue')+'<div class="tiny muted mono">'+esc(r.ref)+'</div>'},
    {label:'ประเด็นที่พบ',render:r=>'<b class="small">'+esc(r.finding)+'</b><div class="tiny muted">'+esc((r.detail||'').slice(0,60))+'</div>'},
    {label:'ความเสี่ยง',render:r=>badge(r.risk,riskClass(r.risk))},
    {label:'ผู้รับผิดชอบ',render:r=>'<span class="small">'+esc(r.owner)+'</span>'},
    {label:'วันที่แล้วเสร็จ',render:r=>{const d=daysBetween(iso(TODAY),r.due);
      return '<span class="nowrap">'+thDate(r.due)+'</span>'+(r.status!=='Closed'?'<div class="tiny '+(d<0?'':'muted')+'"'+(d<0?' style="color:var(--red)"':'')+'>'+(d<0?'เกิน '+(-d)+' วัน':'เหลือ '+d+' วัน')+'</div>':'');}},
    {label:'ความคืบหน้า',render:r=>progress(r.progress,r.status==='Overdue'?'red':(r.progress>=100?'green':''))},
    {label:'รูปหลังแก้ไข',render:r=>photoTag(r.photoAfter,'มีรูป')},
    {label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))},
    {label:'',render:r=>can()?'<button class="btn btn-sm" data-act="'+r.id+'">อัปเดต</button>':''}
  ],rows),{raw:true,actions:'<button class="btn btn-sm" id="expAct">ส่งออก CSV</button>'});
};
V.actions.after=function(){
  $$('[data-af]').forEach(b=>b.onclick=()=>{ actFilter=b.dataset.af; render(); });
  const a=S().actions;
  const gs=groupCount(a,'status'), ks=STATUS_ACT.filter(s=>gs[s]);
  mkChart('caStatus',{type:'doughnut',data:{labels:ks.map(statTh),datasets:[{data:ks.map(s=>gs[s]),
    backgroundColor:ks.map(s=>s==='Closed'?C.green:s==='Overdue'?C.red:s==='In Progress'?C.blue:s==='Pending Verification'?C.amber:C.gray),borderWidth:0}]},
    options:{cutout:'58%',plugins:{legend:{position:'bottom',labels:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor(),usePointStyle:true,boxWidth:8}}}}});
  const gso=groupCount(a,'source'), kso=Object.keys(gso);
  mkChart('caSource',{type:'bar',data:{labels:kso,datasets:[{data:kso.map(s=>gso[s]),backgroundColor:C.navy,borderRadius:5}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{grid:{display:false},ticks:{font:{size:10,family:'IBM Plex Sans Thai'},color:tickColor()}}}}});
  const gr=groupCount(a,'risk'), kr=RISK.filter(r=>gr[r]);
  mkChart('caRisk',{type:'bar',data:{labels:kr,datasets:[{data:kr.map(r=>gr[r]),
    backgroundColor:kr.map(r=>r==='สูงมาก'||r==='สูง'?C.red:r==='ปานกลาง'?C.amber:C.blue),borderRadius:5}]},
    options:{plugins:{legend:{display:false}}}});
  $$('[data-act]').forEach(b=>b.onclick=()=>{
    const ac=S().actions.find(x=>x.id===b.dataset.act);
    openForm('อัปเดตงานแก้ไข '+ac.id,[
      {key:'finding',label:'ประเด็นที่พบ',type:'textarea',full:true,value:ac.finding},
      {key:'detail',label:'รายละเอียดการแก้ไข',type:'textarea',full:true,value:ac.detail},
      {key:'owner',label:'ผู้รับผิดชอบ',value:ac.owner,placeholder:'พิมพ์ชื่อ-นามสกุล'},
      {key:'due',label:'วันที่แล้วเสร็จ',type:'date',value:ac.due},
      {key:'progress',label:'ความคืบหน้า (%)',type:'number',value:ac.progress},
      {key:'status',label:'สถานะ',type:'select',options:STATUS_ACT,value:ac.status},
      {key:'photoAfter',label:'รูปภาพหลังการแก้ไข',type:'file',full:true,placeholder:'แนบรูปภาพหลังการแก้ไข (.jpg .png)'}],d=>{
      if(!guard()) return;
      Object.assign(ac,{finding:d.finding,detail:d.detail,owner:d.owner,due:d.due,progress:Number(d.progress),status:d.status});
      if(ac.status==='Closed'){ ac.progress=100; ac.photoAfter=1; }
      const r=S().rounds.find(x=>x.id===ac.ref);
      if(r&&ac.status==='Closed'){ r.status='ดำเนินการเสร็จสิ้น'; if(!r.doneDate) r.doneDate=iso(TODAY); r.photoAfter=1; r.fixDetail=d.detail; }
      Store.save(); toast('อัปเดตงานแก้ไข '+ac.id+' แล้ว'); render(); });
  });
  const e=$('#expAct'); if(e) e.onclick=()=>exportCSV('corrective-actions.csv',
    [{label:'Action ID',key:'id'},{label:'แหล่งที่มา',key:'source'},{label:'เลขที่อ้างอิง',key:'ref'},{label:'ประเด็น',key:'finding'},{label:'การแก้ไข',key:'detail'},{label:'ความเสี่ยง',key:'risk'},{label:'ผู้รับผิดชอบ',key:'owner'},{label:'วันที่แล้วเสร็จ',key:'due'},{label:'สถานะ',key:'status'},{label:'ความคืบหน้า',key:'progress'}],S().actions);
};
function addActionForm(){
  if(!guard()) return;
  const src=openSources();
  if(!src.length){ toast('ไม่มีเลขที่อ้างอิงที่ยังไม่ได้แก้ไขในระบบ',true); return; }
  const opts=[{value:'',label:'— เลือกเลขที่อ้างอิงที่ยังไม่ได้แก้ไข —'}].concat(src.map(s=>({value:s.ref,label:s.label})));
  openForm('สร้างงานแก้ไขใหม่',[
    {key:'ref',label:'เลขที่อ้างอิง (ดึงรายการที่ยังไม่ได้แก้ไขอัตโนมัติ)',type:'select',options:opts,required:true,full:true,id:'srcRef'},
    {key:'source',label:'แหล่งที่มา',type:'select',options:['Safety Round','Accident','Near Miss','Incident','Inspection','Wastewater','อื่น ๆ'],required:true,id:'srcType'},
    {key:'risk',label:'ระดับความเสี่ยง',type:'select',options:RISK3,required:true,id:'srcRisk'},
    {key:'finding',label:'ประเด็นที่พบ (ดึงอัตโนมัติ)',type:'textarea',full:true,required:true,id:'srcFinding'},
    {key:'detail',label:'แนวทางการแก้ไข',type:'textarea',full:true},
    {key:'dept',label:'หน่วยงาน',type:'select',options:DEPTS,required:true,id:'srcDept'},
    {key:'owner',label:'ผู้รับผิดชอบ',required:true,placeholder:'พิมพ์ชื่อ-นามสกุล',id:'srcOwner'},
    {key:'due',label:'วันที่แล้วเสร็จ',type:'date',required:true,value:iso(addDays(TODAY,14)),id:'srcDue'},
    {key:'photoAfter',label:'รูปภาพหลังการแก้ไข',type:'file',full:true,placeholder:'แนบรูปภาพหลังการแก้ไข (แนบภายหลังได้)'}
  ],d=>{
    S().actions.unshift(Object.assign({id:uid('CA'),status:'Open',progress:0,created:iso(TODAY),photoAfter:0},d));
    Store.save(); toast('สร้างงานแก้ไขแล้ว'); render();
  },null,{after:()=>{
    const sel=$('#srcRef');
    sel.onchange=()=>{ const s=src.find(x=>x.ref===sel.value); if(!s) return;
      $('#srcType').value=s.source; $('#srcFinding').value=s.finding; $('#srcRisk').value=s.risk||'ปานกลาง';
      $('#srcDue').value=s.due||iso(addDays(TODAY,14));
      $('#srcOwner').value=(DEPTS.indexOf(s.owner)>=0||!s.owner)?(s.owner||''):s.owner;
      if(DEPTS.indexOf(s.dept)>=0) $('#srcDept').value=s.dept;
      toast('ดึงข้อมูลจาก '+s.ref+' แล้ว');
    };
  }});
}

/* ---- Reports ---- */
V.reports=function(){
  const R=[
    ['Monthly Safety Report','สรุปผลการดำเนินงานความปลอดภัยประจำเดือน ครอบคลุมทุกตัวชี้วัด',IC.chart,'monthly'],
    ['Accident Report','รายงานอุบัติเหตุ อุบัติการณ์ IFR / ISR และการวิเคราะห์สาเหตุ',IC.alert,'accident'],
    ['Safety Round Report','ประเด็นที่พบจากการตรวจ Safety Round และสถานะการแก้ไข',IC.clipboard,'round'],
    ['KPI Report','ผลสำเร็จตามตัวชี้วัดเทียบเป้าหมายรายเดือนและรายปี',IC.chart,'kpi'],
    ['Training Report','สรุปการอบรมพนักงานใหม่และผู้รับเหมาก่อนเริ่มงาน',IC.book,'training'],
    ['Waste Report','ปริมาณและวิธีการจัดการขยะแต่ละประเภทรายเดือน',IC.trash,'waste'],
    ['Wastewater Report','ผลวิเคราะห์คุณภาพน้ำทิ้งและวิธีการแก้ไขเมื่อไม่ผ่านเกณฑ์',IC.drop,'wastewater'],
    ['Inspection Report','ผลการตรวจประเมินและสถานะการแก้ไข',IC.search,'inspection'],
    ['Corrective Action Report','สถานะงานแก้ไขทั้งหมดและงานที่เกินกำหนด',IC.wrench,'actions'],
    ['Safety Officer Report','ทะเบียน จป. และสถานะการขึ้นทะเบียน',IC.badge,'officers']
  ];
  return '<div class="page-head"><div><h1>ศูนย์รายงาน</h1><p>สร้างรายงานตามช่วงเวลาและส่งออกเป็นไฟล์ PDF หรือ Excel เพื่อเสนอคณะกรรมการความปลอดภัยและหน่วยงานภายนอก</p></div></div>'+
  card('กำหนดช่วงเวลารายงาน','<div class="row">'+
    '<div class="field" style="margin:0"><label>ตั้งแต่วันที่</label><input class="input" type="date" id="rFrom" value="'+iso(new Date(TODAY.getFullYear(),TODAY.getMonth(),1))+'"></div>'+
    '<div class="field" style="margin:0"><label>ถึงวันที่</label><input class="input" type="date" id="rTo" value="'+iso(TODAY)+'"></div>'+
    '<div class="field" style="margin:0;min-width:240px"><label>หน่วยงาน</label><select class="select" id="rDept"><option>ทุกหน่วยงาน</option>'+DEPTS.map(d=>'<option>'+esc(d)+'</option>').join('')+'</select></div>'+
    '<div class="field" style="margin:0"><label>รูปแบบ</label><select class="select" id="rFmt"><option>สรุปผู้บริหาร</option><option>รายละเอียดเต็ม</option></select></div></div>',{cls:'mb'})+
  '<div class="grid g3 mb">'+R.map(r=>'<div class="card"><div class="card-b">'+
    '<div class="row" style="align-items:flex-start;gap:12px"><div class="kpi-ic">'+r[2]+'</div>'+
    '<div><b class="small">'+esc(r[0])+'</b><div class="tiny muted" style="margin-top:3px">'+esc(r[1])+'</div></div></div>'+
    '<div class="row mt" style="gap:8px"><button class="btn btn-sm btn-primary" data-rep="'+r[3]+'">สร้างรายงาน</button>'+
    '<button class="btn btn-sm" data-repcsv="'+r[3]+'">'+IC.down.replace('<svg','<svg width="13" height="13"')+' Excel</button></div></div></div>').join('')+'</div>'+
  card('รายงานที่สร้างล่าสุด',table([
    {label:'ชื่อรายงาน',key:'name'},{label:'ช่วงเวลา',key:'period'},{label:'ผู้สร้าง',key:'by'},
    {label:'วันที่สร้าง',render:r=>thDate(r.date)},{label:'รูปแบบ',render:r=>badge(r.fmt,'b-blue')},
    {label:'',render:r=>'<button class="btn btn-sm">ดาวน์โหลด</button>'}
  ],[
    {name:'Monthly Safety Report',period:THMON_FULL[(TODAY.getMonth()+11)%12]+' '+(TODAY.getFullYear()+543),by:'ณัฐวุฒิ พงษ์สวัสดิ์',date:iso(addDays(TODAY,-6)),fmt:'PDF'},
    {name:'Corrective Action Report',period:'ไตรมาสปัจจุบัน',by:'สุภาพร ใจดีงาม',date:iso(addDays(TODAY,-13)),fmt:'Excel'},
    {name:'Wastewater Report',period:'12 เดือนย้อนหลัง',by:'ธนกฤต ศรีวิชัย',date:iso(addDays(TODAY,-20)),fmt:'PDF'},
    {name:'Training Report',period:'ปี '+(TODAY.getFullYear()+543),by:'ณัฐวุฒิ พงษ์สวัสดิ์',date:iso(addDays(TODAY,-31)),fmt:'Excel'}
  ]),{raw:true});
};
V.reports.after=function(){
  const csvMap={
    accident:['accident-report.csv',[{label:'รหัส',key:'id'},{label:'วันที่',key:'date'},{label:'หน่วยงาน',key:'dept'},{label:'ประเภท',key:'type'},{label:'ความรุนแรง',key:'severity'},{label:'วันสูญเสีย',key:'lostDays'},{label:'สถานะ',key:'status'}],()=>S().events],
    round:['safety-round-report.csv',[{label:'รหัส',key:'id'},{label:'วันที่ตรวจ',key:'date'},{label:'หน่วยงาน',key:'dept'},{label:'อาคาร/ชั้น',key:'building'},{label:'ประเด็น',key:'issue'},{label:'ความเสี่ยง',key:'risk'},{label:'สถานะ',key:'status'},{label:'วันที่เสร็จจริง',key:'doneDate'}],()=>S().rounds],
    kpi:['kpi-report.csv',[{label:'ตัวชี้วัด',key:'name'},{label:'เป้าหมาย',key:'target'},{label:'ผลจริง',key:'actual'},{label:'ความสำเร็จ',key:'achievement'},{label:'สถานะ',key:'status'}],()=>S().kpis],
    training:['training-report.csv',[{label:'ประเภท',key:'type'},{label:'วันที่',key:'date'},{label:'จำนวน',key:'count'},{label:'วันหมดอายุ',key:'expiry'},{label:'หลักฐาน',key:'file'}],()=>S().trainings],
    waste:['waste-report.csv',[{label:'เดือน',key:'month'},{label:'ประเภท',key:'type'},{label:'ปริมาณ',key:'qty'},{label:'ผู้รับกำจัด',key:'vendor'}],()=>S().waste],
    wastewater:['wastewater-report.csv',[{label:'เดือน',key:'month'},{label:'pH',key:'ph'},{label:'BOD',key:'bod'},{label:'TSS',key:'tss'},{label:'COD',key:'cod'},{label:'ผล',key:'result'},{label:'การแก้ไข',csv:r=>r.fix?r.fix.detail:''}],()=>S().wastewater],
    inspection:['inspection-report.csv',[{label:'รหัส',key:'id'},{label:'วันที่',key:'date'},{label:'หน่วยงาน',key:'agency'},{label:'ข้อสังเกต',key:'finding'},{label:'สถานะ',key:'status'}],()=>S().inspections],
    actions:['corrective-action-report.csv',[{label:'Action ID',key:'id'},{label:'แหล่งที่มา',key:'source'},{label:'อ้างอิง',key:'ref'},{label:'ประเด็น',key:'finding'},{label:'ผู้รับผิดชอบ',key:'owner'},{label:'วันที่แล้วเสร็จ',key:'due'},{label:'สถานะ',key:'status'}],()=>S().actions],
    officers:['safety-officer-report.csv',[{label:'ชื่อ',key:'name'},{label:'ระดับ',key:'level'},{label:'หน่วยงาน',key:'dept'},{label:'เลขทะเบียน',key:'regNo'}],()=>S().officers],
    monthly:['monthly-safety-report.csv',[{label:'ตัวชี้วัด',key:'name'},{label:'เป้าหมาย',key:'target'},{label:'ผลจริง',key:'actual'},{label:'ความสำเร็จ',key:'achievement'}],()=>S().kpis]
  };
  $$('[data-repcsv]').forEach(b=>b.onclick=()=>{ const c=csvMap[b.dataset.repcsv]; exportCSV(c[0],c[1],c[2]()); });
  $$('[data-rep]').forEach(b=>b.onclick=()=>previewReport(b.dataset.rep));
};
function previewReport(kind){
  const m=metrics(); const period=THMON_FULL[TODAY.getMonth()]+' '+(TODAY.getFullYear()+543);
  let body='';
  if(kind==='monthly'||kind==='kpi'){
    body='<div class="grid g4 mb">'+
      kpiCard({label:'วันปลอดอุบัติเหตุ',value:m.daysSafe,unit:'วัน',tone:'good'})+
      kpiCard({label:'IFR / ISR',value:m.ifr+' / '+m.isr,tone:'info'})+
      kpiCard({label:'KPI เฉลี่ย',value:m.kpiAvg+'%',tone:'info'})+
      kpiCard({label:'งานแก้ไขค้าง',value:m.actOpen,tone:'warn'})+'</div>'+
      table([{label:'ตัวชี้วัด',key:'name'},{label:'เป้าหมาย',render:r=>(r.lower?'≤ ':'')+num(r.target)+' '+r.unit},
        {label:'ผลจริง',render:r=>num(r.actual)+' '+r.unit},{label:'ความสำเร็จ',render:r=>r.achievement+'%'},
        {label:'สถานะ',render:r=>badge(r.status,r.achievement>=100?'b-green':r.achievement>=90?'b-amber':'b-red')}],S().kpis);
  } else if(kind==='accident'){
    body='<div class="grid g4 mb">'+kpiCard({label:'IFR',value:m.ifr,tone:'info'})+kpiCard({label:'ISR',value:m.isr,tone:'info'})+
      kpiCard({label:'อุบัติเหตุปีนี้',value:thisYear(S().events.filter(e=>e.kind==='accident')).length,tone:'warn'})+
      kpiCard({label:'วันสูญเสียรวม',value:ifrIsr().lost,unit:'วัน',tone:'warn'})+'</div>'+
      table([{label:'รหัส',key:'id',cls:'mono'},{label:'วันที่',render:r=>thDate(r.date)},{label:'หน่วยงาน',key:'dept'},
      {label:'ประเภท',key:'type'},{label:'ความรุนแรง',render:r=>badge(r.severity,sevClass(r.severity))},
      {label:'สาเหตุราก',key:'rootCause'}],S().events.filter(e=>e.kind==='accident'));
  } else if(kind==='round'){
    body=table([{label:'รหัส',key:'id',cls:'mono'},{label:'วันที่',render:r=>thDate(r.date)},{label:'หน่วยงาน',key:'dept'},
      {label:'อาคาร/ชั้น',key:'building'},{label:'ประเด็นที่พบ',key:'issue'},
      {label:'ความเสี่ยง',render:r=>badge(r.risk,riskClass(r.risk))},
      {label:'สถานะ',render:r=>badge(r.status,roundStatClass(r.status))}],S().rounds.slice(0,25));
  } else if(kind==='training'){
    body=table([{label:'ประเภท',key:'type'},{label:'วันที่',render:r=>thDate(r.date)},
      {label:'จำนวนผู้เข้าร่วม',render:r=>r.count+' คน'},{label:'วันหมดอายุ',render:r=>r.expiry?thDate(r.expiry):'—'},
      {label:'หลักฐาน',key:'file'}],S().trainings.slice(0,25));
  } else if(kind==='waste'){
    const curM=ym(TODAY); const month=S().waste.filter(x=>x.month===curM);
    body=table([{label:'ประเภท',key:'t'},{label:'ปริมาณเดือนนี้',render:r=>num(r.q)+' กก.'},{label:'วิธีการจัดการ',key:'m'}],
      WASTE_TYPES.map(t=>{const rec=month.filter(x=>x.type===t); return {t:t,q:rec.reduce((s,x)=>s+x.qty,0),m:rec[0]?rec[0].method:'—'};}));
  } else if(kind==='wastewater'){
    body=table([{label:'เดือน',render:r=>thMonth(r.month)},{label:'pH',key:'ph'},{label:'BOD',key:'bod'},{label:'TSS',key:'tss'},
      {label:'COD',key:'cod'},{label:'ผล',render:r=>badge(r.result,r.result==='ผ่าน'?'b-green':'b-red')},
      {label:'การแก้ไข',render:r=>esc(r.fix?r.fix.detail:'—')}],S().wastewater);
  } else if(kind==='inspection'){
    body=table([{label:'รหัส',key:'id',cls:'mono'},{label:'วันที่',render:r=>thDate(r.date)},{label:'หน่วยงานผู้ตรวจ',key:'agency'},
      {label:'ข้อสังเกต',key:'finding'},{label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))}],S().inspections);
  } else if(kind==='actions'){
    body=table([{label:'Action ID',key:'id',cls:'mono'},{label:'แหล่งที่มา',key:'source'},{label:'ประเด็น',key:'finding'},
      {label:'ผู้รับผิดชอบ',key:'owner'},{label:'วันที่แล้วเสร็จ',render:r=>thDate(r.due)},
      {label:'สถานะ',render:r=>badge(statTh(r.status),statClass(r.status))}],S().actions.slice(0,25));
  } else {
    body=table([{label:'ชื่อ',key:'name'},{label:'ระดับ',key:'level'},{label:'หน่วยงาน',key:'dept'},
      {label:'เลขทะเบียน',key:'regNo',cls:'mono'},{label:'หมดอายุ',render:r=>r.expiry?thDate(r.expiry):'ไม่มีกำหนด'}],S().officers);
  }
  openModal('ตัวอย่างรายงาน — '+period,
    '<div class="hero mb" style="padding:18px 20px"><h2 style="color:#fff;font-size:1.1rem">'+esc(HOSPITAL)+'</h2>'+
    '<div class="sub">รายงานความปลอดภัย ประจำ'+esc(period)+' · จัดทำโดย '+esc(S().settings.user)+' · พิมพ์เมื่อ '+thDate(iso(TODAY))+'</div></div>'+body,
    '<button class="btn" data-close="1">ปิด</button><button class="btn" id="printRep">พิมพ์ / บันทึกเป็น PDF</button>',{width:'960px'});
  $('#printRep').onclick=printReport;
}

/* ---- Notifications ---- */
V.notifications=function(){
  const n=buildNotifs();
  const g={red:'เร่งด่วน / วิกฤต',amber:'เฝ้าระวัง',blue:'ข้อมูลทั่วไป'};
  return '<div class="page-head"><div><h1>ศูนย์การแจ้งเตือน</h1><p>แจ้งเตือนอัตโนมัติจากทุกโมดูล ส่งถึงผู้รับผิดชอบทางอีเมลและในระบบ</p></div>'+
    '<div class="spacer"></div><button class="btn" id="setNotif">ตั้งค่าการแจ้งเตือน</button></div>'+
  '<div class="grid g3 mb">'+['red','amber','blue'].map(l=>kpiCard({label:g[l],value:n.filter(x=>x.level===l).length,unit:'รายการ',
    tone:l==='red'?'crit':l==='amber'?'warn':'info'})).join('')+'</div>'+
  ['red','amber','blue'].map(l=>{ const items=n.filter(x=>x.level===l); if(!items.length) return '';
    return card(g[l],'<div>'+items.map(x=>'<div class="notif-item" data-go="'+x.go.replace('#/','')+'">'+
      '<span class="ndot" style="background:'+(l==='red'?'var(--red)':l==='amber'?'var(--amber)':'var(--blue)')+'"></span>'+
      '<div style="flex:1"><b class="small">'+esc(x.title)+'</b><div class="tiny muted">'+esc(x.detail)+'</div></div>'+
      '<div class="tiny muted nowrap">'+thDate(x.when)+'</div></div>').join('')+'</div>',{raw:true,cls:'mb'});
  }).join('');
};
V.notifications.after=function(){
  const b=$('#setNotif'); if(b) b.onclick=()=>openModal('ตั้งค่าการแจ้งเตือน',
    ['อุบัติเหตุใหม่ที่บันทึกเข้าระบบ','ประเด็น Safety Round ความเสี่ยงสูง','งานแก้ไขใกล้ถึงวันที่แล้วเสร็จ (7 วัน)','งานแก้ไขเกินกำหนด',
     'การอบรมผู้รับเหมาใกล้หมดอายุ (30 วัน)','ผลตรวจน้ำเสียเกินมาตรฐาน','ข้อสังเกตจากการตรวจประเมินที่ยังไม่ปิด']
     .map(t=>'<div class="stat-row"><span>'+esc(t)+'</span><div class="row"><span class="tiny muted">อีเมล + ในระบบ</span>'+
     '<span class="badge b-green">เปิดใช้งาน</span></div></div>').join(''),'<button class="btn" data-close="1">ปิด</button>');
};

/* ---- Users & roles ---- */
V.users=function(){
  const u=S().users;
  return '<div class="page-head"><div><h1>ผู้ใช้งานและสิทธิ์</h1><p>ผู้ใช้งานทุกคนลงทะเบียนเข้าใช้ระบบด้วยสิทธิ์ “ดูอย่างเดียว” ยกเว้นผู้ที่ลงทะเบียนเป็น Safety Officer ที่แก้ไขข้อมูลได้ทุกโมดูล</p></div>'+
    '<div class="spacer"></div><button class="btn btn-primary" id="regUser">'+IC.plus+' ลงทะเบียนผู้ใช้งาน</button></div>'+
  (!can()?'<div class="card mb" style="border-left:3px solid var(--amber)"><div class="card-b small">'+
    'คุณกำลังใช้งานด้วยสิทธิ์ <b>ผู้ใช้งานทั่วไป</b> — ดูข้อมูลและรายงานได้อย่างเดียว หากต้องการทดลองสิทธิ์ Safety Officer เปลี่ยนได้จากเมนูมุมขวาบน</div></div>':'')+
  '<div class="grid g4 mb">'+
    kpiCard({label:'ผู้ใช้งานทั้งหมด',value:u.length,unit:'บัญชี',tone:'info'})+
    kpiCard({label:'Safety Officer (แก้ไขได้)',value:u.filter(x=>x.role==='Safety Officer').length,unit:'บัญชี',tone:'good',foot:'แก้ไขข้อมูลได้ทุกโมดูล'})+
    kpiCard({label:'ผู้ใช้งานทั่วไป (ดูอย่างเดียว)',value:u.filter(x=>x.role==='ผู้ใช้งานทั่วไป').length,unit:'บัญชี',tone:'info',foot:'สิทธิ์เริ่มต้นของการลงทะเบียน'})+
    kpiCard({label:'รออนุมัติ',value:u.filter(x=>x.status==='รออนุมัติ').length,unit:'บัญชี',tone:u.filter(x=>x.status==='รออนุมัติ').length?'warn':'good',foot:'Safety Officer เป็นผู้อนุมัติ'})+
  '</div>'+
  '<div class="grid g2 mb">'+
    card('สิทธิ์การใช้งาน','<div class="tbl-wrap"><table><thead><tr><th>บทบาท</th><th>ขอบเขตสิทธิ์</th></tr></thead><tbody>'+
      '<tr><td class="nowrap"><b>Safety Officer</b></td><td>'+
      ['บันทึก แก้ไข และลบข้อมูลได้ทุกโมดูล','ปิดงานแก้ไขและอนุมัติผลการดำเนินการ','อนุมัติผู้ใช้งานใหม่และกำหนดสิทธิ์','สร้างและส่งออกรายงานทุกประเภท']
        .map(x=>'<div class="small">• '+esc(x)+'</div>').join('')+'</td></tr>'+
      '<tr><td class="nowrap"><b>ผู้ใช้งานทั่วไป</b></td><td>'+
      ['ดูข้อมูลได้ทุกโมดูล','ดูและส่งออกรายงานได้','ไม่สามารถเพิ่ม แก้ไข หรือลบข้อมูลใด ๆ','สิทธิ์เริ่มต้นเมื่อลงทะเบียนเข้าใช้ระบบ']
        .map(x=>'<div class="small">• '+esc(x)+'</div>').join('')+'</td></tr></tbody></table></div>',{raw:true})+
    card('หน่วยงานในระบบ ('+S().departments.length+' หน่วยงาน)','<div style="max-height:320px;overflow-y:auto">'+
      S().departments.map(d=>'<div class="stat-row"><span class="small">'+esc(d.name)+'</span><span class="tiny muted mono">'+d.staff+' คน</span></div>').join('')+'</div>')+
  '</div>'+
  card('บัญชีผู้ใช้งาน',table([
    {label:'รหัส',key:'id',cls:'mono nowrap'},{label:'ชื่อ-นามสกุล',key:'name'},
    {label:'หน่วยงาน',render:r=>'<span class="small">'+esc(r.dept)+'</span>'},
    {label:'อีเมล',key:'email'},
    {label:'สิทธิ์',render:r=>badge(r.role,r.role==='Safety Officer'?'b-blue':'b-gray')},
    {label:'วันที่ลงทะเบียน',render:r=>'<span class="nowrap">'+thDate(r.regDate)+'</span>'},
    {label:'สถานะ',render:r=>badge(r.status,r.status==='อนุมัติแล้ว'?'b-green':'b-amber')},
    {label:'',render:r=>can()?'<button class="btn btn-sm" data-user="'+r.id+'">จัดการสิทธิ์</button>':''}
  ],u),{raw:true});
};
V.users.after=function(){
  $$('[data-user]').forEach(b=>b.onclick=()=>{
    const u=S().users.find(x=>x.id===b.dataset.user);
    openForm('จัดการสิทธิ์ผู้ใช้ '+u.name,[
      {key:'name',label:'ชื่อ-นามสกุล',value:u.name,required:true},
      {key:'dept',label:'หน่วยงาน',type:'select',options:DEPTS,value:u.dept},
      {key:'email',label:'อีเมล',type:'email',value:u.email},
      {key:'role',label:'สิทธิ์การใช้งาน',type:'select',options:ROLES,value:u.role,hint:'เฉพาะ Safety Officer เท่านั้นที่แก้ไขข้อมูลได้'},
      {key:'status',label:'สถานะบัญชี',type:'select',options:['อนุมัติแล้ว','รออนุมัติ','ระงับการใช้งาน'],value:u.status}],d=>{
      if(!guard()) return; Object.assign(u,d); Store.save(); toast('อัปเดตสิทธิ์ผู้ใช้แล้ว'); render(); });
  });
  const a=$('#regUser'); if(a) a.onclick=()=>openForm('ลงทะเบียนเข้าใช้งานระบบ',[
    {key:'name',label:'ชื่อ-นามสกุล',required:true},
    {key:'dept',label:'หน่วยงาน',type:'select',options:DEPTS,required:true},
    {key:'email',label:'อีเมล',type:'email',required:true},
    {key:'role',label:'ขอสิทธิ์การใช้งาน',type:'select',options:ROLES,value:'ผู้ใช้งานทั่วไป',
      hint:'ค่าเริ่มต้นคือดูอย่างเดียว — การขอสิทธิ์ Safety Officer ต้องได้รับการอนุมัติ'}],d=>{
    const needApprove= d.role==='Safety Officer';
    S().users.push(Object.assign({id:'U'+pad(S().users.length+1),regDate:iso(TODAY),
      status: needApprove?'รออนุมัติ':'อนุมัติแล้ว'},d));
    Store.save(); toast(needApprove?'ลงทะเบียนแล้ว — รอ Safety Officer อนุมัติสิทธิ์':'ลงทะเบียนสำเร็จ — สิทธิ์ดูข้อมูลอย่างเดียว'); render(); },null,
    {intro:'<div class="card mb" style="background:var(--surface-2)"><div class="card-b small">ผู้ลงทะเบียนทุกคนจะได้รับสิทธิ์ดูข้อมูลอย่างเดียวโดยอัตโนมัติ การขอสิทธิ์ Safety Officer ซึ่งแก้ไขข้อมูลได้ทุกโมดูล ต้องรอการอนุมัติ</div></div>'});
};

/* ---- Database structure ---- */
V.database=function(){
  const T=[
    ['users','ผู้ใช้งานระบบ',[['id','PK'],['name',''],['email',''],['role','Safety Officer / ผู้ใช้งานทั่วไป'],['department_id','FK → departments'],['status','']]],
    ['departments','หน่วยงาน (53 รายการ)',[['id','PK'],['name',''],['head_user_id','FK → users'],['staff_count','']]],
    ['buildings','อาคาร/ชั้น',[['id','PK'],['name',''],['zone','']]],
    ['accidents','อุบัติเหตุ',[['id','PK'],['occurred_at',''],['department_id','FK'],['location',''],['type',''],['severity',''],['person_type',''],['lost_days','ใช้คำนวณ ISR'],['root_cause',''],['status','']]],
    ['near_misses','เหตุเกือบเกิด',[['id','PK'],['occurred_at',''],['department_id','FK'],['description',''],['risk_level',''],['status','']]],
    ['incidents','อุบัติการณ์',[['id','PK'],['occurred_at',''],['department_id','FK'],['type',''],['severity',''],['status','']]],
    ['safety_rounds','บันทึก Safety Round',[['id','PK'],['round_date',''],['department_id','FK'],['building',''],['inspector',''],['issue',''],['risk_level','สูง/ปานกลาง/ต่ำ'],['owner',''],['due_date',''],['status',''],['done_date',''],['photo_before_id','FK → documents'],['photo_after_id','FK → documents'],['note','']]],
    ['kpis','ตัวชี้วัด',[['id','PK'],['name',''],['target',''],['unit',''],['actual',''],['month',''],['year',''],['owner','']]],
    ['waste_records','บันทึกขยะรายเดือน',[['id','PK'],['month','YYYY-MM'],['waste_type',''],['quantity',''],['unit',''],['method',''],['vendor',''],['recorded_by','FK → users']]],
    ['wastewater_records','ผลตรวจน้ำเสียรายเดือน',[['id','PK'],['month','YYYY-MM'],['appearance',''],['ph',''],['bod',''],['tss',''],['tds',''],['settleable',''],['sulfide',''],['tkn',''],['oil_grease',''],['total_coliform',''],['fecal_coliform',''],['chlorine',''],['cod',''],['ecoli',''],['parasite_egg',''],['result',''],['lab_file_id','FK → documents']]],
    ['wastewater_fixes','การแก้ไขเมื่อผลไม่ผ่าน',[['id','PK'],['record_id','FK → wastewater_records'],['detail',''],['fixed_by',''],['fixed_date',''],['status',''],['evidence_id','FK → documents']]],
    ['inspections','ผลการตรวจประเมิน',[['id','PK'],['inspect_date',''],['agency',''],['type',''],['finding',''],['severity',''],['owner',''],['due_date',''],['status','']]],
    ['trainings','การอบรมก่อนเริ่มงาน',[['id','PK'],['type','พนักงานใหม่ / ผู้รับเหมา'],['train_date',''],['participant_count',''],['topic',''],['expiry_date','ผู้รับเหมา = +30 วัน'],['evidence_id','FK → documents']]],
    ['safety_officers','ทะเบียน จป.',[['id','PK'],['user_id','FK → users'],['level',''],['appoint_date',''],['register_no',''],['expiry_date','']]],
    ['corrective_actions','งานแก้ไข (CAPA)',[['id','PK'],['source_type',''],['source_id','polymorphic'],['finding',''],['risk_level',''],['owner',''],['due_date','วันที่แล้วเสร็จ'],['progress',''],['status',''],['photo_after_id','FK → documents']]],
    ['notifications','การแจ้งเตือน',[['id','PK'],['user_id','FK → users'],['type',''],['title',''],['ref_table',''],['ref_id',''],['read_at','']]],
    ['documents','เอกสาร/รูปภาพแนบ',[['id','PK'],['owner_table',''],['owner_id',''],['file_name',''],['file_path',''],['uploaded_by','FK → users']]],
    ['work_hours','ชั่วโมงการทำงาน (IFR/ISR)',[['id','PK'],['year',''],['month',''],['manpower',''],['total_hours','']]]
  ];
  const REL=[
    'departments 1 — N safety_rounds / accidents / incidents',
    'safety_rounds 1 — 1 corrective_actions (source_type = Safety Round)',
    'accidents / incidents / inspections / wastewater_records 1 — N corrective_actions (polymorphic: source_type + source_id)',
    'wastewater_records 1 — 1 wastewater_fixes (บันทึกวิธีการแก้ไขเมื่อผลไม่ผ่านเกณฑ์)',
    'trainings แยกประเภทด้วยคอลัมน์ type และคำนวณ expiry_date = train_date + 30 วัน สำหรับผู้รับเหมา',
    'work_hours ใช้คำนวณ IFR = จำนวนครั้งบาดเจ็บ × 1,000,000 ÷ total_hours และ ISR = วันสูญเสีย × 1,000,000 ÷ total_hours',
    'users.role กำหนดสิทธิ์: Safety Officer เขียนได้ ผู้ใช้งานทั่วไปอ่านอย่างเดียว',
    'documents เชื่อมแบบ polymorphic กับทุกตารางผ่าน owner_table + owner_id (รูปก่อน/หลังการแก้ไข)'
  ];
  return '<div class="page-head"><div><h1>โครงสร้างฐานข้อมูลและสถาปัตยกรรมระบบ</h1><p>ออกแบบให้ต่อยอดเป็นระบบใช้งานจริงของ '+esc(HOSPITAL)+' โดยเปลี่ยนชั้นข้อมูลจาก Local Storage เป็น REST API และฐานข้อมูลเชิงสัมพันธ์</p></div>'+
    '<div class="spacer"></div><button class="btn" id="resetDb">รีเซ็ตข้อมูลตัวอย่าง</button></div>'+
  card('สถาปัตยกรรมที่ออกแบบไว้','<div class="grid g3">'+[
    ['ชั้นหน้าจอ (Presentation)','Single Page Application แยก View ต่อโมดูล เรนเดอร์จากชั้นข้อมูลชั้นเดียว ปรับเป็น React หรือ Vue ได้โดยไม่ต้องรื้อ Logic'],
    ['ชั้นข้อมูล (Data Layer)','ทุกโมดูลอ่าน-เขียนผ่านอ็อบเจกต์ Store เพียงจุดเดียว เปลี่ยนไปเรียก REST/GraphQL ได้โดยแก้เฉพาะเมธอด load/save'],
    ['ชั้นฐานข้อมูล (Database)','18 ตารางหลักตามมาตรฐาน 3NF พร้อมความสัมพันธ์แบบ polymorphic สำหรับงานแก้ไขและเอกสารแนบ'],
    ['การยืนยันตัวตน','รองรับ SSO ของโรงพยาบาลหรือ JWT โดยตรวจสิทธิ์จาก users.role ทั้งที่หน้าจอและที่ API'],
    ['การแจ้งเตือน','งานตามกำหนดเวลา (cron) ตรวจวันครบกำหนดและวันหมดอายุการอบรมผู้รับเหมาทุกเช้า แล้วส่งอีเมลและแจ้งเตือนในระบบ'],
    ['การเชื่อมต่อภายนอก','เตรียมจุดเชื่อมกับระบบ HR ระบบบุคลากร และไฟล์ผลตรวจจากห้องปฏิบัติการภายนอก']
  ].map(x=>'<div class="tbl-card"><h4>'+esc(x[0])+'</h4><div style="padding:10px 12px" class="small">'+esc(x[1])+'</div></div>').join('')+'</div>',{cls:'mb'})+
  card('ตารางหลักในระบบ','<div class="schema">'+T.map(t=>'<div class="tbl-card"><h4>'+esc(t[0])+'<span class="tiny" style="opacity:.75">'+esc(t[1])+'</span></h4>'+
    '<ul>'+t[2].map(c=>'<li><b>'+esc(c[0])+'</b><span class="k">'+esc(c[1])+'</span></li>').join('')+'</ul></div>').join('')+'</div>',{cls:'mb'})+
  '<div class="grid g2">'+
    card('ความสัมพันธ์ระหว่างตาราง','<div>'+REL.map(r=>'<div class="stat-row"><span class="small">'+esc(r)+'</span></div>').join('')+'</div>')+
    card('ตัวอย่าง API Endpoint ที่รองรับ','<div>'+[
      ['GET','/api/dashboard/summary','ข้อมูลสรุปสำหรับหน้าแรก'],['GET','/api/safety-rounds?dept=&status=','ค้นหาประเด็น Safety Round'],
      ['POST','/api/safety-rounds','บันทึกประเด็นและสร้างงานแก้ไขอัตโนมัติ'],['PATCH','/api/safety-rounds/:id','บันทึกผลการแก้ไขและแนบรูปหลังแก้ไข'],
      ['GET','/api/kpis?year=','ผลตัวชี้วัดรายปี'],['GET','/api/stats/ifr-isr?year=','คำนวณ IFR และ ISR'],
      ['POST','/api/wastewater','บันทึกผลตรวจรายเดือนพร้อมไฟล์ผลวิเคราะห์'],['POST','/api/trainings','บันทึกการอบรมและคำนวณวันหมดอายุ'],
      ['POST','/api/documents','อัปโหลดเอกสารหรือรูปภาพหลักฐาน'],['GET','/api/reports/monthly.pdf','สร้างรายงานประจำเดือน']
    ].map(r=>'<div class="stat-row"><span><span class="badge '+(r[0]==='GET'?'b-blue':r[0]==='POST'?'b-green':'b-amber')+' plain tiny mono">'+r[0]+'</span> <span class="mono small">'+esc(r[1])+'</span></span><span class="tiny muted">'+esc(r[2])+'</span></div>').join('')+'</div>')+
  '</div>';
};
V.database.after=function(){
  const b=$('#resetDb'); if(b) b.onclick=()=>{
    openModal('รีเซ็ตข้อมูลตัวอย่าง','<p class="small">ข้อมูลที่บันทึกไว้ทั้งหมดในเบราว์เซอร์นี้จะถูกล้างและแทนที่ด้วยชุดข้อมูลตัวอย่างเริ่มต้น การกระทำนี้ย้อนกลับไม่ได้</p>',
      '<button class="btn" data-close="1">ยกเลิก</button><button class="btn btn-primary" id="doReset">ล้างและเริ่มใหม่</button>');
    $('#doReset').onclick=()=>{ Store.reset(); closeModal(); toast('รีเซ็ตข้อมูลเรียบร้อย'); render(); };
  };
};

/* =========================================================
   Quick actions
   ========================================================= */
function quick(kind){
  if(kind==='report-accident'){ if(!guard())return; openForm('บันทึกอุบัติเหตุ',EVENT_FIELDS(),d=>addEvent('accident',d)); }
  else if(kind==='add-nearmiss'){ if(!guard())return; openForm('บันทึกเหตุเกือบเกิด (Near Miss)',EVENT_FIELDS(),d=>addEvent('near_miss',d)); }
  else if(kind==='add-incident'){ if(!guard())return; openForm('บันทึกอุบัติการณ์',EVENT_FIELDS(),d=>addEvent('incident',d)); }
  else if(kind==='add-round'){ if(!guard())return;
    openForm('บันทึกประเด็นจากการตรวจ Safety Round',[
      {key:'date',label:'วันที่ตรวจ',type:'date',required:true,value:iso(TODAY)},
      {key:'dept',label:'หน่วยงาน/พื้นที่',type:'select',options:DEPTS,required:true},
      {key:'building',label:'อาคาร/ชั้น',type:'select',options:BUILDINGS,required:true},
      {key:'inspector',label:'ผู้ตรวจประเมิน',type:'select',options:INSPECTORS,required:true},
      {key:'issue',label:'ประเด็น/ความเสี่ยงที่พบ',type:'textarea',full:true,required:true},
      {key:'risk',label:'ระดับความเสี่ยง',type:'select',options:RISK3,required:true},
      {key:'owner',label:'ผู้รับผิดชอบแก้ไข',required:true,placeholder:'พิมพ์ชื่อหน่วยงานหรือชื่อ-นามสกุล'},
      {key:'due',label:'กำหนดแล้วเสร็จ',type:'date',required:true,value:iso(addDays(TODAY,14))},
      {key:'status',label:'สถานะดำเนินการ',type:'select',options:ROUND_STATUS,value:'ยังไม่เริ่มดำเนินการ'},
      {key:'note',label:'หมายเหตุ',type:'textarea',full:true},
      {key:'photo',label:'รูปภาพประกอบ',type:'file',full:true,placeholder:'แนบรูปภาพจุดที่พบประเด็น (.jpg .png)'}
    ],d=>{
      const id='SR-'+d.date.slice(0,4)+'-'+pad(S().rounds.length+1);
      S().rounds.unshift(Object.assign({id:id,photo:1,doneDate:'',photoAfter:0,fixDetail:''},d));
      S().actions.unshift({id:uid('CA'),source:'Safety Round',ref:id,finding:d.issue,risk:d.risk,owner:d.owner,
        due:d.due,dept:d.dept,status:'Open',progress:0,detail:'',created:iso(TODAY),photoAfter:0});
      Store.save(); toast('บันทึกประเด็น '+id+' และสร้างงานแก้ไขอัตโนมัติแล้ว'); render(); }); }
  else if(kind==='add-action'){ addActionForm(); }
  else if(kind==='add-training'){ if(!guard())return;
    openForm('บันทึกการอบรมก่อนเริ่มงาน',[
      {key:'type',label:'ประเภทการอบรม',type:'select',options:TRAIN_TYPES,required:true,full:true,
        hint:'อบรมผู้รับเหมาจะมีวันหมดอายุ 30 วันนับจากวันที่ Register'},
      {key:'date',label:'วันที่อบรม / Register',type:'date',required:true,value:iso(TODAY)},
      {key:'count',label:'จำนวนผู้เข้าร่วมอบรม (คน)',type:'number',required:true},
      {key:'topic',label:'หัวข้อการอบรม',full:true,value:'ความปลอดภัยพื้นฐาน อาชีวอนามัยและสภาพแวดล้อมในการทำงาน'},
      {key:'note',label:'หมายเหตุ / บริษัทผู้รับเหมา',full:true},
      {key:'file',label:'แนบ Excel หรือรูปผลการอบรม',type:'file',full:true,placeholder:'แนบไฟล์ผลการอบรมเพื่อเป็นหลักฐาน (.xlsx .jpg .png .pdf)'}
    ],d=>{
      const rec=Object.assign({id:uid('TR'),trainer:'หน่วยบริหารความปลอดภัย อาชีวอนามัยและสิ่งแวดล้อม',
        file:d.type===TRAIN_TYPES[1]?('ทะเบียนผู้รับเหมา_'+d.date+'.xlsx'):('ผลการอบรมพนักงานใหม่_'+d.date+'.xlsx')},d,
        {count:Number(d.count),expiry: d.type===TRAIN_TYPES[1]?iso(addDays(new Date(d.date),30)):''});
      S().trainings.unshift(rec); S().trainings.sort((a,b)=>b.date.localeCompare(a.date));
      Store.save(); toast(d.type===TRAIN_TYPES[1]?('บันทึกแล้ว — หมดอายุวันที่ '+thDate(rec.expiry)):'บันทึกการอบรมพนักงานใหม่แล้ว'); render(); }); }
  else if(kind==='add-inspection'){ if(!guard())return;
    openForm('บันทึกผลการตรวจประเมิน',[
      {key:'date',label:'วันที่ตรวจ',type:'date',required:true,value:iso(TODAY)},
      {key:'type',label:'ประเภทการตรวจ',type:'select',options:['หน่วยงานราชการ','Internal Audit','External Audit','Hospital Accreditation','Environmental / Safety Inspection','อื่น ๆ'],required:true},
      {key:'agency',label:'หน่วยงานผู้ตรวจ',required:true,full:true},
      {key:'topic',label:'หัวข้อการตรวจ',required:true,full:true},
      {key:'finding',label:'ข้อสังเกต / Finding',type:'textarea',full:true,required:true},
      {key:'severity',label:'ระดับความรุนแรง',type:'select',options:SEVERITY,required:true},
      {key:'rec',label:'ข้อเสนอแนะ',type:'textarea',full:true},
      {key:'ca',label:'แนวทางแก้ไข',type:'textarea',full:true},
      {key:'owner',label:'ผู้รับผิดชอบ',required:true,placeholder:'พิมพ์ชื่อ-นามสกุล'},
      {key:'due',label:'วันที่แล้วเสร็จ',type:'date',required:true,value:iso(addDays(TODAY,30))},
      {key:'files',label:'เอกสาร/ภาพหลักฐาน',type:'file',full:true}
    ],d=>{
      const id='INS-'+pad(S().inspections.length+1);
      S().inspections.unshift(Object.assign({id:id,status:'In Progress',files:['เอกสารแนบ.pdf']},d));
      S().actions.unshift({id:uid('CA'),source:'Inspection',ref:id,finding:d.finding,
        risk:(d.severity==='รุนแรง'||d.severity==='วิกฤต')?'สูง':'ปานกลาง',owner:d.owner,due:d.due,dept:'แผนกธุรการ',
        status:'Open',progress:0,detail:d.ca,created:d.date,photoAfter:0});
      Store.save(); toast('บันทึกผลการตรวจและสร้างงานแก้ไขแล้ว'); render(); }); }
  else if(kind==='add-waste'){ if(!guard())return;
    openForm('บันทึกปริมาณขยะ',[
      {key:'month',label:'เดือน',type:'month',required:true,value:ym(TODAY)},
      {key:'type',label:'ประเภทขยะ',type:'select',options:WASTE_TYPES,required:true},
      {key:'qty',label:'ปริมาณ',type:'number',required:true},
      {key:'unit',label:'หน่วย',type:'select',options:['กก.','ลิตร','ชิ้น']},
      {key:'method',label:'วิธีการจัดการ',type:'select',options:['เผาในเตาเผาขยะติดเชื้อ','ฝังกลบ/เทศบาล','ส่งจำหน่ายผู้รับซื้อ','ส่งกำจัดโดยผู้รับอนุญาต'],required:true},
      {key:'vendor',label:'ผู้รับกำจัด',required:true},
      {key:'recorder',label:'ผู้บันทึก',required:true,value:S().settings.user,placeholder:'พิมพ์ชื่อ-นามสกุล'}
    ],d=>{ S().waste.unshift(Object.assign({id:uid('WS')},d,{qty:+d.qty}));
      Store.save(); toast('บันทึกปริมาณขยะประจำเดือน'+thMonth(d.month)+'แล้ว'); render(); }); }
  else if(kind==='add-ww'){ if(!guard())return;
    openForm('บันทึกผลตรวจคุณภาพน้ำทิ้งประจำเดือน',
      [{key:'month',label:'เดือนที่ตรวจ',type:'month',required:true,value:ym(TODAY),full:true}]
      .concat(WW_PARAMS.map(p=>({key:p.k,label:p.label+(p.std?' ('+p.std+')':''),
        type:p.text?'text':'number',step:'0.01',required:!p.text&&p.k!=='cod',
        value:p.text?'ใส ไม่มีกลิ่น':''})))
      .concat([
        {key:'lab',label:'ห้องปฏิบัติการที่วิเคราะห์',value:'บจก. ห้องปฏิบัติการกลาง (ประเทศไทย)',full:true},
        {key:'by',label:'ผู้บันทึก',value:S().settings.user},
        {key:'file',label:'แนบเอกสารผลตรวจประจำเดือน',type:'file',full:true,placeholder:'แนบไฟล์ผลตรวจจากห้องปฏิบัติการ (.pdf .jpg)'}
      ]),d=>{
      const r=Object.assign({id:uid('WW'),fix:null,file:'ผลตรวจน้ำทิ้ง_'+d.month+'.pdf'},d);
      WW_PARAMS.forEach(p=>{ if(!p.text) r[p.k]=Number(r[p.k]||0); });
      r.fails=wwFails(r); r.result=r.fails.length?'ไม่ผ่าน':'ผ่าน';
      S().wastewater.unshift(r); S().wastewater.sort((a,b)=>b.month.localeCompare(a.month));
      if(r.fails.length){
        S().actions.unshift({id:uid('CA'),source:'Wastewater',ref:r.id,
          finding:'ผลตรวจน้ำเสีย '+thMonth(r.month)+' เกินมาตรฐาน: '+r.fails.join(', '),risk:'สูง',
          owner:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',due:iso(addDays(TODAY,14)),dept:'แผนกเครื่องมือแพทย์/แผนกวิศวกรรม',
          status:'Open',progress:0,detail:'ตรวจสอบระบบบำบัดน้ำเสีย ปรับกระบวนการ และสุ่มตรวจซ้ำ',created:iso(TODAY),photoAfter:0});
        toast('ค่าเกินมาตรฐาน ('+r.fails.join(', ')+') — สร้างงานแก้ไขอัตโนมัติแล้ว',true);
      } else toast('บันทึกผลตรวจน้ำเสียแล้ว — ผลผ่านเกณฑ์');
      Store.save(); render(); },null,{width:'760px'}); }
}

/* =========================================================
   Router & shell
   ========================================================= */
function route(){ const h=(location.hash||'#/home').replace('#/',''); return {page:V[h]?h:'home'}; }
function render(){
  destroyCharts();
  const r=route().page;
  $('#view').innerHTML=V[r]();
  $('#topTitle').textContent=TITLES[r]||'Dashboard';
  renderNav();
  if(V[r].after) try{ V[r].after(); }catch(e){ console.error(e); }
  bindCommon();
  window.scrollTo({top:0});
}
function bindCommon(){
  $$('[data-go]').forEach(b=>b.onclick=()=>{ location.hash='#/'+b.dataset.go; document.body.classList.remove('nav-open'); });
  $$('[data-quick]').forEach(b=>b.onclick=()=>quick(b.dataset.quick));
  $$('[data-ev]').forEach(b=>b.onclick=()=>eventDetail(b.dataset.ev));
  $$('[data-rca]').forEach(b=>b.onclick=()=>rcaModal(b.dataset.rca));
  const p=$('#printBtn'); if(p) p.onclick=printReport;
}
document.addEventListener('click',e=>{
  const bg=e.target.closest('.modal-bg');
  if(bg){ const btn=e.target.closest('button[data-close]');
    if(e.target===bg || btn){ closeModal(); return; } }
  const adv=e.target.closest('[data-advance]');
  if(adv){ const ev=S().events.find(x=>x.id===adv.dataset.advance);
    ev.timeline.push({t:iso(TODAY),title:'บันทึกความคืบหน้าโดย '+S().settings.user,by:S().settings.user,done:true});
    if(ev.status==='Open') ev.status='In Progress'; else if(ev.status==='In Progress') ev.status='Pending Verification'; else ev.status='Closed';
    Store.save(); closeModal(); toast('อัปเดตสถานะเป็น '+statTh(ev.status)); render(); }
  const np=$('#notifPanel');
  if(np && np.innerHTML && !e.target.closest('#notifPanel') && !e.target.closest('#bellBtn')) np.innerHTML='';
});
document.addEventListener('keydown',e=>{ if(e.key==='Escape') closeModal(); });

function renderNotifPanel(){
  const n=buildNotifs().slice(0,8);
  $('#notifPanel').innerHTML='<div class="card notif"><div class="card-h"><h3>การแจ้งเตือน</h3><div class="spacer"></div><span class="tiny muted">'+n.length+' รายการล่าสุด</span></div>'+
    '<div style="max-height:380px;overflow-y:auto">'+n.map(x=>'<div class="notif-item unread" data-go="'+x.go.replace('#/','')+'">'+
      '<span class="ndot" style="background:'+(x.level==='red'?'var(--red)':x.level==='amber'?'var(--amber)':'var(--blue)')+'"></span>'+
      '<div style="flex:1"><b class="small">'+esc(x.title)+'</b><div class="tiny muted">'+esc(x.detail)+'</div></div>'+
      '<div class="tiny muted nowrap">'+thDate(x.when)+'</div></div>').join('')+'</div>'+
    '<div class="card-b" style="padding:12px 16px;border-top:1px solid var(--line)"><button class="btn btn-sm" style="width:100%" data-go="notifications">ดูการแจ้งเตือนทั้งหมด</button></div></div>';
  $$('#notifPanel [data-go]').forEach(b=>b.onclick=()=>{ location.hash='#/'+b.dataset.go; $('#notifPanel').innerHTML=''; });
}
function updateUser(){
  const nm=S().settings.user;
  $('#userName').textContent=nm+' · '+S().settings.role;
  $('#avatar').textContent=nm.slice(0,2);
}
function init(){
  Store.load();
  $('#topDate').textContent=thLong(TODAY);
  $('#roleSel').innerHTML=ROLES.map(r=>'<option'+(r===S().settings.role?' selected':'')+'>'+r+'</option>').join('');
  $('#roleSel').onchange=e=>{ S().settings.role=e.target.value;
    const u=S().users.find(x=>x.role===e.target.value); if(u) S().settings.user=u.name;
    Store.save(); updateUser(); toast('เปลี่ยนสิทธิ์เป็น '+e.target.value+' — '+PERM[e.target.value].label); render(); };
  $('#menuBtn').onclick=()=>document.body.classList.toggle('nav-open');
  $('#bellBtn').onclick=()=>{ const p=$('#notifPanel'); if(p.innerHTML) p.innerHTML=''; else renderNotifPanel(); };
  $('#themeBtn').onclick=()=>{ const d=document.documentElement.getAttribute('data-theme')==='dark';
    document.documentElement.setAttribute('data-theme',d?'light':'dark');
    try{ localStorage.setItem('hsms.theme',d?'light':'dark'); }catch(e){} render(); };
  try{ const t=localStorage.getItem('hsms.theme'); if(t) document.documentElement.setAttribute('data-theme',t); }catch(e){}
  updateUser();
  $('#bellDot').hidden = buildNotifs().filter(x=>x.level==='red').length===0;
  window.addEventListener('hashchange',render);
  render();
}
init();
})();
